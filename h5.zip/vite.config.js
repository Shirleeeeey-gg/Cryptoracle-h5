import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import path from 'path'

// https://vite.dev/config/
export default defineConfig({
  plugins: [vue()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src')
    }
  },
  server: {
    host: '0.0.0.0',
    allowedHosts: ['127.0.0.1', 'localhost', '192.168.1.100','36815nf418.wicp.vip'],
    proxy: {
      '/api': {
        // target: 'https://13.236.140.216:8080',
        // target:'http://crypto.free.svipss.top',
        // target:'https://service.cryptoracle.network',
        target:'https://test.cryptoracle.network', //测试
        // target:'http://3290l77l22.wicp.vip',
        changeOrigin: true,
        secure: false,  // 添加此配置，允许不安全的https请求
        rewrite: (path) => path.replace(/^\/api/, '/api')
      }
    }
  }
})
