// postcss.config.js
module.exports = {
  plugins: {
    'postcss-px-to-viewport': {
      viewportWidth: 375,  // 设置视口的宽度
      // viewportHeight: 667, // 设置视口的高度
      unitPrecision: 5,    // 小数位数
      viewportUnit: 'vw',  // 转换的单位
      selectorBlackList: [], // 忽略的 CSS 选择器
      minPixelValue: 1,    // 最小转换单位
      mediaQuery: true,    // 允许在媒体查询中转换
    }
  }
}
