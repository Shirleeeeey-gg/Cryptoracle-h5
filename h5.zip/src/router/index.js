import { createRouter, createWebHistory } from 'vue-router'

const router = createRouter({
  history: createWebHistory(),
  routes: [
    { path: '/', name: 'home', component: () => import('../views/home/index.vue') },
    { path: '/dashboard', name: 'dashboard', component: () => import('../views/dashboard/index.vue') },
    {
      path:'/hot-section',
      name: 'hot-section',
      component: () => import('../views/dashboard/hotSection.vue')
    },
    {
      path:'/project',
      name: 'project',
      component: () => import('../views/dashboard/project.vue')
    },
    {
      path:'/cases',
      name: 'cases',
      component: () => import('../views/cases/index.vue')
    },
    
    {
      path:'/insights',
      name: 'insights',
      component: () => import('../views/insights/index.vue')
    },
    {
      path:'/faq',
      name: 'faq',
      component: () => import('../views/faq/index.vue')
    },
    {
      path:'/contact',
      name: 'contact',
      component: () => import('../views/contact/index.vue')
    },
    {
      path:'/resources',
      name: 'resources',
      component: () => import('../views/resources/index.vue')
    },
    {
      path:'/resources/user-guide',
      name: 'resources-user-guide',
      component: () => import('../views/resources/UserGuide.vue')
    },
    {
      path:'/resources/api-docs',
      name: 'resources-api-docs',
      component: () => import('../views/resources/ApiDocs.vue')
    },
    {
      path:'/about-us',
      name: 'about-us',
      component: () => import('../views/about-us/index.vue')
    },
    {
      path:'/groups',
      name: 'groups',
      component: () => import('../views/groups/index.vue')
    },
    {
      path:'/token-list',
      name: 'token-list',
      component: () => import('../views/token-list/index.vue')
    },
    {
      path:'/profile',
      name: 'profile',
      component: () => import('../views/profile/profile.vue')
    },    {
      path:'/watchlist',
      name: 'watchlist',
      component: () => import('../views/watchlist/index.vue')
    },
    {
      path:'/reset-pass',
      name: 'reset-pass',
      component: () => import('../views/login/reset-pass.vue')
    },
    {
      path:'/cookie-notice',
      name: 'cookie-notice',
      component: () => import('../views/login/agreement.vue')
    },
    {
      path:'/privacy-policy',
      name: 'privacy-policy',
      component: () => import('../views/login/agreement.vue')
    },
    {
      path:'/terms-of-use',
      name: 'terms-of-use',
      component: () => import('../views/login/agreement.vue')
    }
  ],
  scrollBehavior() {
    return { top: 0 }
  }
})

export default router