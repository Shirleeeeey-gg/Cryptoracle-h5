/**
 * 使用 SHA-256 算法加密字符串
 * @param {string} text - 需要加密的文本
 * @returns {Promise<string>} 返回加密后的十六进制字符串
 */
export async function sha256(text) {
  // 将文本转换为 UTF-8 编码的 Uint8Array
  const encoder = new TextEncoder();
  const data = encoder.encode(text);
  
  // 使用 Web Crypto API 进行 SHA-256 加密
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  
  // 将 ArrayBuffer 转换为十六进制字符串
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  const hashHex = hashArray.map(byte => byte.toString(16).padStart(2, '0')).join('');
  
  return hashHex;
}
