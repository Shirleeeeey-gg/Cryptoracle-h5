/**
 * 数字千分位格式化（返回格式化后的字符串）
 * @param {number} num - 需要格式化的数字
 * @param {number} decimals - 小数位数，默认为0
 * @returns {string} - 返回带千分位的字符串
 */
export function formatNumberWithCommas(num, decimals = 0) {
  if (num === null || num === undefined) return '0';
  
  // 处理小数位数
  const numStr = typeof num === 'number' 
    ? num.toFixed(decimals) 
    : parseFloat(num).toFixed(decimals);
  
  // 添加千分位分隔符
  const parts = numStr.split('.');
  parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  
  return parts.join('.');
}

/**
 * 数字千分位格式化（返回数组，用于滚动动画）
 * @param {number} num - 需要格式化的数字
 * @returns {Array} - 返回包含每个字符的数组，逗号用','表示，数字用对应的数字值表示
 */
export function formatNumberForScroll(num) {
  if (!num && num !== 0) return [0];
  
  const numStr = num.toString();
  const result = [];
  let count = 0;
  
  // 从后向前每三位添加逗号
  for (let i = numStr.length - 1; i >= 0; i--) {
    if (count === 3 && i !== 0) {
      result.unshift(',');
      count = 0;
    }
    result.unshift(numStr[i]);
    count++;
  }
  
  // 将数字字符转换为数字，逗号保持不变
  return result.map(char => char === ',' ? ',' : parseInt(char));
}

/**
 * 数字格式化（带单位缩写：K, M, B, T）
 * @param {number} num - 需要格式化的数字
 * @param {number} digits - 保留的小数位数
 * @returns {string} - 格式化后的字符串
 */
export function formatNumberWithUnit(num, digits = 2) {
  if (num === null || num === undefined) return '0';
  
  const units = ['', 'K', 'M', 'B', 'T'];
  let unitIndex = 0;
  let value = Math.abs(num);
  
  while (value >= 1000 && unitIndex < units.length - 1) {
    value /= 1000;
    unitIndex++;
  }
  
  // 处理符号和四舍五入
  const prefix = num < 0 ? '-' : '';
  value = Math.round(value * Math.pow(10, digits)) / Math.pow(10, digits);
  
  // 修复小数点部分
  const formattedValue = value.toFixed(digits).replace(/\.?0+$/, '');
  
  return `${prefix}${formattedValue}${units[unitIndex]}`;
}
