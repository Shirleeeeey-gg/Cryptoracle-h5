/**
 * Responsive utilities for handling viewport differences
 */

// Breakpoints in pixels
export const breakpoints = {
  xs: 375,
  sm: 576,
  md: 768,
  lg: 992,
  xl: 1200,
  xxl: 1920
};

// Check if viewport is mobile (<= 768px)
export const isMobile = () => {
  return window.innerWidth <= breakpoints.md;
};

// Check if viewport is tablet (> 768px and <= 992px)
export const isTablet = () => {
  return window.innerWidth > breakpoints.md && window.innerWidth <= breakpoints.lg;
};

// Check if viewport is desktop (> 992px)
export const isDesktop = () => {
  return window.innerWidth > breakpoints.lg;
};

// Add responsive class based on viewport
export const getResponsiveClass = () => {
  if (isMobile()) return 'mobile-view';
  if (isTablet()) return 'tablet-view';
  return 'desktop-view';
};

// Get appropriate element size based on viewport
export const getResponsiveSize = (mobileSizePx, desktopSizePx) => {
  return isMobile() ? mobileSizePx : desktopSizePx;
};

// Listen for viewport changes
export const addViewportListener = (callback) => {
  window.addEventListener('resize', callback);
  return () => window.removeEventListener('resize', callback);
}; 