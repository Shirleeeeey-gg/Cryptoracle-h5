import axios from 'axios'
import { ElMessage } from 'element-plus';
import { useUserStore } from '@/store/user';
import router from '@/router';

const service = axios.create({
  baseURL: import.meta.env.VITE_API_URL,
  timeout: 1500000
})

service.interceptors.request.use(
  config => {
    // 在请求发送前添加 token 到请求头
    // 从 user store 中获取 token（支持持久化）
    const userStore = useUserStore()
    if (userStore.token) {
      config.headers.token = userStore.token
    }
    return config
  },
  error => {
    return Promise.reject(error)
  }
)

service.interceptors.response.use(
  response => {
    // 根据自定义错误码判断请求是否成功
    if (response.status === 200) {
      if(response.data.code != 200){
        // 设置更高的 z-index，确保消息提示显示在弹窗之上（Login 弹窗 z-index 为 10000）
        ElMessage.error({
          message: response.data.msg,
          zIndex: 99999
        });
        return Promise.reject(new Error(response.data.msg));
      }
      return response.data
    }
    // 处理其他状态码
    return Promise.reject(new Error('Axios-----请求失败'))
  },
  error => {
    // 处理 HTTP 错误状态码（如 401、403、500 等）
    if (error.response) {
      const status = error.response.status;
      
      // 401 未授权：清除用户信息，跳转到 home 页面，然后触发登录弹框显示事件
      if (status === 401) {
        const userStore = useUserStore()
        // 清除用户登录信息
        userStore.clearUserInfo()
        
        // 检查当前路由，如果不是 home 页面，则跳转到 home 页面
        const currentRoute = router.currentRoute.value
        if (currentRoute.name !== 'home') {
          // 跳转到 home 页面
          router.push({ name: 'home' }).then(() => {
            // 跳转完成后，延迟一小段时间再触发登录弹框显示事件
            // 确保页面已经渲染完成
            setTimeout(() => {
              window.dispatchEvent(new CustomEvent('show-login-modal'))
            }, 100)
          }).catch(() => {
            // 如果跳转失败，仍然触发登录弹框显示事件
            window.dispatchEvent(new CustomEvent('show-login-modal'))
          })
        } else {
          // 如果已经在 home 页面，直接触发登录弹框显示事件
          window.dispatchEvent(new CustomEvent('show-login-modal'))
        }
        
      } else {
        // 其他错误状态码，显示错误信息
        const errorMessage = error.response.data?.msg || error.response.data?.message || `请求失败 (${status})`;
        ElMessage.error({
          message: errorMessage,
          zIndex: 99999
        });
      }
    } else {
      // 网络错误或其他错误
      ElMessage.error({
        message: error.message || 'Network Error',
        zIndex: 99999
      });
    }
    
    return Promise.reject(error)
  }
)

export default service
