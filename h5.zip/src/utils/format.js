/**
 * 数字格式化工具函数集合
 */

/**
 * 数字千分位格式化
 * @param {number|string} num - 需要格式化的数字
 * @param {number} decimals - 小数位数，默认为0
 * @param {string} separator - 千分位分隔符，默认为逗号
 * @returns {string} - 返回带千分位的字符串
 */
export function formatNumber(num, decimals = 0, separator = ',') {
  if (num === null || num === undefined || num === '') return '0';
  
  // 转换为数字
  const numValue = typeof num === 'number' ? num : parseFloat(num);
  if (isNaN(numValue)) return '0';
  
  // 处理小数位数
  const numStr = numValue.toFixed(decimals);
  
  // 添加千分位分隔符
  const parts = numStr.split('.');
  parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, separator);
  
  return parts.join('.');
}

/**
 * 数字格式化（带单位缩写：K, M, B, T）
 * @param {number|string} num - 需要格式化的数字
 * @param {number} digits - 保留的小数位数，默认为1
 * @param {boolean} addCommas - 是否添加千分符，默认为true
 * @returns {string} - 格式化后的字符串
 */
export function formatNumberWithUnit(num, digits = 1, addCommas = true) {
  if (num === null || num === undefined || num === '') return '0';
  
  const numValue = typeof num === 'number' ? num : parseFloat(num);
  if (isNaN(numValue)) return '0';
  
  const units = ['', 'K', 'M', 'B', 'T'];
  let unitIndex = 0;
  let value = Math.abs(numValue);
  
  while (value >= 1000 && unitIndex < units.length - 1) {
    value /= 1000;
    unitIndex++;
  }
  
  // 处理符号
  const prefix = numValue < 0 ? '-' : '';
  
  // 格式化数值
  let formattedValue;
  if (unitIndex === 0 && addCommas) {
    // 没有单位且需要千分符
    formattedValue = formatNumber(value, digits);
  } else {
    // 有单位或不需要千分符
    formattedValue = value.toFixed(digits).replace(/\.?0+$/, '');
  }
  
  return `${prefix}${formattedValue}${units[unitIndex]}`;
}

/**
 * 百分比格式化
 * @param {number|string} num - 需要格式化的数字
 * @param {number} decimals - 小数位数，默认为2
 * @returns {string} - 格式化后的百分比字符串
 */
export function formatPercentage(num, decimals = 2) {
  if (num === null || num === undefined || num === '') return '0%';
  
  const numValue = typeof num === 'number' ? num : parseFloat(num);
  if (isNaN(numValue)) return '0%';
  
  return `${numValue.toFixed(decimals)}%`;
}

/**
 * 货币格式化
 * @param {number|string} num - 需要格式化的数字
 * @param {string} currency - 货币符号，默认为$
 * @param {number} decimals - 小数位数，默认为2
 * @returns {string} - 格式化后的货币字符串
 */
export function formatCurrency(num, currency = '$', decimals = 2) {
  if (num === null || num === undefined || num === '') return `${currency}0`;
  
  const numValue = typeof num === 'number' ? num : parseFloat(num);
  if (isNaN(numValue)) return `${currency}0`;
  
  const formatted = formatNumber(numValue, decimals);
  return `${currency}${formatted}`;
}

/**
 * 数字滚动动画格式化（返回数组，用于滚动动画）
 * @param {number|string} num - 需要格式化的数字
 * @returns {Array} - 返回包含每个字符的数组
 */
export function formatNumberForScroll(num) {
  if (!num && num !== 0) return [0];
  
  const numStr = num.toString();
  const result = [];
  let count = 0;
  
  // 从后向前每三位添加逗号
  for (let i = numStr.length - 1; i >= 0; i--) {
    if (count === 3 && i !== 0) {
      result.unshift(',');
      count = 0;
    }
    result.unshift(numStr[i]);
    count++;
  }
  
  // 将数字字符转换为数字，逗号保持不变
  return result.map(char => char === ',' ? ',' : parseInt(char));
}

/**
 * 智能数字格式化（根据数值大小自动选择格式）
 * @param {number|string} num - 需要格式化的数字
 * @param {Object} options - 配置选项
 * @returns {string} - 格式化后的字符串
 */
export function formatNumberSmart(num, options = {}) {
  const {
    useUnit = true,        // 是否使用单位缩写
    useCommas = true,      // 是否使用千分符
    decimals = 2,          // 小数位数
    threshold = 10000      // 使用单位缩写的阈值
  } = options;
  
  if (num === null || num === undefined || num === '') return '0';
  
  const numValue = typeof num === 'number' ? num : parseFloat(num);
  if (isNaN(numValue)) return '0';
  
  const absValue = Math.abs(numValue);
  
  if (useUnit && absValue >= threshold) {
    return formatNumberWithUnit(numValue, decimals, false);
  } else if (useCommas) {
    return formatNumber(numValue, decimals);
  } else {
    return numValue.toFixed(decimals).replace(/\.?0+$/, '');
  }
} 

export function formatMembersWithUnit(num, digits = 1, addCommas = true) {
  if (num === null || num === undefined || num === '') return '0';
  
  const numValue = typeof num === 'number' ? num : parseFloat(num);
  if (isNaN(numValue)) return '0';
  
  const units = ['', 'K', 'M', 'B', 'T'];
  let unitIndex = 0;
  let value = Math.abs(numValue);
  
  while (value >= 1000 && unitIndex < units.length - 1) {
    value /= 1000;
    unitIndex++;
  }
  
  // 处理符号
  const prefix = numValue < 0 ? '-' : '';
  
  // 格式化数值
  let formattedValue;
  if (unitIndex === 0) {
    // 没有单位，不保留小数点
    formattedValue = formatNumber(value, 0);
  } else {
    // 有单位，保留小数点
    formattedValue = value.toFixed(digits).replace(/\.0+$/, '').replace(/(\.[1-9]*)0+$/, '$1');
  }
  
  return `${prefix}${formattedValue}${units[unitIndex]}`;
} 