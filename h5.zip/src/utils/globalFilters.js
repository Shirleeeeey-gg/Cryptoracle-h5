/**
 * Vue 3 全局属性和方法
 * 用于数字格式化的全局过滤器
 */

import { 
  formatNumber, 
  formatNumberWithUnit, 
  formatPercentage, 
  formatCurrency, 
  formatNumberSmart,
  formatMembersWithUnit
} from './format.js';

/**
 * 安装全局过滤器到Vue应用实例
 * @param {Object} app - Vue应用实例
 */
export function installGlobalFilters(app) {
  // 全局属性，可在模板中使用 $filters
  app.config.globalProperties.$filters = {
    // 基础千分符格式化
    number: formatNumber,
    
    // 带单位的数字格式化
    numberWithUnit: formatNumberWithUnit,

    // grouptable中members格式化
    members: formatMembersWithUnit,
    
    // 百分比格式化
    percentage: formatPercentage,
    
    // 货币格式化
    currency: formatCurrency,
    
    // 智能格式化
    numberSmart: formatNumberSmart,
    
    // 常用的预设格式化函数
    // 整数千分符
    integer: (num) => formatNumber(num, 0),
    
    // 两位小数千分符
    decimal: (num) => formatNumber(num, 2),
    
    // 价格格式化（美元）
    price: (num) => formatCurrency(num, '$', 2),
    
    // 成交量格式化（自动单位）
    volume: (num) => formatNumberWithUnit(num, 1),
    
    // 热度百分比
    heat: (num) => formatPercentage(num * 100, 1),

    // token名称格式化
    tokenName: (name) => {
      if (!name) return '';
      const length = name.length;
      
      // 1-5个字符：只保留1个中间字符，两边补*
      if (length >= 1 && length <= 5) {
        const mid = Math.floor(length / 2);
        return '*'.repeat(mid) + name.charAt(mid) + '*'.repeat(length - mid - 1);
      } 
      // 6-9个字符：保留中间两个字符，两边分别补2个*
      else if (length >= 6 && length <= 9) {
        const midStart = Math.floor((length - 2) / 2);
        return '**' + name.substring(midStart, midStart + 2) + '**';
      } 
      // >9个字符：保留中间两个字符，两边分别补4个*
      else if (length > 9) {
        const midStart = Math.floor((length - 2) / 2);
        return '****' + name.substring(midStart, midStart + 2) + '****';
      }
      
      return name;
    },
  };

  // 也可以直接挂载到全局属性上，方便在组件中使用
  app.config.globalProperties.$formatNumber = formatNumber;
  app.config.globalProperties.$formatCurrency = formatCurrency;
  app.config.globalProperties.$formatPercentage = formatPercentage;
} 