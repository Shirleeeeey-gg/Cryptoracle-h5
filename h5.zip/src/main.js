import { createApp } from 'vue'
import './style.css'
import App from './App.vue'
import router from './router'
import store from './store'
import ElementPlus from 'element-plus'
import 'element-plus/dist/index.css'

// 导入全局过滤器
import { installGlobalFilters } from './utils/globalFilters.js'

const app = createApp(App)
app.use(router)
app.use(store)
app.use(ElementPlus)

// 安装全局过滤器
installGlobalFilters(app)

app.mount('#app')

