import request from '@/utils/request'

// 获取co10列表  View CO10 List 10个币种列表  无参
export function getCO10TokenListApi() {
  return request({
    url: '/adsCoinList/page',
    method: 'post',
  })
}

// 获取co全部币种的列表    参数：pageNum  pageSize
export function getCOAllTokenListApi(data) {
  return request({
    url: '/adsCoinList/all',
    method: 'post',
    data
  })
}

// 排行榜Callout Highlights 无参
export function getCORankingCalloutHighlightsApi() {
  return request({
    url: '/adsCoinList/calloutHighlights',
    method: 'post'
  })
}

// 排行榜Sentiment Momentum 无参
export function getCORankingSentimentSurgeApi() {
  return request({
    url: '/adsCoinList/sentimentSurge',
    method: 'post'
  })
}

// 排行榜DAT 无参
export function getCORankingDATApi() {
  return request({
    url: '/adsCoinList/DAT',
    method: 'post'
  })
}

