import request from '@/utils/request'

/**
 * 邮箱密码登录接口
 * @param {Object} data - 登录数据
 * @param {string} data.email - 用户邮箱
 * @param {string} data.password - 用户密码（SHA-256 加密后的密码）
 * @returns {Promise} 返回登录请求的 Promise
 */
export function loginApi(data){
  return request({
    url: '/coUser/login/password',
    method: 'post',
    data
  })
}

/**
 * Google 登录/注册接口
 * @param {Object} data - Google 登录数据
 * @param {string} data.credential - Google OAuth 返回的 credential (JWT token)
 * @returns {Promise} 返回登录请求的 Promise
 */
export function googleLoginApi(data) {
  return request({
    url: '/coUser/login/google',
    method: 'post',
    data
  })
}

// 谷歌快捷注册回调页面后需要调用的接口
export function googleCallbackApi(data) {
  return request({
    url: '/coUser/callback',
    method: 'get',
    params: data
  })
}

/**
 * 用户注册接口
 * @param {Object} data - 注册数据
 * @param {string} data.email - 用户邮箱
 * @param {string} data.password - 用户密码（SHA-256 加密后的密码）
 * @returns {Promise} 返回注册请求的 Promise
 */
export function registerApi(data) {
  return request({
    url: '/coUser/register/email',
    method: 'post',
    data
  })
}

/**
 * 重新发送验证邮件接口
 * @param {Object} data - 重发邮件数据
 * @param {string} data.email - 用户邮箱
 * @returns {Promise} 返回重发邮件请求的 Promise
 */
export function resendEmailApi(data){
  return request({
    url: '/coUser/resend-verify-email',
    method: 'post',
    data
  })
}

/**
 * 忘记密码--发送重置密码邮件接口
 * @param {Object} data - 忘记密码数据
 * @param {string} data.email - 用户邮箱
 * @returns {Promise} 返回发送邮件请求的 Promise
 */
export function forgotPasswordApi(data){
  return request({
    url: '/coUser/forgot-password/send-link',
    method: 'post',
    data
  })
}

/**
 * 重置密码接口
 * @param {Object} data - 重置密码数据
 * @param {string} data.code - 重置密码验证码（从路由 query 参数获取）
 * @param {string} data.newPassword - 新密码（SHA-256 加密后的密码）
 * @param {string} data.confirmPassword - 确认密码（SHA-256 加密后的密码）
 * @returns {Promise} 返回重置密码请求的 Promise
 */
export function resetPasswordApi(data){
  return request({
    url: '/coUser/forgot-password/reset',
    method: 'post',
    data
  })
}

/**
 * 退出登录接口
 * @returns {Promise} 返回登出请求的 Promise
 */
export function logoutApi() {
  return request({
    url: '/coUser/logout',
    method: 'post',
  })
}

/**
 * 个人中心，查看用户信息接口
 * @param {Object} data - 用户数据
 * @param {string} data.userId - 用户ID
 * @returns {Promise} 返回获取用户信息请求的 Promise
 */
export function getProfileApi(data){
  return request({
    url: '/coUserInfo/detail',
    method: 'post',
    data
  })
}

/**
 * 个人中心 用户信息保存接口
 * @param {Object} data - 用户数据
 * @returns {Promise} 返回保存用户信息请求的 Promise
 */
export function saveProfileApi(data){
  return request({
    url: '/coUserInfo/update',
    method: 'post',
    data
  })
}

/**
 * 修改密码接口
 * @param {Object} data - 密码数据
 * @param {string} data.userId - 用户ID
 * @param {string} data.currentPassword - 当前密码（SHA-256 加密后的密码）
 * @param {string} data.newPassword - 新密码（SHA-256 加密后的密码）
 * @param {string} data.confirmPassword - 确认密码（SHA-256 加密后的密码）
 * @returns {Promise} 返回修改密码请求的 Promise
 */
export function changePasswordApi(data){
  return request({
    url: '/coUser/change-password',
    method: 'post',
    data
  })
}

/**
 * 币种-取消收藏
 * @param {Object} data - 取消收藏数据
 * @param {string} data.userId - 用户ID
 * @param {string} data.coin - 币种
 * @returns {Promise} 返回取消收藏请求的 Promise
 */
export function getCollectApi(data){
  return request({
    url: '/coUserCoin/collect',
    method: 'post',
    data
  })
}

/**
 * 币种-取消收藏
 * @param {Object} data - 取消收藏数据
 * @param {string} data.userId - 用户ID
 * @param {string} data.coin - 币种
 * @returns {Promise} 返回取消收藏请求的 Promise
 */
export function getCancelCollectApi(data){
  return request({
    url: '/coUserCoin/cancelCollect',
    method: 'post',
    data
  })
}

/**
 * 用户收藏币种列表
 * @param {Object} data - 查询数据
 * @returns {Promise} 返回用户收藏币种列表请求的 Promise
 */
export function getUserCollectListApi(data){
  return request({
    url: '/coUserCoin/list',
    method: 'post',
    data
  })
}

/**
 * 收集用户更多信息的接口（邮箱注册）
 * @param {Object} data - 用户信息数据
 * @param {string} data.code - 验证码
 * @param {string} data.userRole - 用户角色
 * @param {string} data.about - 了解渠道（可选）
 * @param {string} data.telegramOne - Telegram 用户名（可选）
 * @param {string} data.telephone - 电话号码（可选）
 * @returns {Promise} 返回收集用户信息请求的 Promise
 */
export function collectUserMoreInfoApi(data){
  return request({
    url: '/coUser/verify-email',
    method: 'post',
    data
  })
}

/**
 * 检查用户是否已填写 tell us more
 * @param {Object} data - 查询数据
 * @param {string} data.code - 验证码（可选）
 * @param {string} data.userId - 用户ID（可选）
 * @returns {Promise} 返回检查结果，0-未验证 1-已验证 2-已过期
 */
export function checkUserTellUsMoreApi(data) {
  return request({
    url: '/coUser/check-email',
    method: 'post',
    data
  })
}

/**
 * 谷歌快捷登录 填写tell us more 的保存接口
 * @param {Object} data - 用户信息数据
 * @param {string} data.userId - 用户ID
 * @param {string} data.userRole - 用户角色
 * @param {string} data.about - 了解渠道（可选）
 * @param {string} data.telegramOne - Telegram 用户名（可选）
 * @param {string} data.telephone - 电话号码（可选）
 * @returns {Promise} 返回保存用户信息请求的 Promise
 */
export function saveUserTellUsMoreApi(data) {
  return request({
    url: '/coUserInfo/updateUser',
    method: 'post',
    data
  })
}
