import request from '@/utils/request'

/**
 * 获取每小时新闻列表
 * @param {Object} params - 请求参数
 * @returns {Promise} - 返回请求结果
 */
export function getHourlyNewsList(params) {
  return request({
    url: '/twitter/hourly/list',
    method: 'get',
    params
  })
}

export function getCryptoListApi(params){
  return request({
    url:'/twitter/crypto/list',
    method:'get',
    params
  })
}

//首页数据条数接口
export function getHomeDataCountApi(params){
  return request({
    url:'/twitter/count/sum',
    method:'get',
    params
  })
}

export function getTwitterCollectionListApi(params) {
  return request({
    url: '/twitter/collection/list',
    method: 'get',
    params
  })
}

export function getTwitterSentimentApi(params) {
  return request({
    url: '/twitter/sentiment/list',
    method: 'get',
    params
  })
}

export function saveEmailApi(data) {
  return request({
    url: '/twitter/mailbox/install',
    method: 'post',
    data
  })
}