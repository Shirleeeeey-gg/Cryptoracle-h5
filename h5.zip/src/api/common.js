import request from '@/utils/request'

// kol列表 无参
export function getKolListApi() {
  return request({
    url: '/community/kolList',
    method: 'post'
  })
}

// 搜索框底下的10个热门币种 无参
export function getHotCoinApi() {
  return request({
    url: '/adsCoinList/search',
    method: 'post'
  })
}

// 搜索接口  搜索框模糊匹配币种列表  post 参数：coin
export function getSearchCoinApi(data) {
  return request({
    url: '/adsCoinList/searchLike',
    method: 'post',
    data
  })
}

// 获取Factor Trends图表数据
/* post 参数：timeType 15m 30m 1h 4h 1d, coin ,startTime,endTime  ,idList 这里id字段是 左侧 labelsTree 接口返回的id字段，用来筛选 */
export function getFactorTrendsApi(data) {
  return request({
    url: '/adsCoin/labelList',
    method: 'post',
    data
  })
}
