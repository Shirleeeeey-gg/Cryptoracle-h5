import request from '@/utils/request'

// dashboard首屏数据获取
export function getDashboardDataApi(data) {
  return request({
    url: '/dashboard/index',
    method: 'post',
    data
  })
}

// dashboard首屏会变动的数据获取
export function getDashboardChangeDataApi(data) {
  return request({
    url: '/dashboard/totalData',
    method: 'post',
    data
  })
}

// CO50 token list 列表接口
export function getCO50TokenListApi(data) {
  return request({
    url: '/coinData/listPage',
    method: 'post',
    data
  })
}

// 折线图接口
export function getLineChartDataApi(data) {
  return request({
    url: '/kline/select',
    method: 'post',
    data
  })
}

// project页面数据获取
export function getProjectLineChartDataApi(data) {
  return request({
    // url: '/kline/coinSelect',
    url:'/adsCoin/detail',
    method: 'post',
    data
  })
}

// project页面上方两个图表
export function getProjectTopChartDataApi(data) {
  return request({
    // url: '/kline/price',
    url:'/adsCoin/list',
    method: 'post',
    data
  })
}

// project页面下方折线图
export function getProjectBottomChartDataApi(data) {
  return request({
    url: '/kline/heat',
    method: 'post',
    data
  })
}

//project页面三个圈的接口
export function getProjectThreeCirclesDataApi(data) {
  return request({
    url: '/kline/heatStaion',
    method: 'post',
    data
  })
}

//project页面三个圈点进去的列表页
export function getProjectThreeCirclesListDataApi(data) {
  return request({
    url: 'kline/coinTopList',
    method: 'post',
    data
  })
}

// aivix图表接口
export function getAivixChartDataApi(data) {
  return request({
    url: '/adsEmo/list',
    method: 'post',
    data
  })
}