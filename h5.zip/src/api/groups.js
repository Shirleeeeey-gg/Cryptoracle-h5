import request from '@/utils/request'

// groups页面列表数据获取
export function getGroupTableDataApi(data) {
  return request({
    url: '/community/list',
    method: 'post',
    data
  })
}

// groups页面数据统计
export function getGroupDataApi() {
  return request({
    url: '/community/total',
    method: 'post'
  })
}