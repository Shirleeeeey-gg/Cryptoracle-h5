<template>
  <Teleport to="body">
    <Transition name="register-fade">
      <div v-if="visible" class="register-overlay" @click.self="handleClose">
      <!-- 注册弹框 -->
      <div v-if="!showEmailVerification" class="register-modal">
        <!-- 关闭按钮 -->
        <button class="close-btn" @click="handleClose">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect
              x="4.02515"
              y="18.5225"
              width="20.538"
              height="2.0538"
              rx="1.0269"
              transform="rotate(-45 4.02515 18.5225)"
              fill="currentColor"
            />
            <rect
              x="5.23328"
              y="4.02515"
              width="20.538"
              height="2.0538"
              rx="1.0269"
              transform="rotate(45 5.23328 4.02515)"
              fill="currentColor"
            />
          </svg>
        </button>

        <!-- 标题 -->
        <h2 class="register-title">Sign Up</h2>

        <!-- 表单 -->
        <form class="register-form" @submit.prevent="handleSubmit">
          <!-- Email 输入框 -->
          <div class="form-group">
            <label class="form-label">Email Address</label>
            <input
              v-model="formData.email"
              type="email"
              :class="['form-input', { 'form-input-error': emailError }]"
              placeholder="Enter your email address"
              @blur="validateEmail"
            />
            <!-- 错误提示信息 -->
            <div v-if="emailError" class="error-message">{{ emailErrorMsg }}</div>
          </div>

          <!-- Password 输入框 -->
          <div class="form-group">
            <label class="form-label">Password</label>
            <div class="password-input-wrapper">
              <input
                v-model="formData.password"
                :type="showPassword ? 'text' : 'password'"
                :class="['form-input', 'password-input', { 'form-input-error': passwordError }]"
                placeholder="Enter your password"
                @blur="validatePassword"
                @input="checkPasswordRules"
              />
              <button
                type="button"
                class="password-toggle-btn"
                @click="togglePasswordVisibility"
              >
                <img
                  :src="showPassword ? iconEye : iconEyeClose"
                  alt="Toggle password visibility"
                />
              </button>
            </div>
            <!-- 密码验证规则提示 -->
            <div v-if="showLengthRule || showFormatRule" class="password-rules">
              <div v-if="showLengthRule" class="password-rule-item">- Use 8-20 characters.</div>
              <div v-if="showFormatRule" class="password-rule-item">- Include both letters and numbers.</div>
            </div>
            <!-- 错误提示信息 -->
            <div v-if="passwordError" class="error-message">{{ passwordErrorMsg }}</div>
          </div>

          <!-- 邮件订阅复选框 -->
          <div class="checkbox-group">
            <label class="checkbox-label">
              <input
                v-model="formData.isSubscribe"
                type="checkbox"
                :true-value="1"
                :false-value="0"
                class="checkbox-input"
              />
              <span class="checkbox-text">
                Please keep me updated by email with the latest crypto news, research findings, reward programs, event updates, coin listings and more information from Cryptoracle.
              </span>
            </label>
          </div>

          <!-- 注册按钮 -->
          <button type="submit" :disabled="isLoading" class="register-btn">
            <span v-if="isLoading" class="loading-spinner"></span>
            <span>{{isLoading ? 'Creating' : 'Create an account'}}</span>
          </button>
        </form>

        <!-- 分隔线 -->
        <div class="divider">
          <span class="divider-text">OR</span>
        </div>

        <!-- Google 登录按钮 -->
        <button class="google-btn" @click="handleGoogleLogin" :disabled="isGoogleLoading">
          <span v-if="isGoogleLoading" class="loading-spinner"></span>
          <img v-else src="@/assets/login/icon-google.png" alt="Google" class="google-icon" />
          <span>{{ isGoogleLoading ? 'Connecting...' : 'Continue with Google' }}</span>
        </button>

        <!-- 法律条款 -->
        <div class="legal-text">
          <span class="legal-text-normal">By proceeding, you agree to Cryptoracle's</span>
          <div class="legal-links">
            <a href="#" class="legal-link" @click.prevent="handleTermsClick">Terms of Use</a>
            <span class="legal-separator">&</span>
            <a href="#" class="legal-link" @click.prevent="handlePrivacyClick">Privacy Policy</a>
          </div>
        </div>
      </div>

      <!-- 邮箱验证弹框 -->
      <div v-if="showEmailVerification" class="email-verification-modal">
        <!-- 左上角返回按钮 -->
        <button class="back-btn" @click="handleBack">
          <img src="@/assets/login/icon-back.svg" alt="Back" class="back-icon" />
        </button>

        <!-- 右上角关闭按钮 -->
        <button class="close-btn" @click="handleClose">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect
              x="4.02515"
              y="18.5225"
              width="20.538"
              height="2.0538"
              rx="1.0269"
              transform="rotate(-45 4.02515 18.5225)"
              fill="currentColor"
            />
            <rect
              x="5.23328"
              y="4.02515"
              width="20.538"
              height="2.0538"
              rx="1.0269"
              transform="rotate(45 5.23328 4.02515)"
              fill="currentColor"
            />
          </svg>
        </button>

        <!-- 邮件图标 -->
        <div class="email-icon-wrapper">
          <img src="@/assets/login/icon-email.png" alt="Email" class="email-icon" />
        </div>

        <!-- 标题 -->
        <h2 class="verification-title">Verify Your Email To Activate Your Account</h2>

        <!-- 说明文字 -->
        <p class="verification-text">
          We sent a link to <span class="email-highlight">{{ formData.email }}</span> to verify your email. If you don't see it within a few minutes, be sure to check your spam folder.
        </p>

        <!-- 重发邮件按钮 -->
        <button 
          class="resend-btn" 
          :disabled="countdown > 0 || isResending"
          @click="handleResendEmail"
        >
          <span v-if="isResending" class="loading-spinner"></span>
          <span>{{ isResending ? 'Sending' : 'Resend email' }}</span>
        </button>

        <!-- 倒计时提示 -->
        <p v-if="countdown > 0" class="countdown-text">
          Resend your email if it doesn't arrive in {{ formatCountdown(countdown) }}
        </p>
      </div>
    </div>
  </Transition>
  </Teleport>
</template>

<script setup>
import { ref, defineProps, defineEmits, watch, onUnmounted, onBeforeUnmount } from 'vue';
import iconEye from '@/assets/login/icon-eye.svg';
import iconEyeClose from '@/assets/login/icon-eye-close.svg';
import { registerApi, resendEmailApi } from '@/api/login';
import { sha256 } from '@/utils/encrypto';
import { useUserStore } from '@/store/user';
import { ElMessage } from 'element-plus';
import { useRouter } from 'vue-router';
const router = useRouter();
// 定义 props：控制弹窗显示/隐藏
const props = defineProps({
  visible: {
    type: Boolean,
    default: false,
  },
});

// 定义 emits：关闭事件
const emit = defineEmits(['update:visible', 'close']);

// 表单数据
const formData = ref({
  email: '',
  password: '',
  isSubscribe: 0, // 邮件订阅选项：勾选=1，未勾选=0
});

// 控制密码显示/隐藏
const showPassword = ref(false);

// 邮箱验证错误状态
const emailError = ref(false);
// 邮箱错误消息
const emailErrorMsg = ref('');

// 密码验证错误状态
const passwordError = ref(false);
// 密码错误消息
const passwordErrorMsg = ref('');
// 密码规则提示显示状态
const showLengthRule = ref(false); // 是否显示长度规则提示（8-20字符）
const showFormatRule = ref(false); // 是否显示格式规则提示（包含数字和字母）

// 注册加载状态
const isLoading = ref(false);

// Google 登录加载状态
const isGoogleLoading = ref(false);

// 邮箱验证弹框显示状态
const showEmailVerification = ref(false);

// 用户 Store
const userStore = useUserStore();

// 倒计时（秒）
const countdown = ref(0);

// 重发邮件加载状态
const isResending = ref(false);

// 倒计时定时器
let countdownTimer = null;

// 保存页面滚动位置
let savedScrollTop = 0;

// 禁止页面滚动
const disableBodyScroll = () => {
  // 保存当前滚动位置
  savedScrollTop = window.pageYOffset || document.documentElement.scrollTop;
  
  // 给 body 添加样式禁止滚动
  document.body.style.overflow = 'hidden';
  document.body.style.position = 'fixed';
  document.body.style.top = `-${savedScrollTop}px`;
  document.body.style.width = '100%';
  
  // 阻止移动端触摸滚动
  document.addEventListener('touchmove', preventScroll, { passive: false });
};

// 恢复页面滚动
const enableBodyScroll = () => {
  // 移除禁止滚动的样式
  document.body.style.overflow = '';
  document.body.style.position = '';
  document.body.style.top = '';
  document.body.style.width = '';
  
  // 恢复滚动位置
  window.scrollTo(0, savedScrollTop);
  
  // 移除触摸滚动阻止
  document.removeEventListener('touchmove', preventScroll);
};

// 阻止触摸滚动事件（只阻止弹框外部的滚动，允许弹框内部滚动）
const preventScroll = (e) => {
  // 如果触摸事件发生在弹框内部，允许滚动
  const target = e.target;
  const registerModal = document.querySelector('.register-modal');
  const emailModal = document.querySelector('.email-verification-modal');
  if ((registerModal && registerModal.contains(target)) || 
      (emailModal && emailModal.contains(target))) {
    return; // 允许弹框内部滚动
  }
  // 否则阻止滚动
  e.preventDefault();
};

// 监听 visible 变化，控制页面滚动
watch(
  () => props.visible,
  (newVal) => {
    if (newVal) {
      // 弹窗打开时禁止滚动
      disableBodyScroll();
    } else {
      // 弹窗关闭时恢复滚动
      enableBodyScroll();
    }
  },
  { immediate: true }
);

// 组件卸载时确保恢复滚动和清除定时器
onUnmounted(() => {
  enableBodyScroll();
  clearCountdown();
});

// 切换密码显示状态
const togglePasswordVisibility = () => {
  showPassword.value = !showPassword.value;
};

// 邮箱格式验证函数
const validateEmail = () => {
  const email = formData.value.email.trim();
  // 邮箱格式正则表达式
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  
  // 如果邮箱为空，显示错误提示（已去掉 required 属性）
  if (email === '') {
    emailError.value = true;
    emailErrorMsg.value = 'Please input your email';
    return;
  }
  
  // 验证邮箱格式
  if (!emailRegex.test(email)) {
    emailError.value = true;
    emailErrorMsg.value = 'Invalid email format.';
  } else {
    emailError.value = false;
    emailErrorMsg.value = '';
  }
};

// 实时检查密码规则（在用户输入时触发）
const checkPasswordRules = () => {
  const password = formData.value.password;
  
  // 如果密码为空，隐藏所有规则提示
  if (!password || password.trim() === '') {
    showLengthRule.value = false;
    showFormatRule.value = false;
    return;
  }
  
  // 检查长度规则：8-20 字符
  const lengthValid = password.length >= 8 && password.length <= 20;
  showLengthRule.value = !lengthValid;
  
  // 检查格式规则：至少包含一个数字和一个字母
  const hasNumber = /\d/.test(password); // 检查是否包含数字
  const hasLetter = /[a-zA-Z]/.test(password); // 检查是否包含字母（不区分大小写）
  showFormatRule.value = !(hasNumber && hasLetter);
};

// 密码格式验证函数
const validatePassword = () => {
  const password = formData.value.password.trim();
  
  // 先检查规则
  checkPasswordRules();
  
  // 如果密码为空，显示错误提示（已去掉 required 属性）
  if (password === '') {
    passwordError.value = true;
    passwordErrorMsg.value = 'Please input your password.';
    return;
  }
  
  // 校验规则：至少包含一个数字和一个字母（不区分大小写）
  const hasNumber = /\d/.test(password); // 检查是否包含数字
  const hasLetter = /[a-zA-Z]/.test(password); // 检查是否包含字母（不区分大小写）
  
  // 检查长度
  const lengthValid = password.length >= 8 && password.length <= 20;
  
  // 如果缺少数字或字母，或者长度不符合要求，则显示错误
  if (!(hasNumber && hasLetter && lengthValid)) {
    passwordError.value = true;
    passwordErrorMsg.value = 'Invalid password format.';
  } else {
    passwordError.value = false;
    passwordErrorMsg.value = '';
  }
};

// 处理关闭
const handleClose = () => {
  // 清除倒计时
  clearCountdown();
  // 重置邮箱验证弹框状态
  showEmailVerification.value = false;
  // 清空所有输入框
  formData.value.email = '';
  formData.value.password = '';
  formData.value.isSubscribe = 0;
  // 清空错误状态
  emailError.value = false;
  emailErrorMsg.value = '';
  passwordError.value = false;
  passwordErrorMsg.value = '';
  // 清空密码规则提示
  showLengthRule.value = false;
  showFormatRule.value = false;
  // 重置密码显示状态
  showPassword.value = false;
  emit('update:visible', false);
  emit('close');
};

// 处理表单提交
const handleSubmit = async () => {
  // 如果正在加载中，不重复提交
  if (isLoading.value) {
    return;
  }
  
  // 验证邮箱和密码格式
  validateEmail();
  validatePassword();
  
  // 如果验证失败，不提交表单
  if (emailError.value || passwordError.value) {
    return;
  }
  
  // 设置加载状态
  isLoading.value = true;
  
  try {
    // 使用 SHA-256 加密密码
    const encryptedPassword = await sha256(formData.value.password);
    
    // 调用注册接口，传递 email 和加密后的 password 参数
    await registerApi({
      email: formData.value.email.trim(),
      password: encryptedPassword,
      isSubscribe: formData.value.isSubscribe,
    });
    
    // 注册成功后显示邮箱验证弹框
    showEmailVerification.value = true;
    // 启动60秒倒计时
    startCountdown();
    
  } catch (error) {
    // 注册失败，打印错误信息
    console.error('Register error:', error);
    // TODO: 可以在这里添加错误提示，比如显示错误消息给用户
  } finally {
    // 无论成功或失败，都重置加载状态
    isLoading.value = false;
  }
};


const handleGoogleLogin = () => {
  // 如果正在加载中，不重复触发
  if (isGoogleLoading.value) {
    return;
  }

  // 设置加载状态
  isGoogleLoading.value = true;

  try {
    // 从环境变量获取 Google Client ID
    // 需要在 .env 文件中配置 VITE_GOOGLE_CLIENT_ID
    const GOOGLE_CLIENT_ID = import.meta.env.VITE_GOOGLE_CLIENT_ID || '';

    if (!GOOGLE_CLIENT_ID) {
      console.log('Google Client ID 未配置，请联系管理员');
      isGoogleLoading.value = false;
      return;
    }

    // 使用 OAuth 2.0 授权码流程，显示完整的授权同意页面
    // 这种方式会重定向到 Google 授权服务器，显示详细的授权信息
    useOAuth2AuthorizationCodeFlow(GOOGLE_CLIENT_ID);

  } catch (error) {
    console.error('Google login initialization error:', error);
    isGoogleLoading.value = false;
  }
};

/**
 * 使用 OAuth 2.0 授权码流程（Authorization Code Flow）
 * 这种方式会显示完整的授权同意页面，用户可以看到应用请求访问的信息
 * @param {string} clientId - Google Client ID
 */
const useOAuth2AuthorizationCodeFlow = (clientId) => {
  try {
    // 生成随机状态参数，用于防止 CSRF 攻击
    const state = Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
    // 将状态保存到 sessionStorage，用于回调时验证
    sessionStorage.setItem('google_oauth_state', state);
    // 保存 client_id，用于回调时换取 token
    sessionStorage.setItem('google_oauth_client_id', clientId);
    
    // 构建授权 URL
    // 使用授权码流程（response_type=code），这会显示完整的授权同意页面
    // const redirectUri = window.location.origin;
    const redirectUri = 'https://www.cryptoracle.network';
    const scope = 'openid email profile';
    const authUrl = `https://accounts.google.com/o/oauth2/v2/auth?` +
      `client_id=${encodeURIComponent(clientId)}` +
      `&redirect_uri=${encodeURIComponent(redirectUri)}` +
      `&response_type=code` +
      `&scope=${encodeURIComponent(scope)}` +
      `&state=${encodeURIComponent(state)}` +
      `&access_type=offline` +
      `&prompt=consent`; // 强制显示同意页面，即使之前已授权
    
    // 重定向到 Google 授权服务器
    window.location.href = authUrl;
    
  } catch (error) {
    console.error('OAuth2 authorization code flow error:', error);
    isGoogleLoading.value = false;
  }
};

// 处理返回（回退到注册弹框）
const handleBack = () => {
  showEmailVerification.value = false;
  // 清除倒计时
  clearCountdown();
};

// 启动倒计时（60秒）
const startCountdown = () => {
  countdown.value = 60;
  countdownTimer = setInterval(() => {
    countdown.value--;
    if (countdown.value <= 0) {
      clearCountdown();
    }
  }, 1000);
};

// 清除倒计时
const clearCountdown = () => {
  if (countdownTimer) {
    clearInterval(countdownTimer);
    countdownTimer = null;
  }
  countdown.value = 0;
};

// 格式化倒计时显示（MM:SS）
const formatCountdown = (seconds) => {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
};

// 处理重发邮件
const handleResendEmail = async () => {
  if (countdown.value > 0 || isResending.value) {
    return;
  }

  isResending.value = true;

  try {
    // 调用重发邮件接口，传递 email 参数
    await resendEmailApi({
      email: formData.value.email.trim()
    });
    
    // 重新启动60秒倒计时
    startCountdown();
  } catch (error) {
    // 重发邮件失败，打印错误信息
    console.error('Resend email error:', error);
    // TODO: 可以在这里添加错误提示，比如显示错误消息给用户
  } finally {
    isResending.value = false;
  }
};

// 组件卸载时清除定时器
onBeforeUnmount(() => {
  clearCountdown();
});

// 处理条款点击
const handleTermsClick = () => {
  handleClose()
  // 可以跳转到条款页面或打开新窗口
  if (router.resolve({ name: 'terms-of-use' }).matched.length > 0) {
    router.push({ name: 'terms-of-use' })
  } else {
    window.open('/terms-of-use', '_blank')
  }
};

// 处理隐私政策点击
const handlePrivacyClick = () => {
  handleClose()
  // 可以跳转到隐私政策页面或打开新窗口
  if (router.resolve({ name: 'privacy-policy' }).matched.length > 0) {
    router.push({ name: 'privacy-policy' })
  } else {
    window.open('/privacy-policy', '_blank')
  }
};
</script>

<style scoped lang="scss">
.register-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  width: 100vw;
  height: 100vh;
  height: 100dvh; /* 使用动态视口高度，适配移动端浏览器 */
  background: rgba(0, 0, 0, 0.6);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 10000;
}

.register-modal {
  position: relative;
  width: 100%;
  height: 100vh;
  height: 100dvh; /* 使用动态视口高度，适配移动端浏览器 */
  max-height: 100vh;
  max-height: 100dvh; /* 使用动态视口高度，适配移动端浏览器 */
  background: #1A1625;
  padding: 20px 20px 32px;
  padding-bottom: calc(32px + env(safe-area-inset-bottom)); /* 底部安全区域适配 */
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  overflow-y: auto;
  overflow-x: hidden;
  -webkit-overflow-scrolling: touch;
  /* 确保内容可以滚动到底部 */
  overscroll-behavior: contain;
}

.close-btn {
  position: absolute;
  top: 20px;
  right: 20px;
  width: 24px;
  height: 24px;
  background: transparent;
  border: none;
  cursor: pointer;
  padding: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #ffffff;
  transition: opacity 0.2s ease;

  svg {
    width: 24px;
    height: 24px;
    display: block;
  }

  &:active {
    opacity: 0.8;
  }
}

.register-title {
  font-family: 'Tomato Grotesk', sans-serif;
  font-size: 28px;
  font-weight: 600;
  line-height: 36px;
  color: #ffffff;
  text-align: center;
  margin: 0 0 32px 0;
}

.register-form {
  flex-shrink: 0;
}

.form-group {
  margin-bottom: 16px;
}

.form-label {
  display: block;
  font-family: 'Tomato Grotesk', sans-serif;
  font-size: 14px;
  line-height: 18px;
  font-weight: 500;
  color: #ffffff;
  margin-bottom: 8px;
}

.form-input {
  width: 100%;
  height: 56px;
  padding: 0 20px;
  background: #302D48;
  border: 1px solid #8D67FF;
  border-radius: 12px;
  font-family: 'Tomato Grotesk', sans-serif;
  font-size: 16px;
  color: #ffffff;
  outline: none;
  transition: border-color 0.2s ease, background-color 0.2s ease;
  box-sizing: border-box;
  -webkit-appearance: none;
  appearance: none;

  &::placeholder {
    color: rgba(185, 176, 255, 0.64);
    font-size: 14px;
  }

  &:focus {
    border-color: #8D67FF;
    box-shadow: 0px 0px 8px 0px rgba(141, 103, 255, 0.3);
  }
}

// 输入框错误状态样式
.form-input-error {
  border-color: #EA3943 !important;
  
  &:focus {
    border-color: #EA3943 !important;
    box-shadow: none;
  }
}

// 错误提示信息样式
.error-message {
  margin-top: 8px;
  font-family: 'Tomato Grotesk', sans-serif;
  font-size: 14px;
  line-height: 22px;
  color: #EA3943;
}

// 密码验证规则提示样式
.password-rules {
  margin-top: 8px;
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.password-rule-item {
  font-family: 'Tomato Grotesk', sans-serif;
  font-size: 14px;
  line-height: 22px;
  color: #EA3943;
}

.password-input-wrapper {
  position: relative;
}

.password-input {
  padding-right: 56px;
}

.password-toggle-btn {
  position: absolute;
  right: 20px;
  top: 50%;
  transform: translateY(-50%);
  width: 20px;
  height: 20px;
  background: transparent;
  border: none;
  cursor: pointer;
  padding: 0;
  display: flex;
  align-items: center;
  justify-content: center;

  img {
    width: 20px;
    height: 20px;
    display: block;
  }
}

// 复选框组样式
.checkbox-group {
  margin-bottom: 24px;
}

.checkbox-label {
  display: flex;
  align-items: flex-start;
  cursor: pointer;
  gap: 12px;
}

.checkbox-input {
  width: 20px;
  height: 20px;
  min-width: 20px;
  margin-top: 2px;
  cursor: pointer;
  accent-color: #7644FB;
  // 自定义复选框样式
  appearance: none;
  background: #302D48;
  border: 1px solid #8D67FF;
  border-radius: 50%;
  position: relative;
  transition: border-color 0.2s ease, background-color 0.2s ease;

  &:checked {
    background: #7644FB;
    border-color: #7644FB;
    
    // 显示勾选标记
    &::after {
      content: '';
      position: absolute;
      left: 6px;
      top: 2px;
      width: 6px;
      height: 10px;
      border: solid #ffffff;
      border-width: 0 2px 2px 0;
      transform: rotate(45deg);
    }
  }

  &:focus {
    outline: none;
    box-shadow: 0px 0px 8px 0px rgba(141, 103, 255, 0.3);
  }
}

.checkbox-text {
  font-family: 'Tomato Grotesk', sans-serif;
  font-size: 12px;
  line-height: 15px;
  color: #ffffff;
  flex: 1;
}

.register-btn {
  width: 100%;
  height: 56px;
  background: #7644FB;
  border: none;
  border-radius: 12px;
  font-family: 'Tomato Grotesk', sans-serif;
  font-size: 16px;
  font-weight: 500;
  color: #EEEDF7;
  cursor: pointer;
  transition: background-color 0.2s ease, transform 0.1s ease;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  flex-shrink: 0;

  &:active:not(:disabled) {
    background: #8D67FF;
    transform: scale(0.98);
  }

  // disabled 状态样式
  &:disabled {
    background: #7644FB;
    color: #EEEDF7;
    cursor: not-allowed;
    opacity: 0.6;
  }
}

// Loading 旋转图标样式
.loading-spinner {
  width: 16px;
  height: 16px;
  border: 2px solid rgba(238, 237, 247, 0.3);
  border-top-color: #EEEDF7;
  border-radius: 50%;
  animation: spin 0.8s linear infinite;
}

// 旋转动画
@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}

.divider {
  display: flex;
  align-items: center;
  margin: 16px 0;
  position: relative;
  flex-shrink: 0;

  &::before,
  &::after {
    content: '';
    flex: 1;
    height: 1px;
    background: #7B73AE;
  }

  &::before {
    margin-right: 16px;
  }

  &::after {
    margin-left: 16px;
  }
}

.divider-text {
  font-family: 'Tomato Grotesk', sans-serif;
  font-size: 16px;
  font-weight: 500;
  line-height: 26px;
  color: #DFDCFF;
}

.google-btn {
  width: 100%;
  height: 56px;
  box-sizing: border-box;
  background: transparent;
  border: 1px solid #7B73AE;
  border-radius: 12px;
  font-family: 'Tomato Grotesk', sans-serif;
  font-size: 14px;
  font-weight: 500;
  color: #DFDCFF;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  transition: border-color 0.2s ease, background-color 0.2s ease, transform 0.1s ease, opacity 0.2s ease;
  flex-shrink: 0;

  &:active:not(:disabled) {
    background: #251A50;
    transform: scale(0.98);
  }

  // disabled 状态样式
  &:disabled {
    cursor: not-allowed;
    opacity: 0.6;
  }
}

.google-icon {
  width: 20px;
  height: 20px;
  display: block;
}

// 法律条款样式
.legal-text {
  margin-top: 24px;
  text-align: center;
  font-family: 'Tomato Grotesk', sans-serif;
  flex-shrink: 0;
}

.legal-text-normal {
  display: block;
  font-size: 14px;
  line-height: 22px;
  color: rgba(201, 195, 255, 0.7);
  margin-bottom: 4px;
}

.legal-links {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 4px;
  flex-wrap: wrap;
}

.legal-link {
  font-size: 14px;
  line-height: 22px;
  color: #B2A7FF;
  text-decoration: none;
  font-weight: 500;
  transition: color 0.2s ease;

  &:active {
    color: #8D67FF;
  }
}

.legal-separator {
  font-size: 14px;
  line-height: 22px;
  color: #B2A7FF;
  margin: 0 2px;
}

// 弹窗淡入淡出动画
.register-fade-enter-active {
  transition: opacity 0.3s ease;
}

.register-fade-leave-active {
  transition: opacity 0.2s ease;
}

.register-fade-enter-from,
.register-fade-leave-to {
  opacity: 0;
}

.register-fade-enter-to,
.register-fade-leave-from {
  opacity: 1;
}

// 邮箱验证弹框样式
.email-verification-modal {
  position: relative;
  width: 100%;
  height: 100vh;
  height: 100dvh; /* 使用动态视口高度，适配移动端浏览器 */
  max-height: 100vh;
  max-height: 100dvh; /* 使用动态视口高度，适配移动端浏览器 */
  background: #1A1625;
  padding: 44px 20px 32px;
  padding-bottom: calc(32px + env(safe-area-inset-bottom)); /* 底部安全区域适配 */
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  align-items: center;
  overflow-y: auto;
  overflow-x: hidden;
  -webkit-overflow-scrolling: touch;
  /* 确保内容可以滚动到底部 */
  overscroll-behavior: contain;
}

// 返回按钮样式
.back-btn {
  position: absolute;
  top: 20px;
  left: 20px;
  width: 24px;
  height: 24px;
  background: transparent;
  border: none;
  cursor: pointer;
  padding: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: opacity 0.2s ease;

  .back-icon {
    width: 24px;
    height: 24px;
    display: block;
  }

  &:active {
    opacity: 0.8;
  }
}

// 邮件图标容器
.email-icon-wrapper {
  margin-top: 20px;
  margin-bottom: 24px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.email-icon {
  width: 85px;
  height: 60px;
  display: block;
  object-fit: contain;
}

// 验证标题样式
.verification-title {
  font-family: 'Tomato Grotesk', sans-serif;
  font-size: 20px;
  font-weight: 600;
  line-height: 28px;
  color: #EEEDF7;
  text-align: center;
  margin: 0 0 24px 0;
}

// 验证说明文字样式
.verification-text {
  font-family: 'Tomato Grotesk', sans-serif;
  font-size: 14px;
  line-height: 22px;
  color: rgba(201, 195, 255, 0.7);
  text-align: center;
  margin: 0 0 32px 0;
}

.email-highlight {
  font-weight: 600;
  color: #ffffff;
}

// 重发邮件按钮样式
.resend-btn {
  width: 100%;
  height: 56px;
  background: #7644FB;
  border: none;
  border-radius: 12px;
  font-family: 'Tomato Grotesk', sans-serif;
  font-size: 16px;
  font-weight: 500;
  color: #EEEDF7;
  cursor: pointer;
  transition: background-color 0.2s ease, transform 0.1s ease, opacity 0.2s ease;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  margin-bottom: 24px;
  flex-shrink: 0;

  &:active:not(:disabled) {
    background: #8D67FF;
    transform: scale(0.98);
  }

  // disabled 状态样式
  &:disabled {
    background: #7644FB;
    color: #EEEDF7;
    cursor: not-allowed;
    opacity: 0.6;
  }
}

// 倒计时文字样式
.countdown-text {
  font-family: 'Tomato Grotesk', sans-serif;
  font-size: 12px;
  line-height: 20px;
  color: #B2A7FF;
  text-align: center;
  margin: 0;
  flex-shrink: 0;
}
</style>
