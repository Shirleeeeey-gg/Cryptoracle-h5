<template>
  <Teleport to="body">
    <Transition name="forgot-pass-fade">
      <div v-if="visible" class="forgot-pass-overlay" @click.self="handleClose">
        <div class="forgot-pass-modal">
          <!-- 第一个标题栏：Log In -->
          <div class="login-header">
            <h2 class="login-title">Log In</h2>
            <button class="close-btn" @click="handleClose">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <rect
                  x="4.02515"
                  y="18.5225"
                  width="20.538"
                  height="2.0538"
                  rx="1.0269"
                  transform="rotate(-45 4.02515 18.5225)"
                  fill="currentColor"
                />
                <rect
                  x="5.23328"
                  y="4.02515"
                  width="20.538"
                  height="2.0538"
                  rx="1.0269"
                  transform="rotate(45 5.23328 4.02515)"
                  fill="currentColor"
                />
              </svg>
            </button>
          </div>

          <!-- 第二个标题栏：Forgot password -->
          <div class="forgot-pass-header">
            <button class="back-btn" @click="handleBack">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M15 18L9 12L15 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
            </button>
            <h2 class="forgot-pass-title">Forgot password</h2>
          </div>

          <!-- 表单内容 -->
          <div class="forgot-pass-content">
            <!-- 说明文字 -->
            <p class="form-description">
              Enter the email address you used when you joined and we'll send you instructions to reset your password.
            </p>
            
            <!-- 邮箱输入框 -->
            <div class="form-group">
              <input
                v-model="email"
                type="email"
                class="form-input"
                :class="{ 'form-input-error': emailError }"
                placeholder="Enter your email address"
                @input="handleInputChange"
                @blur="validateEmail"
              />
              <!-- 错误提示信息 -->
              <div v-if="emailError" class="error-message">Invalid email format.</div>
            </div>
            
            <!-- 提交按钮 -->
            <button 
              type="button" 
              class="submit-btn" 
              :disabled="isLoading || !email.trim()"
              @click="handleSubmit"
            >
              <span v-if="isLoading" class="loading-spinner"></span>
              <span>{{ isLoading ? 'Sending...' : 'Send Password Reset Link' }}</span>
            </button>
          </div>
        </div>
      </div>
    </Transition>

    <!-- 邮件发送成功底部弹出框 -->
    <Transition name="mail-bottom-sheet">
      <div v-if="showMailModal" class="mail-bottom-sheet-overlay" @click.self="handleCloseMailModal">
        <div class="mail-bottom-sheet">
          <!-- 顶部指示条 -->
          <div class="mail-bottom-sheet-handle"></div>

          <!-- 标题 -->
          <h2 class="mail-bottom-sheet-title">You've Got Mail :)</h2>

          <!-- 内容 -->
          <div class="mail-bottom-sheet-content">
            <p class="mail-bottom-sheet-text">
              <span>Instructions have been sent to</span> {{ maskedEmail }}.
            </p>
            <div class="mail-bottom-sheet-list">
              <p class="mail-bottom-sheet-list-item">* If you don't see it in Inbox, try the Junk Mail/Spam folder.</p>
              <p class="mail-bottom-sheet-list-item">Otherwise, make sure you entered the same e-mail address you used to sign in.</p>
            </div>
          </div>

          <!-- 返回登录按钮 -->
          <button class="return-login-btn" @click="handleReturnToLogin">
            Return to login
          </button>
        </div>
      </div>
    </Transition>
  </Teleport>
</template>

<script setup>
import { ref, computed, watch, onUnmounted } from 'vue';
import { forgotPasswordApi } from '@/api/login';

// 定义 props：控制弹窗显示/隐藏
const props = defineProps({
  visible: {
    type: Boolean,
    default: false,
  },
});

// 定义 emits：关闭事件和返回登录事件
const emit = defineEmits(['update:visible', 'close', 'back']);

// 邮箱输入值
const email = ref('');

// 邮箱验证错误状态
const emailError = ref(false);

// 提交加载状态
const isLoading = ref(false);

// 邮件发送成功弹窗显示状态
const showMailModal = ref(false);

// 保存页面滚动位置
let savedScrollTop = 0;

// 禁止页面滚动
const disableBodyScroll = () => {
  savedScrollTop = window.pageYOffset || document.documentElement.scrollTop;
  document.body.style.overflow = 'hidden';
  document.body.style.position = 'fixed';
  document.body.style.top = `-${savedScrollTop}px`;
  document.body.style.width = '100%';
  document.addEventListener('touchmove', preventScroll, { passive: false });
};

// 恢复页面滚动
const enableBodyScroll = () => {
  document.body.style.overflow = '';
  document.body.style.position = '';
  document.body.style.top = '';
  document.body.style.width = '';
  window.scrollTo(0, savedScrollTop);
  document.removeEventListener('touchmove', preventScroll);
};

// 阻止触摸滚动事件
const preventScroll = (e) => {
  e.preventDefault();
};

// 监听 visible 变化，控制页面滚动
watch(
  () => props.visible,
  (newVal) => {
    if (newVal) {
      disableBodyScroll();
    } else {
      enableBodyScroll();
    }
  },
  { immediate: true }
);

// 组件卸载时确保恢复滚动
onUnmounted(() => {
  enableBodyScroll();
});

// 邮箱格式验证函数
const validateEmail = () => {
  const emailValue = email.value.trim();
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  
  if (emailValue === '') {
    emailError.value = false;
    return;
  }
  
  emailError.value = !emailRegex.test(emailValue);
};

// 处理输入变化
const handleInputChange = () => {
  if (emailError.value) {
    emailError.value = false;
  }
};

// 计算部分隐藏的邮箱地址（例如：1***38@qq.com）
const maskedEmail = computed(() => {
  const emailValue = email.value.trim();
  if (!emailValue) return '';
  
  const atIndex = emailValue.indexOf('@');
  if (atIndex === -1) return emailValue;
  
  const localPart = emailValue.substring(0, atIndex);
  const domain = emailValue.substring(atIndex);
  
  if (localPart.length <= 2) {
    return `${localPart[0]}***${domain}`;
  }
  
  const firstChar = localPart[0];
  const lastTwoChars = localPart.slice(-2);
  return `${firstChar}***${lastTwoChars}${domain}`;
});

// 关闭邮件发送成功弹窗
const handleCloseMailModal = () => {
  showMailModal.value = false;
};

// 返回登录弹窗（关闭邮件弹窗并触发返回事件）
const handleReturnToLogin = () => {
  showMailModal.value = false;
  handleClose();
  emit('back');
};

// 处理返回（回到登录弹窗）
const handleBack = () => {
  handleClose();
  emit('back');
};

// 处理关闭
const handleClose = () => {
  email.value = '';
  emailError.value = false;
  showMailModal.value = false;
  emit('update:visible', false);
  emit('close');
};

// 处理表单提交
const handleSubmit = async () => {
  if (isLoading.value) {
    return;
  }
  
  validateEmail();
  if (emailError.value || !email.value.trim()) {
    return;
  }
  
  isLoading.value = true;
  
  try {
    await forgotPasswordApi({
      email: email.value.trim()
    });
    
    showMailModal.value = true;
    
  } catch (error) {
    console.error('Password reset error:', error);
  } finally {
    isLoading.value = false;
  }
};
</script>

<style scoped lang="scss">
.forgot-pass-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  width: 100vw;
  height: 100vh;
  background: rgba(0, 0, 0, 0.6);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 10001;
}

.forgot-pass-modal {
  position: relative;
  width: 100%;
  height: 100vh;
  max-height: 100vh;
  background: #1A1625;
  padding: 20px 20px 32px;
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  overflow-y: auto;
  -webkit-overflow-scrolling: touch;
}

// 第一个标题栏：Log In
.login-header {
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;
  margin-bottom: 0;
  min-height: 44px;
}

.login-title {
  font-family: 'Tomato Grotesk', sans-serif;
  font-size: 16px;
  font-weight: 500;
  line-height: 24px;
  color: #ffffff;
  margin: 0;
  text-align: center;
}

.login-header .close-btn {
  position: absolute;
  right: 0;
  top: 50%;
  transform: translateY(-50%);
  width: 24px;
  height: 24px;
  background: transparent;
  border: none;
  cursor: pointer;
  padding: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #ffffff;
  transition: opacity 0.2s ease;

  svg {
    width: 24px;
    height: 24px;
    display: block;
  }

  &:active {
    opacity: 0.8;
  }
}

// 第二个标题栏：Forgot password
.forgot-pass-header {
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;
  margin-bottom: 32px;
  min-height: 44px;
}

.back-btn {
  position: absolute;
  left: 0;
  top: 50%;
  transform: translateY(-50%);
  width: 24px;
  height: 24px;
  background: transparent;
  border: none;
  cursor: pointer;
  padding: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #ffffff;
  transition: opacity 0.2s ease;

  svg {
    width: 24px;
    height: 24px;
    display: block;
  }

  &:active {
    opacity: 0.8;
  }
}

.forgot-pass-title {
  font-family: 'Tomato Grotesk', sans-serif;
  font-size: 16px;
  font-weight: 500;
  line-height: 24px;
  color: #ffffff;
  margin: 0;
  text-align: center;
}

.forgot-pass-content {
  flex: 1;
  display: flex;
  flex-direction: column;
}

.form-description {
  font-family: 'Tomato Grotesk', sans-serif;
  font-size: 14px;
  font-weight: 500;
  line-height: 22px;
  color: rgba(201, 195, 255, 0.89);
  text-align: left;
  margin: 0 0 24px 0;
}

.form-group {
  margin-bottom: 24px;
}

.form-input {
  width: 100%;
  height: 56px;
  padding: 0 20px;
  background: #1A1625;
  border: 1px solid rgba(178, 167, 255, 0.6);
  border-radius: 12px;
  font-family: 'Tomato Grotesk', sans-serif;
  font-size: 16px;
  color: #ffffff;
  outline: none;
  transition: border-color 0.2s ease, background-color 0.2s ease;
  box-sizing: border-box;
  -webkit-appearance: none;
  appearance: none;

  &::placeholder {
    color: rgba(185, 176, 255, 0.64);
    font-size: 14px;
  }

  &:focus {
    border-color: #8D67FF;
    box-shadow: 0px 0px 8px 0px rgba(141, 103, 255, 0.3);
  }
}

.form-input-error {
  border-color: #EA3943 !important;
  
  &:focus {
    border-color: #EA3943 !important;
    box-shadow: none;
  }
}

.error-message {
  margin-top: 8px;
  font-family: 'Tomato Grotesk', sans-serif;
  font-size: 14px;
  line-height: 22px;
  color: #EA3943;
}

.submit-btn {
  width: 100%;
  height: 56px;
  background: #7644FB;
  border: none;
  border-radius: 12px;
  font-family: 'Tomato Grotesk', sans-serif;
  font-size: 16px;
  font-weight: 500;
  color: #EEEDF7;
  cursor: pointer;
  transition: background-color 0.2s ease, transform 0.1s ease;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  flex-shrink: 0;

  &:active:not(:disabled) {
    background: #8D67FF;
    transform: scale(0.98);
  }

  &:disabled {
    background: #7644FB;
    color: #EEEDF7;
    cursor: not-allowed;
    opacity: 0.6;
  }
}

.loading-spinner {
  width: 16px;
  height: 16px;
  border: 2px solid rgba(238, 237, 247, 0.3);
  border-top-color: #EEEDF7;
  border-radius: 50%;
  animation: spin 0.8s linear infinite;
}

@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}

// 弹窗淡入淡出动画
.forgot-pass-fade-enter-active {
  transition: opacity 0.3s ease;
}

.forgot-pass-fade-leave-active {
  transition: opacity 0.2s ease;
}

.forgot-pass-fade-enter-from,
.forgot-pass-fade-leave-to {
  opacity: 0;
}

.forgot-pass-fade-enter-to,
.forgot-pass-fade-leave-from {
  opacity: 1;
}

// 邮件发送成功底部弹出框样式
.mail-bottom-sheet-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.6);
  z-index: 10002;
  display: flex;
  align-items: flex-end;
  justify-content: center;
}

.mail-bottom-sheet {
  position: relative;
  width: 100%;
  max-width: 100%;
  background: #302D48;
  border-radius: 24px 24px 0 0;
  padding: 16px 20px 32px;
  box-sizing: border-box;
  max-height: 90vh;
  overflow-y: auto;
  -webkit-overflow-scrolling: touch;
}

.mail-bottom-sheet-handle {
  width: 40px;
  height: 4px;
  background: rgba(178, 173, 226, 0.6);
  border-radius: 2px;
  margin: 0 auto 24px;
}

.mail-bottom-sheet-title {
  font-family: 'Tomato Grotesk', sans-serif;
  font-size: 24px;
  font-weight: 700;
  line-height: 32px;
  color: #ffffff;
  text-align: left;
  margin: 0 0 24px 0;
}

.mail-bottom-sheet-content {
  margin-bottom: 24px;
}

.mail-bottom-sheet-text {
  font-family: 'Tomato Grotesk', sans-serif;
  font-size: 14px;
  font-weight: 500;
  line-height: 22px;
  color: #fff;
  margin: 0 0 16px 0;
  
  span {
    color: #B2ADE2;
  }
}

.mail-bottom-sheet-list {
  margin: 0;
  padding: 0;
}

.mail-bottom-sheet-list-item {
  font-family: 'Tomato Grotesk', sans-serif;
  font-size: 14px;
  font-weight: 500;
  line-height: 22px;
  color: #EEEDF7;
  margin: 0 0 8px 0;
  padding: 0;

  &:last-child {
    margin-bottom: 0;
  }
}

.return-login-btn {
  width: 100%;
  height: 56px;
  background: #7644FB;
  border: none;
  border-radius: 12px;
  font-family: 'Tomato Grotesk', sans-serif;
  font-size: 16px;
  font-weight: 500;
  color: #ffffff;
  cursor: pointer;
  transition: background-color 0.2s ease, transform 0.1s ease;
  display: flex;
  align-items: center;
  justify-content: center;

  &:active {
    background: #8D67FF;
    transform: scale(0.98);
  }
}

// 底部弹出框动画
.mail-bottom-sheet-enter-active {
  transition: opacity 0.3s ease;
}

.mail-bottom-sheet-enter-active .mail-bottom-sheet {
  transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}

.mail-bottom-sheet-leave-active {
  transition: opacity 0.2s ease;
}

.mail-bottom-sheet-leave-active .mail-bottom-sheet {
  transition: transform 0.2s cubic-bezier(0.4, 0, 0.2, 1);
}

.mail-bottom-sheet-enter-from {
  opacity: 0;
}

.mail-bottom-sheet-enter-from .mail-bottom-sheet {
  transform: translateY(100%);
}

.mail-bottom-sheet-enter-to {
  opacity: 1;
}

.mail-bottom-sheet-enter-to .mail-bottom-sheet {
  transform: translateY(0);
}

.mail-bottom-sheet-leave-from {
  opacity: 1;
}

.mail-bottom-sheet-leave-from .mail-bottom-sheet {
  transform: translateY(0);
}

.mail-bottom-sheet-leave-to {
  opacity: 0;
}

.mail-bottom-sheet-leave-to .mail-bottom-sheet {
  transform: translateY(100%);
}
</style>
