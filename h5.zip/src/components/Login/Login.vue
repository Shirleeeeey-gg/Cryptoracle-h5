<template>
  <Teleport to="body">
    <Transition name="login-fade">
      <div v-if="visible" class="login-overlay" @click.self="handleClose">
        <div class="login-modal">
          <!-- 关闭按钮 -->
          <button class="close-btn" @click="handleClose">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect
                x="4.02515"
                y="18.5225"
                width="20.538"
                height="2.0538"
                rx="1.0269"
                transform="rotate(-45 4.02515 18.5225)"
                fill="currentColor"
              />
              <rect
                x="5.23328"
                y="4.02515"
                width="20.538"
                height="2.0538"
                rx="1.0269"
                transform="rotate(45 5.23328 4.02515)"
                fill="currentColor"
              />
            </svg>
          </button>

          <!-- 标题 -->
          <h2 class="login-title">Log In</h2>

          <!-- 表单 -->
          <form class="login-form" @submit.prevent="handleSubmit">
            <!-- Email 输入框 -->
            <div class="form-group">
              <label class="form-label">Email Address</label>
              <input
                v-model="formData.email"
                type="email"
                :class="['form-input', { 'form-input-error': emailError }]"
                placeholder="Enter your email address"
                @blur="validateEmail"
              />
              <!-- 错误提示信息 -->
              <div v-if="emailError" class="error-message">{{ emailErrorMsg }}</div>
            </div>

            <!-- Password 输入框 -->
            <div class="form-group">
              <div class="password-label-row">
                <label class="form-label">Password</label>
                <a href="#" class="forgot-password-link" @click.prevent="handleForgotPassword">
                  Forgot password?
                </a>
              </div>
              <div class="password-input-wrapper">
                <input
                  v-model="formData.password"
                  :type="showPassword ? 'text' : 'password'"
                  :class="['form-input', 'password-input', { 'form-input-error': passwordError }]"
                  placeholder="Enter your password"
                  @blur="validatePassword"
                />
                <button
                  type="button"
                  class="password-toggle-btn"
                  @click="togglePasswordVisibility"
                >
                  <img
                    :src="showPassword ? iconEye : iconEyeClose"
                    alt="Toggle password visibility"
                  />
                </button>
              </div>
              <!-- 错误提示信息 -->
              <div v-if="passwordError" class="error-message">Please input your password.</div>
            </div>

            <!-- 登录按钮 -->
            <button type="submit" :disabled="isLoading" class="login-btn">
              <span v-if="isLoading" class="loading-spinner"></span>
              <span>Log In</span>
            </button>
          </form>

          <!-- Sign Up 按钮 -->
          <button type="button" class="signup-btn" @click="handleRegister">
            Sign Up
          </button>

          <!-- 分隔线 -->
          <div class="divider">
            <span class="divider-text">OR</span>
          </div>

          <!-- Google 登录按钮 -->
          <button class="google-btn" @click="handleGoogleLogin" :disabled="isGoogleLoading">
            <span v-if="isGoogleLoading" class="loading-spinner"></span>
            <img v-else src="@/assets/login/icon-google.png" alt="Google" class="google-icon" />
            <span>{{ isGoogleLoading ? 'Connecting...' : 'Continue with Google' }}</span>
          </button>

          <!-- 注册链接 -->
          <div class="register-link">
            <span>Don't have an account?</span>
            <a href="#" class="register-link-text" @click.prevent="handleRegister">
              Create free account
            </a>
          </div>
        </div>
      </div>
    </Transition>

    <!-- 忘记密码弹窗 -->
    <ForgotPass 
      v-model:visible="showForgotPass" 
      @back="handleBackFromForgotPass"
      @close="handleForgotPassClose"
    />
  </Teleport>
</template>

<script setup>
import { ref, defineProps, defineEmits, watch, onUnmounted, nextTick } from 'vue';
import { useRouter } from 'vue-router';
import iconEye from '@/assets/login/icon-eye.svg';
import iconEyeClose from '@/assets/login/icon-eye-close.svg';
import { loginApi } from '@/api/login';
import { sha256 } from '@/utils/encrypto';
import { useUserStore } from '@/store/user';
import { ElMessage } from 'element-plus';
import ForgotPass from './ForgotPass.vue';

// 定义 props：控制弹窗显示/隐藏
const props = defineProps({
  visible: {
    type: Boolean,
    default: false,
  },
});

// 定义 emits：关闭事件和注册事件
const emit = defineEmits(['update:visible', 'close', 'register']);

// 路由实例
const router = useRouter();

// 用户 store 实例
const userStore = useUserStore();

// 表单数据
const formData = ref({
  email: '',
  password: '',
});

// 控制密码显示/隐藏
const showPassword = ref(false);

// 邮箱验证错误状态
const emailError = ref(false);
// 邮箱错误消息
const emailErrorMsg = ref('');

// 密码验证错误状态
const passwordError = ref(false);

// 登录加载状态
const isLoading = ref(false);

// Google 登录加载状态
const isGoogleLoading = ref(false);

// 忘记密码弹窗显示状态
const showForgotPass = ref(false);

// 保存页面滚动位置
let savedScrollTop = 0;

// 禁止页面滚动
const disableBodyScroll = () => {
  // 保存当前滚动位置
  savedScrollTop = window.pageYOffset || document.documentElement.scrollTop;
  
  // 给 body 添加样式禁止滚动
  document.body.style.overflow = 'hidden';
  document.body.style.position = 'fixed';
  document.body.style.top = `-${savedScrollTop}px`;
  document.body.style.width = '100%';
  
  // 阻止移动端触摸滚动
  document.addEventListener('touchmove', preventScroll, { passive: false });
};

// 恢复页面滚动
const enableBodyScroll = () => {
  // 移除禁止滚动的样式
  document.body.style.overflow = '';
  document.body.style.position = '';
  document.body.style.top = '';
  document.body.style.width = '';
  
  // 恢复滚动位置
  window.scrollTo(0, savedScrollTop);
  
  // 移除触摸滚动阻止
  document.removeEventListener('touchmove', preventScroll);
};

// 阻止触摸滚动事件（只阻止弹框外部的滚动，允许弹框内部滚动）
const preventScroll = (e) => {
  // 如果触摸事件发生在弹框内部，允许滚动
  const target = e.target;
  const modal = document.querySelector('.login-modal');
  if (modal && modal.contains(target)) {
    return; // 允许弹框内部滚动
  }
  // 否则阻止滚动
  e.preventDefault();
};

// 监听 visible 变化，控制页面滚动
watch(
  () => props.visible,
  (newVal) => {
    if (newVal) {
      // 弹窗打开时禁止滚动
      disableBodyScroll();
    } else {
      // 弹窗关闭时恢复滚动
      enableBodyScroll();
    }
  },
  { immediate: true }
);

// 组件卸载时确保恢复滚动
onUnmounted(() => {
  enableBodyScroll();
});

// 切换密码显示状态
const togglePasswordVisibility = () => {
  showPassword.value = !showPassword.value;
};

// 邮箱格式验证函数
const validateEmail = () => {
  const email = formData.value.email.trim();
  // 邮箱格式正则表达式
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  
  // 如果邮箱为空，显示错误提示
  if (email === '') {
    emailError.value = true;
    emailErrorMsg.value = 'Please input your email';
    return;
  }
  
  // 验证邮箱格式
  if (!emailRegex.test(email)) {
    emailError.value = true;
    emailErrorMsg.value = 'Invalid email format.';
  } else {
    emailError.value = false;
    emailErrorMsg.value = '';
  }
};

// 密码格式验证函数
const validatePassword = () => {
  const password = formData.value.password.trim();
  
  if (password === '') {
    passwordError.value = true;
  }else{
    passwordError.value = false;
  }
};

// 处理关闭
const handleClose = () => {
  // 清空所有输入框
  formData.value.email = '';
  formData.value.password = '';
  // 清空错误状态
  emailError.value = false;
  emailErrorMsg.value = '';
  passwordError.value = false;
  // 重置密码显示状态
  showPassword.value = false;
  emit('update:visible', false);
  emit('close');
};

// 处理表单提交
const handleSubmit = async () => {
  // 如果正在加载中，不重复提交
  if (isLoading.value) {
    return;
  }
  
  // 验证邮箱和密码格式
  validateEmail();
  validatePassword();
  
  // 如果验证失败，不提交表单
  if (emailError.value || passwordError.value) {
    return;
  }
  
  // 设置加载状态
  isLoading.value = true;
  
  try {
    // 使用 SHA-256 加密密码
    const encryptedPassword = await sha256(formData.value.password);
    
    // 调用登录接口，传递 email 和加密后的 password 参数
    const response = await loginApi({
      email: formData.value.email.trim(),
      password: encryptedPassword
    });
    
    // 登录成功，保存用户信息到 store
    // 新的接口返回格式：response.data 是一个包含用户信息和 token 的对象
    if (response.data) {
      // 如果 response.data 是字符串（旧格式），则只保存 token
      if (typeof response.data === 'string') {
        userStore.setUserInfo({ token: response.data });
      } else {
        // 新格式：response.data 是包含所有用户信息的对象
        userStore.setUserInfo(response.data);
      }
    }
    ElMessage.success('Logged in successfully');
    // 登录成功，关闭弹窗
    handleClose();
    
  } catch (error) {
    // 登录失败，打印错误信息
    console.error('Login error:', error);
    // 错误信息已通过 request.js 中的 ElMessage 显示
  } finally {
    // 无论成功或失败，都重置加载状态
    isLoading.value = false;
  }
};

// 处理忘记密码
const handleForgotPassword = () => {
  // 关闭登录弹窗
  handleClose();
  // 打开忘记密码弹窗
  showForgotPass.value = true;
};

// 处理从忘记密码弹窗返回
const handleBackFromForgotPass = async () => {
  // 关闭忘记密码弹窗
  showForgotPass.value = false;
  // 等待下一个 tick，确保忘记密码弹窗开始关闭动画
  await nextTick();
  // 重新打开登录弹窗
  emit('update:visible', true);
};

// 处理忘记密码弹窗关闭
const handleForgotPassClose = () => {
  showForgotPass.value = false;
};

// 处理注册
const handleRegister = () => {
  // 关闭登录弹窗
  handleClose();
  // 触发注册事件，通知父组件打开注册弹窗
  emit('register');
};

/**
 * 处理 Google 登录
 * 使用 OAuth 2.0 授权码流程进行 Google 登录
 */
const handleGoogleLogin = () => {
  // 如果正在加载中，不重复触发
  if (isGoogleLoading.value) {
    return;
  }

  // 设置加载状态
  isGoogleLoading.value = true;

  try {
    // 从环境变量获取 Google Client ID
    // 需要在 .env 文件中配置 VITE_GOOGLE_CLIENT_ID
    const GOOGLE_CLIENT_ID = import.meta.env.VITE_GOOGLE_CLIENT_ID || '';

    if (!GOOGLE_CLIENT_ID) {
      console.log('Google Client ID 未配置，请联系管理员');
      isGoogleLoading.value = false;
      return;
    }

    // 使用 OAuth 2.0 授权码流程，显示完整的授权同意页面
    // 这种方式会重定向到 Google 授权服务器，显示详细的授权信息
    useOAuth2AuthorizationCodeFlow(GOOGLE_CLIENT_ID);

  } catch (error) {
    console.error('Google login initialization error:', error);
    isGoogleLoading.value = false;
  }
};

/**
 * 使用 OAuth 2.0 授权码流程（Authorization Code Flow）
 * 这种方式会显示完整的授权同意页面，用户可以看到应用请求访问的信息
 * @param {string} clientId - Google Client ID
 */
const useOAuth2AuthorizationCodeFlow = (clientId) => {
  try {
    // 生成随机状态参数，用于防止 CSRF 攻击
    const state = Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
    // 将状态保存到 sessionStorage，用于回调时验证
    sessionStorage.setItem('google_oauth_state', state);
    // 保存 client_id，用于回调时换取 token
    sessionStorage.setItem('google_oauth_client_id', clientId);
    
    // 构建授权 URL
    // 使用授权码流程（response_type=code），这会显示完整的授权同意页面
    // const redirectUri = window.location.origin;
    const redirectUri = 'https://www.cryptoracle.network';
    const scope = 'openid email profile';
    const authUrl = `https://accounts.google.com/o/oauth2/v2/auth?` +
      `client_id=${encodeURIComponent(clientId)}` +
      `&redirect_uri=${encodeURIComponent(redirectUri)}` +
      `&response_type=code` +
      `&scope=${encodeURIComponent(scope)}` +
      `&state=${encodeURIComponent(state)}` +
      `&access_type=offline` +
      `&prompt=consent`; // 强制显示同意页面，即使之前已授权
    
    // 重定向到 Google 授权服务器
    window.location.href = authUrl;
    
  } catch (error) {
    console.error('OAuth2 authorization code flow error:', error);
    isGoogleLoading.value = false;
  }
};
</script>

<style scoped lang="scss">
.login-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  width: 100vw;
  height: 100vh;
  height: 100dvh; /* 使用动态视口高度，适配移动端浏览器 */
  background: rgba(0, 0, 0, 0.6);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 10000;
}

.login-modal {
  position: relative;
  width: 100%;
  height: 100vh;
  height: 100dvh; /* 使用动态视口高度，适配移动端浏览器 */
  max-height: 100vh;
  max-height: 100dvh; /* 使用动态视口高度，适配移动端浏览器 */
  background: #1A1625;
  padding: 20px 20px 32px;
  padding-bottom: calc(32px + env(safe-area-inset-bottom)); /* 底部安全区域适配 */
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  overflow-y: auto;
  overflow-x: hidden;
  -webkit-overflow-scrolling: touch;
  /* 确保内容可以滚动到底部 */
  overscroll-behavior: contain;
}

.close-btn {
  position: absolute;
  top: 20px;
  right: 20px;
  width: 24px;
  height: 24px;
  background: transparent;
  border: none;
  cursor: pointer;
  padding: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #ffffff;
  transition: opacity 0.2s ease;

  svg {
    width: 24px;
    height: 24px;
    display: block;
  }

  &:active {
    opacity: 0.8;
  }
}

.login-title {
  font-family: 'Tomato Grotesk', sans-serif;
  font-size: 28px;
  font-weight: 600;
  line-height: 36px;
  color: #ffffff;
  text-align: center;
  margin: 0 0 32px 0;
}

.login-form {
  margin-bottom: 0;
  flex-shrink: 0;
}

.form-group {
  margin-bottom: 16px;
}

.form-label {
  display: block;
  font-family: 'Tomato Grotesk', sans-serif;
  font-size: 14px;
  line-height: 18px;
  font-weight: 500;
  color: #ffffff;
  margin-bottom: 8px;
}

.password-label-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 8px;
}

.forgot-password-link {
  font-family: 'Tomato Grotesk', sans-serif;
  font-size: 14px;
  line-height: 22px;
  font-weight: 500;
  color: #B2A7FF;
  text-decoration: none;
  transition: color 0.2s ease;
  
  &:active {
    color: #8D67FF;
  }
}

.form-input {
  width: 100%;
  height: 56px;
  padding: 0 20px;
  background: #302D48;
  border: 1px solid #8D67FF;
  border-radius: 12px;
  font-family: 'Tomato Grotesk', sans-serif;
  font-size: 16px;
  color: #ffffff;
  outline: none;
  transition: border-color 0.2s ease, background-color 0.2s ease;
  box-sizing: border-box;
  -webkit-appearance: none;
  appearance: none;

  &::placeholder {
    color: rgba(185, 176, 255, 0.64);
    font-size: 14px;
  }

  &:focus {
    border-color: #8D67FF;
    box-shadow: 0px 0px 8px 0px rgba(141, 103, 255, 0.3);
  }
}

// 输入框错误状态样式
.form-input-error {
  border-color: #EA3943 !important;
  
  &:focus {
    border-color: #EA3943 !important;
    box-shadow: none;
  }
}

// 错误提示信息样式
.error-message {
  margin-top: 8px;
  font-family: 'Tomato Grotesk', sans-serif;
  font-size: 14px;
  line-height: 22px;
  color: #EA3943;
}

.password-input-wrapper {
  position: relative;
}

.password-input {
  padding-right: 56px;
}

.password-toggle-btn {
  position: absolute;
  right: 20px;
  top: 50%;
  transform: translateY(-50%);
  width: 20px;
  height: 20px;
  background: transparent;
  border: none;
  cursor: pointer;
  padding: 0;
  display: flex;
  align-items: center;
  justify-content: center;

  img {
    width: 20px;
    height: 20px;
    display: block;
  }
}

.login-btn {
  width: 100%;
  height: 56px;
  background: #7644FB;
  border: none;
  border-radius: 12px;
  font-family: 'Tomato Grotesk', sans-serif;
  font-size: 16px;
  font-weight: 500;
  color: #EEEDF7;
  cursor: pointer;
  transition: background-color 0.2s ease, transform 0.1s ease;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  flex-shrink: 0;

  &:active:not(:disabled) {
    background: #8D67FF;
    transform: scale(0.98);
  }

  // disabled 状态样式
  &:disabled {
    background: #7644FB;
    color: #EEEDF7;
    cursor: not-allowed;
    opacity: 0.6;
  }
}

.signup-btn {
  width: 100%;
  height: 56px;
  box-sizing: border-box;
  background: transparent;
  border: 1px solid #8D67FF;
  border-radius: 12px;
  font-family: 'Tomato Grotesk', sans-serif;
  font-size: 16px;
  font-weight: 500;
  color: #ffffff;
  cursor: pointer;
  transition: border-color 0.2s ease, background-color 0.2s ease, transform 0.1s ease;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  margin-top: 16px;

  &:active {
    background: #251A50;
    transform: scale(0.98);
  }
}

// Loading 旋转图标样式
.loading-spinner {
  width: 16px;
  height: 16px;
  border: 2px solid rgba(238, 237, 247, 0.3);
  border-top-color: #EEEDF7;
  border-radius: 50%;
  animation: spin 0.8s linear infinite;
}

// 旋转动画
@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}

.divider {
  display: flex;
  align-items: center;
  margin: 16px 0;
  position: relative;
  flex-shrink: 0;

  &::before,
  &::after {
    content: '';
    flex: 1;
    height: 1px;
    background: #7B73AE;
  }

  &::before {
    margin-right: 16px;
  }

  &::after {
    margin-left: 16px;
  }
}

.divider-text {
  font-family: 'Tomato Grotesk', sans-serif;
  font-size: 16px;
  font-weight: 500;
  line-height: 26px;
  color: #DFDCFF;
}

.google-btn {
  width: 100%;
  height: 56px;
  box-sizing: border-box;
  background: transparent;
  border: 1px solid #7B73AE;
  border-radius: 12px;
  font-family: 'Tomato Grotesk', sans-serif;
  font-size: 14px;
  font-weight: 500;
  color: #DFDCFF;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  transition: border-color 0.2s ease, background-color 0.2s ease, transform 0.1s ease, opacity 0.2s ease;
  flex-shrink: 0;

  &:active:not(:disabled) {
    background: #251A50;
    transform: scale(0.98);
  }

  // disabled 状态样式
  &:disabled {
    cursor: not-allowed;
    opacity: 0.6;
  }
}

.google-icon {
  width: 20px;
  height: 20px;
  display: block;
}

.register-link {
  margin-top: 24px;
  text-align: center;
  font-family: 'Tomato Grotesk', sans-serif;
  font-size: 14px;
  line-height: 22px;
  color: #ffffff;
  flex-shrink: 0;

  .register-link-text {
    color: #B2A7FF;
    text-decoration: none;
    font-weight: 500;
    transition: color 0.2s ease;

    &:active {
      color: #8D67FF;
    }
  }
}

// 弹窗淡入淡出动画
.login-fade-enter-active {
  transition: opacity 0.3s ease;
}

.login-fade-leave-active {
  transition: opacity 0.2s ease;
}

.login-fade-enter-from,
.login-fade-leave-to {
  opacity: 0;
}

.login-fade-enter-to,
.login-fade-leave-from {
  opacity: 1;
}
</style>
