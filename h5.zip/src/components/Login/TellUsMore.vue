<template>
  <Transition name="tellusmore-fade">
    <div 
      v-if="visible" 
      class="tellusmore-overlay" 
      ref="overlayRef"
    >
      <div class="tellusmore-modal" ref="modalRef" @click.stop>
        <!-- 拖拽把手 -->
        <div class="tellusmore-handle"></div>
        
        <h2 class="modal-title">Tell Us More</h2>

        <div class="field">
          <label class="field-label">* What's your role?</label>
          <div
            class="select-trigger"
            :class="{ open: activeDropdown === 'role' }"
            @click="toggleDropdown('role')"
          >
            <span class="select-value">{{ formData.role || 'Select...' }}</span>
            <span class="arrow" />
          </div>
          <ul v-if="activeDropdown === 'role'" class="options-list">
            <li
              v-for="option in roleOptions"
              :key="option"
              class="option-item"
              :class="{ active: formData.role === option }"
              @click.stop="selectOption('role', option)"
            >
              {{ option }}
            </li>
          </ul>
        </div>

        <div class="field">
          <label class="field-label">How did you hear about cryptoracle?</label>
          <div
            class="select-trigger"
            :class="{ open: activeDropdown === 'source' }"
            @click="toggleDropdown('source')"
          >
            <span class="select-value">{{ formData.source || 'Select...' }}</span>
            <span class="arrow" />
          </div>
          <ul v-if="activeDropdown === 'source'" class="options-list">
            <li
              v-for="option in sourceOptions"
              :key="option"
              class="option-item"
              :class="{ active: formData.source === option }"
              @click.stop="selectOption('source', option)"
            >
              {{ option }}
            </li>
          </ul>
        </div>

        <div class="field">
          <label class="field-label">How to contact you?</label>
          <!-- 联系方式输入容器：统一边框，包含输入框和下拉选择器 -->
          <div 
            class="contact-container"
            :class="{ 
              'has-focus': contactFocused || activeDropdown === 'contact',
              'has-value': formData.contactValue
            }"
          >
            <input
              v-model="formData.contactValue"
              class="contact-input"
              :placeholder="contactPlaceholder"
              @focus="contactFocused = true"
              @blur="contactFocused = false"
            />
            <div
              class="contact-select"
              :class="{ open: activeDropdown === 'contact' }"
              @click="toggleDropdown('contact')"
            >
              <img
                v-if="currentContact?.icon"
                :src="currentContact.icon"
                alt=""
                class="contact-icon"
              />
              <span class="contact-label">{{ currentContact?.label || 'Select' }}</span>
              <span class="arrow" />
            </div>
            <!-- 下拉菜单：在容器外部展开 -->
            <ul v-if="activeDropdown === 'contact'" class="options-list contact-options">
              <li
                v-for="option in contactOptions"
                :key="option.label"
                class="option-item contact-option"
                :class="{ active: formData.contactMethod === option.label }"
                @click.stop="selectOption('contact', option.label)"
              >
                <img :src="option.icon" alt="" class="contact-icon" />
                <span>{{ option.label }}</span>
                <!-- 选中状态显示对勾图标 -->
                <img
                  v-if="formData.contactMethod === option.label"
                  src="@/assets/project/icon-check.svg"
                  alt=""
                  class="check-icon"
                />
              </li>
            </ul>
          </div>
        </div>

        <button 
          class="submit-btn" 
          :disabled="isSubmitting"
          @click="handleSubmit"
        >
          <span v-if="isSubmitting" class="loading-spinner"></span>
          <span>{{ isSubmitting ? 'Submitting...' : 'Get Started' }}</span>
        </button>
      </div>
    </div>
  </Transition>
</template>

<script setup>
import { computed, defineEmits, defineProps, onBeforeUnmount, onMounted, ref, watch } from 'vue';
import { ElMessage } from 'element-plus';
import { collectUserMoreInfoApi,saveUserTellUsMoreApi } from '@/api/login';
import iconPhone from '@/assets/login/icon-phone.svg';
import iconTg from '@/assets/login/icon-tg.svg';
import { useRoute } from 'vue-router';
import { useUserStore } from '@/store/user';

const userStore = useUserStore();
const props = defineProps({
  visible: {
    type: Boolean,
    default: false,
  },
  from: {
    type: String,
    default: '',
  },
});

const route = useRoute();

const emit = defineEmits(['update:visible', 'submit']);

const roleOptions = [
  'Founder / business owner',
  'Retail Traders/Retail Investors',
  'Quantitative agency',
  'Personal studio',
  'Web3 Builder',
  'Other',
];

const sourceOptions = [
  'Binance',
  'X',
  'PANews',
  'MEtaera',
  'YouTube',
  'Friend / colleague',
  'Newsletter',
  'Other',
];

const contactOptions = [
  { label: 'Telephone', icon: iconPhone },
  { label: 'Telegram', icon: iconTg },
];

const formData = ref({
  role: '',
  source: '',
  contactMethod: 'Telegram',
  contactValue: '',
});

const activeDropdown = ref('');
const overlayRef = ref(null);
const modalRef = ref(null);
const contactFocused = ref(false); // 输入框焦点状态
const isSubmitting = ref(false); // 提交按钮 loading 状态

// 根据当前联系类型动态提示
// 如果未选择联系方式，显示初始提示；否则根据选择的类型显示对应提示
const contactPlaceholder = computed(() => {
  if (!formData.value.contactMethod || formData.value.contactMethod === 'Select') {
    return 'Select contact information...';
  }
  return formData.value.contactMethod === 'Telephone'
    ? 'Enter phone number...'
    : 'Enter username telegram...';
});

const currentContact = computed(() =>
  contactOptions.find((item) => item.label === formData.value.contactMethod),
);

function toggleDropdown(key) {
  activeDropdown.value = activeDropdown.value === key ? '' : key;
}

function selectOption(key, value) {
  if (key === 'role') {
    formData.value.role = value;
  } else if (key === 'source') {
    formData.value.source = value;
  } else if (key === 'contact') {
    formData.value.contactMethod = value;
  }
  activeDropdown.value = '';
}

/**
 * 提交表单：调用收集用户更多信息接口
 * 在接口调用过程中保持 loading 状态，防止重复提交
 */
async function handleSubmit() {
  // 如果正在提交中，直接返回，防止重复点击
  if (isSubmitting.value) {
    return;
  }

  if(props.from == 'mail'){   //普通邮箱注册
    const cocode = route.query.cocode;
    // 校验必填字段：userRole 是必填的
    if (!formData.value.role || formData.value.role.trim() === '') {
      ElMessage.error('Please select your role');
      return;
    }

    // 设置 loading 状态
    isSubmitting.value = true;

    try {
      // 构建请求参数
      const params = {
        code: cocode, 
        userRole: formData.value.role, // 必填字段
        about: formData.value.source || '', // 可选字段，如果没有值则传空字符串
      };

      // 根据联系方式类型，添加对应的字段
      if (formData.value.contactMethod === 'Telegram') {
        // 如果选择的是 Telegram，添加 telegramOne 字段
        params.telegramOne = formData.value.contactValue || '';
      } else if (formData.value.contactMethod === 'Telephone') {
        // 如果选择的是 Telephone，添加 telephone 字段
        params.telephone = formData.value.contactValue || '';
      }

      // 调用 API 接口
      await collectUserMoreInfoApi(params);

      // 提交成功后，触发 submit 事件
      emit('submit', { ...formData.value });
      
      // 显示成功提示
      ElMessage.success('Information submitted successfully');
    } catch (error) {
      // 提交失败，显示错误提示
      console.error('Submit error:', error);
    } finally {
      // 无论成功还是失败，都要取消 loading 状态
      isSubmitting.value = false;
    }
  }else{ //谷歌快捷注册
    // 校验必填字段：userRole 是必填的
    if (!formData.value.role || formData.value.role.trim() === '') {
      ElMessage.error('Please select your role');
      return;
    }

    // 设置 loading 状态
    isSubmitting.value = true;

    try{
      // 构建请求参数
      const params = {
        userId: userStore.userId, 
        userRole: formData.value.role, // 必填字段
        about: formData.value.source || '', // 可选字段，如果没有值则传空字符串
      };

      // 根据联系方式类型，添加对应的字段
      if (formData.value.contactMethod === 'Telegram') {
        // 如果选择的是 Telegram，添加 telegramOne 字段
        params.telegramOne = formData.value.contactValue || '';
      } else if (formData.value.contactMethod === 'Telephone') {
        // 如果选择的是 Telephone，添加 telephone 字段
        params.telephone = formData.value.contactValue || '';
      }
      await saveUserTellUsMoreApi(params);
      // 提交成功后，触发 submit 事件
      emit('submit', { ...formData.value });
      
      // 显示成功提示
      ElMessage.success('Information submitted successfully');
    } catch (error) {
      console.error('Submit error:', error);
    } finally {
      // 无论成功还是失败，都要取消 loading 状态
      isSubmitting.value = false;
    }
  }
}

function handleClose() {
  emit('update:visible', false);
}

// 关闭下拉：监听点击外部区域
function handleDocumentClick(event) {
  const target = event.target;
  if (!modalRef.value || modalRef.value.contains(target)) return;
  activeDropdown.value = '';
}

// 保存滚动位置，用于恢复
let scrollPosition = 0;

/**
 * 禁止页面滚动
 * 当弹框显示时，使用 position: fixed 固定页面并保存滚动位置
 */
function disableBodyScroll() {
  // 保存当前滚动位置
  scrollPosition = window.pageYOffset || document.documentElement.scrollTop;
  // 禁用滚动
  document.documentElement.style.overflow = 'hidden';
  document.body.style.overflow = 'hidden';
  // 使用 position: fixed 固定页面位置
  document.documentElement.style.position = 'fixed';
  document.documentElement.style.top = `-${scrollPosition}px`;
  document.documentElement.style.width = '100%';
}

/**
 * 恢复页面滚动
 * 当弹框隐藏时，恢复所有样式并滚动到之前的位置
 */
function enableBodyScroll() {
  // 恢复滚动样式
  document.documentElement.style.overflow = '';
  document.body.style.overflow = '';
  document.documentElement.style.position = '';
  document.documentElement.style.top = '';
  document.documentElement.style.width = '';
  // 恢复滚动位置
  window.scrollTo(0, scrollPosition);
}

// 监听 visible 变化，控制页面滚动
watch(() => props.visible, (newVal) => {
  if (newVal) {
    // 弹框显示时，禁止页面滚动
    disableBodyScroll();
  } else {
    // 弹框隐藏时，恢复页面滚动
    enableBodyScroll();
  }
}, { immediate: true });

onMounted(() => {
  document.addEventListener('click', handleDocumentClick);
  // 如果组件挂载时弹框已经显示，则禁止滚动
  if (props.visible) {
    disableBodyScroll();
  }
});

onBeforeUnmount(() => {
  document.removeEventListener('click', handleDocumentClick);
  // 组件卸载时，确保恢复页面滚动
  enableBodyScroll();
});
</script>

<style scoped>
/* 过渡动画 */
.tellusmore-fade-enter-active,
.tellusmore-fade-leave-active {
  transition: opacity 0.3s ease;
}

.tellusmore-fade-enter-active .tellusmore-modal,
.tellusmore-fade-leave-active .tellusmore-modal {
  transition: transform 0.3s ease;
}

.tellusmore-fade-enter-from,
.tellusmore-fade-leave-to {
  opacity: 0;
}

.tellusmore-fade-enter-from .tellusmore-modal,
.tellusmore-fade-leave-to .tellusmore-modal {
  transform: translateY(100%);
}

/* 遮罩层 */
.tellusmore-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: flex-end;
  justify-content: center;
  z-index: 1000;
}

/* 弹框主体 */
.tellusmore-modal {
  width: 100%;
  max-width: 100%;
  background: #1F1C33;
  border-radius: 20px 20px 0 0;
  padding: 0 24px 32px 24px;
  box-sizing: border-box;
  max-height: 85vh;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  box-shadow: 0 -4px 20px rgba(0, 0, 0, 0.3);
  color: #EEEDF7;
}

/* 拖拽把手 */
.tellusmore-handle {
  width: 40px;
  height: 4px;
  background: #474269;
  border-radius: 2px;
  margin: 12px auto 20px;
  flex-shrink: 0;
}

/* 标题 */
.modal-title {
  font-size: 24px;
  line-height: 32px;
  margin: 0 0 20px 0;
  font-weight: 500;
  text-align: left;
  color: #EEEDF7;
}

/* 表单项 */
.field {
  margin-bottom: 20px;
  position: relative;
}

.field-label {
  display: block;
  margin-bottom: 8px;
  font-size: 14px;
  font-weight: 500;
  line-height: 22px;
  color: #ffffff;
}

/* 下拉选择触发器 */
.select-trigger {
  height: 48px;
  padding: 0 16px;
  border-radius: 12px;
  background: #1F1C33;
  border: 1px solid #474269;
  display: flex;
  align-items: center;
  justify-content: space-between;
  cursor: pointer;
  transition: border 0.2s ease, box-shadow 0.2s ease;
}

.select-trigger:active,
.select-trigger.open {
  border-color: #8D67FF;
  box-shadow: 0px 0px 8px 0px #604E9E80;
}

.select-value {
  color: #cfc9ec;
  font-size: 14px;
}

.arrow {
  width: 14px;
  height: 14px;
  background-color: #ffffff;
  mask: url('@/assets/login/icon-down.svg') center/contain no-repeat;
  -webkit-mask: url('@/assets/login/icon-down.svg') center/contain no-repeat;
  transition: transform 0.2s ease;
  flex-shrink: 0;
}

.select-trigger.open .arrow,
.contact-select.open .arrow {
  transform: rotate(180deg);
}

/* 下拉选项列表 */
.options-list {
  padding: 8px 6px;
  list-style: none;
  background: #0f0c1e;
  border: 1px solid #433c6a;
  border-radius: 12px;
  max-height: 200px;
  overflow-y: auto;
  box-shadow: 0 16px 40px rgba(0, 0, 0, 0.4);
  position: absolute;
  width: 100%;
  z-index: 10;
  margin-top: 4px;
}

.option-item {
  padding: 12px 12px;
  border-radius: 10px;
  color: #cfc9ec;
  cursor: pointer;
  transition: background 0.2s ease, color 0.2s ease;
  font-size: 14px;
}

.option-item:active {
  background: #2b2545;
  color: #ffffff;
}

.option-item.active {
  background: #2b2545;
  color: #ffffff;
}

/* 联系方式容器 */
.contact-container {
  position: relative;
  display: flex;
  align-items: center;
  border-radius: 12px;
  border: 1px solid #433c6a;
  background: #19152e;
  transition: border-color 0.2s ease, box-shadow 0.2s ease;
  overflow: visible;
  min-height: 48px;
}

.contact-container.has-focus {
  border-color: #8D67FF;
  box-shadow: 0px 0px 8px 0px rgba(141, 103, 255, 0.5);
}

/* 联系方式输入框 */
.contact-input {
  height: 48px;
  padding: 0 16px;
  border: none;
  background: transparent;
  color: #EEEDF7;
  font-size: 14px;
  outline: none;
  width:144px;
}

.contact-input::placeholder {
  color: rgba(207, 201, 236, 0.5);
  font-size: 14px;
}

/* 联系方式下拉选择器 */
.contact-select {
  height: 48px;
  padding: 0 12px 0 10px;
  display: flex;
  align-items: center;
  gap: 8px;
  cursor: pointer;
  border-left: 1px solid rgba(67, 60, 106, 0.5);
  transition: background 0.2s ease;
}

.contact-select:active {
  background: rgba(255, 255, 255, 0.05);
}

.contact-icon {
  width: 20px;
  height: 20px;
  flex-shrink: 0;
}

.contact-label {
  color: #ffffff;
  font-weight: 600;
  font-size: 14px;
  white-space: nowrap;
}

/* 联系方式下拉菜单 */
.contact-options {
  position: absolute;
  top: calc(100% + 8px);
  right: 0;
  width: 160px;
  margin-top: 0;
  z-index: 20;
  background: #151020;
}

.contact-option {
  display: flex;
  align-items: center;
  gap: 8px;
  position: relative;
}

.check-icon {
  width: 14px;
  height: 14px;
  margin-left: auto;
  flex-shrink: 0;
}

/* 提交按钮 */
.submit-btn {
  width: 100%;
  height: 48px;
  border: none;
  border-radius: 12px;
  background: #7644FB;
  color: #ffffff;
  font-size: 16px;
  font-weight: 700;
  cursor: pointer;
  transition: opacity 0.2s ease, transform 0.2s ease;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  margin-top: 8px;
}

.submit-btn:active:not(:disabled) {
  transform: scale(0.98);
  opacity: 0.9;
}

.submit-btn:disabled {
  cursor: not-allowed;
  opacity: 0.7;
  transform: none;
}

/* Loading spinner */
.loading-spinner {
  width: 16px;
  height: 16px;
  border: 2px solid rgba(255, 255, 255, 0.3);
  border-top-color: #ffffff;
  border-radius: 50%;
  animation: spin 0.8s linear infinite;
}

@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}
</style>
