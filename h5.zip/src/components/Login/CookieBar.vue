<template>
  <Transition name="cookie-slide-up">
    <div v-if="showCookieBar" class="cookie-bar">
      <div class="cookie-content">
        <div class="cookie-text">
          We use cookies to enhance your experience and measure site performance. Read our
          <a href="#" class="cookie-policy-link" @click.prevent="handlePolicyClick">
            cookie policy
          </a>.
        </div>
        <div class="cookie-buttons">
          <button class="btn-reject" @click="handleReject">
            Reject all
          </button>
          <button class="btn-accept" @click="handleAccept">
            Accept cookies
          </button>
        </div>
      </div>
    </div>
  </Transition>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import { useRouter } from 'vue-router';
const router = useRouter();
// 控制 cookie 提示条的显示/隐藏
const showCookieBar = ref(false);

// 检查是否已经接受或拒绝过 cookies
const checkCookieConsent = () => {
  const consent = localStorage.getItem('cookieConsent');
  // 如果没有存储过 consent，则显示提示条
  return !consent;
};

// 处理接受 cookies
const handleAccept = () => {
  localStorage.setItem('cookieConsent', 'accepted');
  showCookieBar.value = false;
};

// 处理拒绝 cookies
const handleReject = () => {
  localStorage.setItem('cookieConsent', 'rejected');
  showCookieBar.value = false;
};

// 处理 cookie policy 链接点击
const handlePolicyClick = () => {
  router.push({ name: 'cookie-notice' });
};

// 组件挂载时检查是否需要显示
onMounted(() => {
  if (checkCookieConsent()) {
    // 延迟显示，让页面先渲染完成
    setTimeout(() => {
      showCookieBar.value = true;
    }, 500);
  }
});
</script>

<style scoped lang="scss">
.cookie-bar {
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  z-index: 9;
  padding: 16px;
  box-sizing: border-box;
}

.cookie-content {
  display: flex;
  flex-direction: column;
  gap: 16px;
  padding: 20px;
  background: rgba(47, 44, 71, 0.95);
  border-radius: 16px;
  backdrop-filter: blur(30px);
  box-shadow: 0px -4px 12px 0px rgba(0, 0, 0, 0.2);
  font-family: 'Tomato Grotesk', sans-serif;
  font-weight: 500;
  font-size: 14px;
  line-height: 22px;
  color: #fff;
}

.cookie-text {
  text-align: left;
}

.cookie-policy-link {
  color: rgba(255, 255, 255, 0.9);
  text-decoration: underline;
  text-underline-offset: 2px;
  cursor: pointer;
  transition: color 0.2s ease;
  
  &:active {
    color: rgba(136, 109, 255, 1);
  }
}

.cookie-buttons {
  display: flex;
  align-items: center;
  gap: 12px;
  flex-shrink: 0;
}

.btn-reject,
.btn-accept {
  flex: 1;
  height: 48px;
  border-radius: 12px;
  font-family: 'Tomato Grotesk', sans-serif;
  font-size: 16px;
  font-weight: 500;
  box-sizing: border-box;
  cursor: pointer;
  transition: background-color 0.2s ease, transform 0.1s ease;
  border: none;
  
  &:active {
    transform: scale(0.98);
  }
}

.btn-reject {
  background: rgba(47, 44, 71, 0.8);
  color: #fff;
  border: 1px solid rgba(178, 167, 255, 0.2);
}

.btn-accept {
  background: #ffffff;
  color: #7644FB;
}

// 从底部弹出的动画效果
.cookie-slide-up-enter-active {
  transition: all 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94);
}

.cookie-slide-up-leave-active {
  transition: all 0.3s cubic-bezier(0.55, 0.06, 0.68, 0.19);
}

.cookie-slide-up-enter-from {
  opacity: 0;
  transform: translateY(100%);
}

.cookie-slide-up-leave-to {
  opacity: 0;
  transform: translateY(100%);
}

.cookie-slide-up-enter-to,
.cookie-slide-up-leave-from {
  opacity: 1;
  transform: translateY(0);
}
</style>
