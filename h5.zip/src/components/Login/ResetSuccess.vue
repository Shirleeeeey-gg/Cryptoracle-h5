<template>
  <Teleport to="body">
    <Transition name="success-bottom-sheet">
      <div v-if="visible" class="success-bottom-sheet-overlay" @click.self="handleClose">
        <div class="success-bottom-sheet">
          <!-- 顶部指示条 -->
          <div class="success-bottom-sheet-handle"></div>

          <!-- 成功图标和标题区域 -->
          <div class="success-bottom-sheet-header">
            <img :src="iconSuccess" alt="Success" class="success-icon" />
            <h2 class="success-bottom-sheet-title">Reset successful</h2>
          </div>

          <!-- 描述内容区域 -->
          <div class="success-bottom-sheet-content">
            <p class="success-bottom-sheet-text">
              Your new password has been saved. Try signing in with your new password now.
            </p>
          </div>

          <!-- 跳转登录按钮 -->
          <button class="signin-btn" @click="handleSignIn">
            Sign in
          </button>
        </div>
      </div>
    </Transition>
  </Teleport>
</template>

<script setup>
import { defineProps, defineEmits } from 'vue';
import iconSuccess from '@/assets/login/icon-success.svg';

// 接收父组件传入的可见性控制
const props = defineProps({
  visible: {
    type: Boolean,
    default: false,
  },
});

// 对外暴露的事件：close（关闭弹窗）、sign-in（跳转登录）
const emit = defineEmits(['close', 'sign-in']);

// 处理关闭按钮点击事件
const handleClose = () => {
  emit('close');
};

// 处理"Sign in"按钮点击事件
const handleSignIn = () => {
  emit('sign-in');
};
</script>

<style scoped lang="scss">
// 底部弹出框遮罩层样式
.success-bottom-sheet-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.6);
  z-index: 10002;
  display: flex;
  align-items: flex-end;
  justify-content: center;
}

// 底部弹出框主体样式
.success-bottom-sheet {
  position: relative;
  width: 100%;
  max-width: 100%;
  background: #302D48;
  border-radius: 24px 24px 0 0;
  padding: 16px 20px 32px;
  box-sizing: border-box;
  max-height: 90vh;
  overflow-y: auto;
  -webkit-overflow-scrolling: touch;
}

// 顶部指示条（拖拽手柄）
.success-bottom-sheet-handle {
  width: 40px;
  height: 4px;
  background: rgba(178, 173, 226, 0.6);
  border-radius: 2px;
  margin: 0 auto 24px;
}

// 成功图标和标题区域
.success-bottom-sheet-header {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 24px;
}

.success-icon {
  width: 32px;
  height: 32px;
  display: block;
  flex-shrink: 0;
}

.success-bottom-sheet-title {
  font-family: 'Tomato Grotesk', sans-serif;
  font-size: 24px;
  font-weight: 700;
  line-height: 32px;
  color: #ffffff;
  text-align: left;
  margin: 0;
}

// 描述内容区域
.success-bottom-sheet-content {
  margin-bottom: 24px;
}

.success-bottom-sheet-text {
  font-family: 'Tomato Grotesk', sans-serif;
  font-size: 14px;
  font-weight: 500;
  line-height: 22px;
  color: #EEEDF7;
  margin: 0;
}

// 登录按钮样式
.signin-btn {
  width: 100%;
  height: 56px;
  background: #7644FB;
  border: none;
  border-radius: 12px;
  font-family: 'Tomato Grotesk', sans-serif;
  font-size: 16px;
  font-weight: 500;
  color: #ffffff;
  cursor: pointer;
  transition: background-color 0.2s ease, transform 0.1s ease;
  display: flex;
  align-items: center;
  justify-content: center;

  &:active {
    background: #8D67FF;
    transform: scale(0.98);
  }
}

// 底部弹出框动画
.success-bottom-sheet-enter-active {
  transition: opacity 0.3s ease;
}

.success-bottom-sheet-enter-active .success-bottom-sheet {
  transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}

.success-bottom-sheet-leave-active {
  transition: opacity 0.2s ease;
}

.success-bottom-sheet-leave-active .success-bottom-sheet {
  transition: transform 0.2s cubic-bezier(0.4, 0, 0.2, 1);
}

.success-bottom-sheet-enter-from {
  opacity: 0;
}

.success-bottom-sheet-enter-from .success-bottom-sheet {
  transform: translateY(100%);
}

.success-bottom-sheet-enter-to {
  opacity: 1;
}

.success-bottom-sheet-enter-to .success-bottom-sheet {
  transform: translateY(0);
}

.success-bottom-sheet-leave-from {
  opacity: 1;
}

.success-bottom-sheet-leave-from .success-bottom-sheet {
  transform: translateY(0);
}

.success-bottom-sheet-leave-to {
  opacity: 0;
}

.success-bottom-sheet-leave-to .success-bottom-sheet {
  transform: translateY(100%);
}
</style>
