<template>
  <div class="bottom-nav" :class="{ 'with-login': !isLoggedIn }">
    <div class="nav-items">
      <!-- Dashboard -->
      <div 
        class="nav-item" 
        :class="{ active: isActive('/dashboard') }"
        @click="navigateTo('/dashboard')"
      >
        <img 
          :src="isActive('/dashboard') ? dashboardIconActive : dashboardIcon" 
          alt="Dashboard"
          class="nav-icon"
        />
        <span class="nav-text">Dashboard</span>
      </div>

      <!-- CO 10 -->
      <div 
        class="nav-item" 
        :class="{ active: isActive('/token-list', { type: 'co10' }) }"
        @click="navigateTo('/token-list', { type: 'co10' })"
      >
        <img 
          :src="isActive('/token-list', { type: 'co10' }) ? co10IconActive : co10Icon" 
          alt="CO 10"
          class="nav-icon"
        />
        <span class="nav-text">CO 10</span>
      </div>

      <!-- Watchlist -->
      <div 
        class="nav-item" 
        :class="{ active: isActive('/watchlist') }"
        @click="navigateTo('/watchlist')"
      >
        <img 
          :src="isActive('/watchlist') ? watchlistIconActive : watchlistIcon" 
          alt="Watchlist"
          class="nav-icon"
        />
        <span class="nav-text">Watchlist</span>
      </div>
    </div>

    <!-- Log In 按钮 - 仅在未登录时显示 -->
    <button 
      v-if="!isLoggedIn" 
      class="login-btn"
      @click="handleLogin"
    >
      Log In
    </button>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { useUserStore } from '@/store/user'

const router = useRouter()
const route = useRoute()
const userStore = useUserStore()

// 图标 URL
const dashboardIcon = 'https://co-web-images.oss-ap-southeast-3.aliyuncs.com/mobile/login/icon-dashboard.svg'
const dashboardIconActive = 'https://co-web-images.oss-ap-southeast-3.aliyuncs.com/mobile/login/icon-dashboard-on.svg'
const co10Icon = 'https://co-web-images.oss-ap-southeast-3.aliyuncs.com/mobile/login/icon-colist.svg'
const co10IconActive = 'https://co-web-images.oss-ap-southeast-3.aliyuncs.com/mobile/login/icon-colist-on.svg'
const watchlistIcon = 'https://co-web-images.oss-ap-southeast-3.aliyuncs.com/mobile/login/icon-watchlist.svg'
const watchlistIconActive = 'https://co-web-images.oss-ap-southeast-3.aliyuncs.com/mobile/login/icon-watchlist-on.svg'

// 判断用户是否登录
const isLoggedIn = computed(() => userStore.isLoggedIn)

// 判断当前路由是否激活
const isActive = (path, query = {}) => {
  if (route.path === path) {
    // 如果有 query 参数，需要检查 query 是否匹配
    if (Object.keys(query).length > 0) {
      return Object.keys(query).every(key => route.query[key] === query[key])
    }
    return true
  }
  return false
}

// 导航到指定路由
const navigateTo = (path, query = {}) => {
  router.push({ path, query })
}

// 处理登录按钮点击
const handleLogin = () => {
  // 触发登录事件，让父组件处理显示登录弹窗
  emit('login')
}

// 定义 emit
const emit = defineEmits(['login'])
</script>

<style lang="scss" scoped>
.bottom-nav {
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 12px 16px;
  background-color: #0A061D;
  border-top: 1px solid rgba(123, 115, 174, 0.1);
  z-index: 999;
  min-height: 60px;
  box-sizing: border-box;
  
  // 当没有登录按钮时，导航项居中均匀分布
  &:not(.with-login) {
    justify-content: center;
    
    .nav-items {
      justify-content: space-around;
      flex: 1;
      max-width: 100%;
    }
  }
}

.nav-items {
  display: flex;
  align-items: center;
  gap: 32px;
  flex: 1;
}

.nav-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 4px;
  cursor: pointer;
  transition: opacity 0.2s;

  &:active {
    opacity: 0.7;
  }

  .nav-icon {
    width: 23px;
    height: 23px;
    display: block;
  }

  .nav-text {
    font-family: 'Tomato Grotesk', sans-serif;
    font-size: 12px;
    font-weight: 400;
    line-height: 1;
    color: #7B73AE;
    transition: color 0.2s;
  }

  &.active {
    .nav-text {
      color: #FFFFFF;
    }
  }
}

.login-btn {
  padding: 8px 20px;
  background-color: #7336FE;
  border: none;
  border-radius: 8px;
  font-family: 'Tomato Grotesk', sans-serif;
  font-size: 14px;
  font-weight: 500;
  color: #FFFFFF;
  cursor: pointer;
  transition: opacity 0.2s, transform 0.1s;

  &:active {
    opacity: 0.8;
    transform: scale(0.98);
  }

  &:hover {
    opacity: 0.9;
  }
}
</style>