<template>
  <div class="heat-trend-chart-container">
    <div class="chart-header">
      <h3 class="chart-title">Factor Trends</h3>
      <div class="chart-actions">
        <div class="legend">
          <span class="legend-item">
            <i class="dot bar"></i>
            Mentions
          </span>
          <span class="legend-item">
            <i class="dot line"></i>
            Sentiment
          </span>
        </div>
        <div class="time-filters">
          <button
            v-for="f in timeFilters"
            :key="f.key"
            :class="['time-filter-btn', { active: f.key === currentFilter }]"
            @click="setFilter(f.key)"
          >
            {{ f.label }}
          </button>
        </div>
      </div>
    </div>
    <div class="chart-body">
      <div ref="chartRef" class="chart" @click="handleChartContainerClick"></div>
      <div v-if="isLoading" class="loading-overlay">
        <div class="loading-text">Loading</div>
      </div>
      <div v-if="!isLoading && !hasData" class="no-data-overlay">
        <div class="no-data-title">No Data</div>
        <div class="no-data-subtitle">Try again later</div>
      </div>
    </div>
    <!-- 底部弹窗 -->
    <div v-if="showTooltip" class="bottom-dialog-mask" @click.self="closeDialog">
      <div class="bottom-dialog">
        <div class="dialog-header">
          <span class="dialog-title">
            <span>Sentiment & Market</span>
          </span>
          <span class="dialog-date">{{ tooltipData.date }}</span>
        </div>
        <div class="panel-metrics">
          <div class="metrics-row">
            <div class="metric">
              <span>Sentiment Momentum:</span>
              <span class="metric-value">{{ tooltipData.sentiment }}</span>
            </div>
          </div>
          <div class="metrics-row">
            <div class="metric">
              <span>Mentions:</span>
              <span class="metric-value">{{ tooltipData.mention }}</span>
            </div>
          </div>
        </div>
        <div class="dialog-footer">
          <button class="dialog-close-btn" @click="closeDialog">Close</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted, watch, nextTick, computed } from 'vue'
import * as echarts from 'echarts'
import dayjs from 'dayjs'
import { getFactorTrendsApi } from '@/api/common'

// 可选高度和外部传参
const props = defineProps({
  height: { type: [Number, String], default: 200 },
  coin: { type: String, default: 'BTC' },
  id: { type: Number, default: 0 },
  idList: { type: Array, default: () => [] }
})

const chartRef = ref(null)
let chartInstance = null
const isLoading = ref(true)

// API数据相关
const apiData = ref([])
const currentEndTime = ref(null)
const currentStartTime = ref(null)
const isLoadingMore = ref(false) // 防止重复加载
let loadingLock = false // 加载锁，防止重复请求

// 计算是否有数据
const hasData = computed(() => {
  return apiData.value && apiData.value.length > 0
})

const timeFilters = [
  { key: '15m', label: '15 Min' },
  { key: '30m', label: '30 Min' },
  { key: '1h', label: '1H' },
  { key: '4h', label: '4H' },
  { key: '1d', label: '1D' }
]
const currentFilter = ref('1d')

function setFilter(key) {
  if (currentFilter.value !== key) {
    currentFilter.value = key
  }
}

// 千分位
function formatNum(n) {
  if (n == null) return '-'
  return n.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')
}

// 计算时间间隔对应的分钟数
function getMinutesFromTimeType(timeType) {
  switch (timeType) {
    case '15m': return 15
    case '30m': return 30
    case '1h': return 60
    case '4h': return 240
    case '1d': return 1440
    default: return 15
  }
}

// 计算开始时间（确保有15条数据用于一屏显示，额外加载10条用于拖动）
function calculateStartTime(timeType, endTime, dataCount = 15) {
  const minutes = getMinutesFromTimeType(timeType)
  const totalMinutes = minutes * dataCount
  return dayjs(endTime).subtract(totalMinutes, 'minute').format('YYYY-MM-DD HH:mm:ss')
}

// 调用API获取数据
async function fetchFactorTrendsData(timeType, coin, idList, startTime, endTime) {
  try {
    isLoading.value = true
    // 如果传入了id，转换为idList格式
    const finalIdList = idList && idList.length > 0 ? idList : (props.id ? [props.id] : [])
    const response = await getFactorTrendsApi({
      timeType,
      coin,
      idList: finalIdList,
      startTime,
      endTime
    })
    
    if (response && response.data) {
      return response.data
    }
    return []
  } catch (error) {
    console.error('获取Factor Trends数据失败:', error)
    return []
  } finally {
    isLoading.value = false
  }
}

// 处理API数据，转换为图表所需格式
function processApiData(data) {
  if (!data || data.length === 0) {
    return { x: [], bars: [], line: [] }
  }
  
  // 1. 按 dtStart 升序排序（确保左侧是较早的时间，右侧是较新的时间）
  const sortedData = [...data].sort((a, b) => {
    return new Date(a.dtStart) - new Date(b.dtStart)
  })
  
  const x = sortedData.map(item => item.dtStart)
  const bars = sortedData.map(item => item.mention || 0)
  // 直接使用接口返回的 emotional 数据
  const line = sortedData.map(item => item.emotional || 0)
  
  return { x, bars, line }
}

// 加载初始数据
async function loadInitialData() {
  const now = dayjs()
  const endTime = now.format('YYYY-MM-DD HH:mm:ss')
  // 加载25条数据：15条用于一屏显示，10条用于拖动
  const startTime = calculateStartTime(currentFilter.value, endTime, 25)
  
  currentEndTime.value = endTime
  currentStartTime.value = startTime
  
  // 如果传入了id，转换为idList格式
  const finalIdList = props.idList && props.idList.length > 0 ? props.idList : (props.id ? [props.id] : [])
  
  const data = await fetchFactorTrendsData(
    currentFilter.value,
    props.coin,
    finalIdList,
    startTime,
    endTime
  )
  
  apiData.value = data
  currentData = processApiData(data)
  // 如果图表已初始化，更新图表；否则等待初始化完成
  if (chartInstance) {
    updateChart()
  } else {
    // 如果图表还没初始化，先初始化
    await initChart()
    if (chartInstance) {
      updateChart()
    }
  }
}

// 加载更多历史数据
async function loadMoreData() {
  if (!currentStartTime.value || isLoadingMore.value || loadingLock) return
  
  isLoadingMore.value = true
  loadingLock = true
  
  try {
    // 保存当前的 dataZoom 区间
    let oldStartValue = null
    let oldEndValue = null
    if (chartInstance) {
      const option = chartInstance.getOption()
      if (option.dataZoom && option.dataZoom[0]) {
        oldStartValue = option.dataZoom[0].startValue
        oldEndValue = option.dataZoom[0].endValue
      }
    }
    
    const newEndTime = currentStartTime.value
    const newStartTime = calculateStartTime(currentFilter.value, newEndTime)
    
    // 如果传入了id，转换为idList格式
    const finalIdList = props.idList && props.idList.length > 0 ? props.idList : (props.id ? [props.id] : [])
    
    const data = await fetchFactorTrendsData(
      currentFilter.value,
      props.coin,
      finalIdList,
      newStartTime,
      newEndTime
    )
    
    if (data && data.length > 0) {
      const addCount = data.length
      // 将新数据添加到现有数据前面
      apiData.value = [...data, ...apiData.value]
      currentData = processApiData(apiData.value)
      currentStartTime.value = newStartTime
      updateChart()
      
      // 恢复 dataZoom 区间
      if (chartInstance && oldStartValue !== null && oldEndValue !== null) {
        chartInstance.dispatchAction({
          type: 'dataZoom',
          startValue: oldStartValue,
          endValue: oldEndValue,
        })
      }
    }
  } finally {
    isLoadingMore.value = false
    loadingLock = false
  }
}

let currentData = { x: [], bars: [], line: [] }
let currentDataIndex = 0

async function initChart() {
  await nextTick()
  if (!chartRef.value) {
    // 如果还没有DOM，等待一下
    setTimeout(() => initChart(), 50)
    return
  }
  if (chartInstance) {
    chartInstance.dispose()
  }
  // 确保容器有高度
  if (chartRef.value.offsetHeight === 0) {
    // 如果容器高度为0，等待一下再初始化
    setTimeout(() => {
      if (chartRef.value && chartRef.value.offsetHeight > 0) {
        chartInstance = echarts.init(chartRef.value)
        if (currentData.x.length > 0) {
          updateChart()
        }
        window.addEventListener('resize', handleResize)
      } else {
        // 如果还是0，设置一个默认高度
        chartRef.value.style.height = '200px'
        chartInstance = echarts.init(chartRef.value)
        if (currentData.x.length > 0) {
          updateChart()
        }
        window.addEventListener('resize', handleResize)
      }
    }, 100)
  } else {
    chartInstance = echarts.init(chartRef.value)
    if (currentData.x.length > 0) {
      updateChart()
    }
    window.addEventListener('resize', handleResize)
  }
}

function handleResize() {
  if (chartInstance) chartInstance.resize()
}

// 获取刻度间隔（每几个数据点显示一个刻度）
function getTickInterval(timeFilter) {
  switch (timeFilter) {
    case '15m': return 4  // 每1小时一个刻度（4 * 15分钟 = 1小时）
    case '30m': return 4  // 每2小时一个刻度（4 * 30分钟 = 2小时）
    case '1h': return 4   // 每4小时一个刻度（4 * 1小时 = 4小时）
    case '4h': return 6   // 每一天一个刻度（6 * 4小时 = 1天）
    case '1d': return 4   // 每4天一个刻度（4 * 1天 = 4天）
    default: return 4
  }
}

// 格式化X轴标签
function formatXAxisLabel(value, index, timeFilter, prevValue) {
  if (!value) return ''
  
  const current = dayjs(value)
  const tickInterval = getTickInterval(timeFilter)
  
  // 只显示符合间隔的刻度
  if (index % tickInterval !== 0) {
    return ''
  }
  
  // 检测跨天和跨年
  let isCrossDay = false
  let isCrossYear = false
  
  if (prevValue) {
    const prev = dayjs(prevValue)
    isCrossDay = current.format('YYYY-MM-DD') !== prev.format('YYYY-MM-DD')
    isCrossYear = current.format('YYYY') !== prev.format('YYYY')
  } else {
    // 第一个刻度，总是显示日期信息
    isCrossDay = true
  }
  
  // 根据timeFilter和跨天/跨年情况格式化
  switch (timeFilter) {
    case '15m':
    case '30m':
    case '1h':
      // 如果跨年，显示 "年 月/日"
      if (isCrossYear) {
        return current.format('YYYY M/D')
      }
      // 如果跨天，显示 "月/日"
      if (isCrossDay) {
        return current.format('M/D')
      }
      // 同一天内，显示时间
      return current.format('HH:mm')
    case '4h':
      // 如果跨年，显示 "年 月/日"
      if (isCrossYear) {
        return current.format('YYYY M/D')
      }
      // 如果跨天，显示 "月/日"
      if (isCrossDay) {
        return current.format('M/D')
      }
      // 同一天内，显示时间
      return current.format('HH:mm')
    case '1d':
      // 如果跨年，显示 "年 月/日"
      if (isCrossYear) {
        return current.format('YYYY M/D')
      }
      // 跨天或同一天，都显示 "月/日"
      return current.format('M/D')
    default:
      return current.format('HH:mm')
  }
}

// 弹窗相关
const showTooltip = ref(false)
const tooltipData = ref({
  date: '',
  sentiment: '',
  mention: ''
})
// 防止关闭后立刻又弹出
let justClosed = false

const closeDialog = (e) => {
  if (e) e.stopPropagation()
  showTooltip.value = false
  selectedIndex.value = null
  updateSelectedState()
  justClosed = true
  setTimeout(() => { justClosed = false }, 150)
}

const selectedIndex = ref(null)

// 处理图表点击事件
const handleChartContainerClick = (e) => {
  if (justClosed) return
  
  if (!chartInstance || currentData.x.length === 0) return
  
  const chartRect = chartRef.value.getBoundingClientRect()
  const chartOffsetX = e.clientX - chartRect.left
  const chartOffsetY = e.clientY - chartRect.top
  
  // 限定只在图表区域有效
  if (chartOffsetX < 0 || chartOffsetX > chartRect.width || chartOffsetY < 0 || chartOffsetY > chartRect.height) {
    return
  }
  
  const pointInPixel = [chartOffsetX, chartOffsetY]
  const pointInGrid = chartInstance.convertFromPixel('grid', pointInPixel)
  
  if (pointInGrid && pointInGrid[0] >= 0) {
    const dataIndex = Math.round(pointInGrid[0])
    
    if (dataIndex >= 0 && dataIndex < currentData.x.length) {
      const rawTime = currentData.x[dataIndex]
      const sentimentValue = currentData.line[dataIndex] || 0
      const mentionValue = currentData.bars[dataIndex] || 0
      
      tooltipData.value = {
        date: dayjs(rawTime).format('YYYY-MM-DD HH:mm'),
        sentiment: sentimentValue.toFixed(2),
        mention: formatNum(mentionValue)
      }
      showTooltip.value = true
      selectedIndex.value = dataIndex
      updateSelectedState()
    }
  }
}

// 只更新选中状态的函数，不重置dataZoom
const updateSelectedState = () => {
  if (!chartInstance || currentData.x.length === 0) return
  
  const { x, bars, line } = currentData
  
  // 更新图表配置，添加高亮和标记点
  chartInstance.setOption({
    series: [
      {
        name: 'Mentions',
        markPoint: selectedIndex.value !== null ? {
          symbol: 'circle',
          symbolSize: 8,
          animation: false,
          data: [
            {
              xAxis: selectedIndex.value,
              yAxis: bars[selectedIndex.value],
              symbolOffset: [0, 0]
            }
          ],
          itemStyle: {
            color: '#6B3EE2',
            borderColor: '#fff',
            borderWidth: 2
          },
          label: { show: false }
        } : { data: [] }
      },
      {
        name: 'Sentiment',
        markPoint: selectedIndex.value !== null ? {
          symbol: 'circle',
          symbolSize: 8,
          animation: false,
          data: [
            {
              xAxis: selectedIndex.value,
              yAxis: line[selectedIndex.value],
              symbolOffset: [0, 0]
            }
          ],
          itemStyle: {
            color: '#16C784',
            borderColor: '#fff',
            borderWidth: 2
          },
          label: { show: false }
        } : { data: [] }
      }
    ],
    markLine: selectedIndex.value !== null ? {
      silent: true,
      symbol: 'none',
      lineStyle: {
        color: '#A18CFF',
        width: 1,
        type: 'dashed'
      },
      data: [
        {
          xAxis: selectedIndex.value
        }
      ]
    } : undefined
  }, false)
}

function updateChart() {
  if (!chartInstance) return

  const { x, bars, line } = currentData
  const lastBarIndex = bars.length - 1
  currentDataIndex = 0
  const isDailyView = currentFilter.value === '1d'

  // 计算初始显示范围：显示最新的15个柱子
  const totalDataCount = x.length
  const displayCount = 15 // 一屏显示15个柱子
  let dataZoomStart = 0
  let dataZoomEnd = 100
  
  if (totalDataCount > displayCount) {
    // 如果有超过15条数据，初始显示最后15条
    dataZoomStart = ((totalDataCount - displayCount) / totalDataCount) * 100
    dataZoomEnd = 100
  }

  const option = {
    backgroundColor: 'transparent',
    grid: { left: 0, right: 0, top: 20, bottom: 30 },
    dataZoom: [
      {
        type: 'inside',
        xAxisIndex: 0,
        start: dataZoomStart,      // 动态计算起始位置，显示最新的40个柱子
        end: dataZoomEnd,          // 到 100% 结束
        zoomOnMouseWheel: false,   // 禁止滚轮缩放
        moveOnMouseMove: true,     // 允许鼠标拖动
        moveOnMouseWheel: false,   // 禁止滚轮平移
        zoomLock: true             // 锁定缩放
      }
    ],
    tooltip: {
      show: false, // 禁用图表内部的tooltip弹框
      trigger: 'axis',
      axisPointer: {
        type: 'cross',
        crossStyle: {
          color: 'transparent'
        },
        lineStyle: {
          color: 'transparent'
        }
      }
    },
    xAxis: {
      type: 'category',
      data: x,
      boundaryGap: true,
      axisLine: { lineStyle: { color: 'rgba(255,255,255,0.12)' } },
      axisLabel: {
        color: 'rgba(255,255,255,0.45)',
        fontSize: 10,
        formatter: function(value, index) {
          // 获取前一个刻度的值（用于检测跨天/跨年）
          let prevValue = null
          const tickInterval = getTickInterval(currentFilter.value)
          // 如果当前索引符合间隔，查找前一个符合间隔的刻度
          if (index % tickInterval === 0) {
            const prevIndex = index - tickInterval
            if (prevIndex >= 0 && x[prevIndex]) {
              prevValue = x[prevIndex]
            }
          }
          return formatXAxisLabel(value, index, currentFilter.value, prevValue)
        }
      },
      axisTick: { show: false },
      axisPointer: {
        type: 'shadow',
        shadowStyle: {
          color: {
            type: 'linear',
            x: 0,
            y: 0,
            x2: 0,
            y2: 1,
            colorStops: [
              { offset: 0, color: 'rgba(161, 140, 255, 0.3)' },
              { offset: 1, color: 'rgba(161, 140, 255, 0.1)' }
            ]
          },
          shadowBlur: 0,
          shadowColor: 'transparent'
        },
        label: {
          show: true,
          backgroundColor: 'rgba(100, 100, 100, 0.8)',
          color: '#fff',
          borderColor: 'rgba(161, 140, 255, 0.3)',
          borderWidth: 1,
          padding: [4, 8],
          fontSize: 10,
          formatter: (params) => {
            if (!params || !params.value) return ''
            return dayjs(params.value).format('YYYY/MM/DD HH:mm')
          }
        }
      }
    },
    yAxis: [
      {
        type: 'value',
        name: '',
        // 使用接口返回的原始情感数据
        z: 50,
        axisLine: { show: false },
        axisLabel: { 
          color: '#B2ADE2', 
          fontSize: 10,
          inside: true,
          margin: 8
        },
        splitLine: { lineStyle: { type: 'dashed', color: 'rgba(255,255,255,0.08)' } },
        axisPointer: {
          label: {
            show: true,
            backgroundColor: '#16C784',
            color: '#fff',
            borderRadius: 4,
            padding: [4, 8],
            fontSize: 10,
            formatter: (params) => {
              return params.value.toFixed(2)
            }
          }
        }
      },
      {
        type: 'value',
        name: '',
        position: 'right',
        z: 50,
        axisLine: { show: false },
        axisLabel: {
          color: 'rgba(255,255,255,0.45)',
          fontSize: 10,
          formatter: (v) => formatNum(v),
          inside: true,
          margin: 8
        },
        splitLine: { show: false },
        axisPointer: {
          label: {
            show: true,
            backgroundColor: '#6B3EE2',
            color: '#fff',
            borderRadius: 4,
            padding: [4, 8],
            fontSize: 10,
            formatter: () => {
              return formatNum(bars[currentDataIndex] || 0)
            }
          }
        }
      }
    ],
    series: [
      {
        name: 'Mentions',
        type: 'bar',
        yAxisIndex: 1,
        data: bars,
        barWidth: 15,
        barCategoryGap: '40%',
        z: 1,
        itemStyle: {
          color: '#6B3EE2',
          borderRadius: [4, 4, 0, 0]
        },
        emphasis: { 
          itemStyle: { 
            color: '#8E78FF',
            borderColor: 'rgba(161, 140, 255, 0.3)',
            borderWidth: 1
          }
        },
      },
      {
        name: 'Sentiment',
        type: 'line',
        symbol: 'circle',
        symbolSize: 0, // 默认不显示圆点
        data: line,
        z: 2,
        lineStyle: { color: '#16C784', width: 2 },
        itemStyle: { color: '#16C784', borderColor: '#fff', borderWidth: 3 },
        emphasis: {
          // 移除圆点显示，改用动态markPoint
        }
      }
    ]
  }

  chartInstance.setOption(option)
  
  // 监听鼠标移动事件，更新Y轴标签和显示小圆点
  chartInstance.off('mousemove')
  chartInstance.off('mouseout')
  
  chartInstance.on('mousemove', (params) => {
    if (params.dataIndex !== undefined) {
      currentDataIndex = params.dataIndex
      const sentimentValue = line[currentDataIndex] || 0
      const discussionValue = bars[currentDataIndex] || 0
      
      // 更新Y轴标签和添加小圆点
      chartInstance.setOption({
        yAxis: [
          {
            axisPointer: {
              value: sentimentValue,
              label: {
                formatter: () => sentimentValue.toFixed(2)
              }
            }
          },
          {
            axisPointer: {
              value: discussionValue,
              label: {
                formatter: () => formatNum(discussionValue)
              }
            }
          }
        ],
        series: [
          {
            name: 'Mentions',
            markPoint: {
               symbol: 'circle',
               symbolSize: 8,
               animation: false,
               data: [
                 {
                   xAxis: currentDataIndex,
                   yAxis: discussionValue,
                   symbolOffset: [0, 0]
                 }
               ],
               itemStyle: {
                 color: '#6B3EE2',
                 borderColor: '#fff',
                 borderWidth: 2
               },
               label: { show: false }
             }
          },
          {
             name: 'Sentiment',
             markPoint: {
                symbol: 'circle',
                symbolSize: 8,
                animation: false,
                data: [
                  {
                    xAxis: currentDataIndex,
                    yAxis: sentimentValue,
                    symbolOffset: [0, 0]
                  }
                ],
                itemStyle: {
                  color: '#16C784',
                  borderColor: '#fff',
                  borderWidth: 2
                },
                label: { show: false }
              }
           }
        ]
      }, false)
    }
  })
  
  chartInstance.on('mouseout', () => {
    // 鼠标移出时移除小圆点
    chartInstance.setOption({
      series: [
        {
          name: 'Mentions',
          markPoint: { data: [] }
        },
        {
          name: 'Sentiment',
          markPoint: { data: [] }
        }
      ]
    }, false)
  })
  
  // 添加dataZoom事件来检测用户拖拽到图表左边界时加载更多数据
  chartInstance.off('dataZoom')
  chartInstance.on('dataZoom', (params) => {
    if (params.batch && params.batch.length > 0) {
      const zoomInfo = params.batch[0]
      // 当用户拖拽到最左边时（start === 0），加载更多历史数据
      if (zoomInfo.start === 0 && !loadingLock) {
        loadMoreData()
      }
    }
  })
  
  // 更新选中状态
  updateSelectedState()
}

watch(currentFilter, () => {
  loadInitialData()
})

// 监听props变化
watch(() => [props.coin, props.id, props.idList], () => {
  loadInitialData()
}, { deep: true })

onMounted(async () => {
  await nextTick()
  // 先初始化图表
  await initChart()
  // 等待一下确保图表DOM已准备好
  await new Promise(resolve => setTimeout(resolve, 100))
  // 再加载数据
  await loadInitialData()
})

onUnmounted(() => {
  window.removeEventListener('resize', handleResize)
  if (chartInstance) chartInstance.dispose()
})
</script>

<style scoped lang="scss">
.heat-trend-chart-container {
  border-radius: 16px;
  box-sizing: border-box;
  height: 100%;
  min-height: 300px;
  display: flex;
  flex-direction: column;
  margin-top: 30px;
  
  .chart-body {
    flex: 1;
    min-height: 200px;
    position: relative;
  }
}

.chart-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  margin-bottom: 12px;
  flex-wrap: wrap;
}

.chart-title {
  margin: 0;
  color: #fff;
  font-weight: 600;
  font-size: 18px;
  display: flex;
  align-items: center;
}

.chart-actions { 
  display: flex; 
  align-items: center; 
  gap: 16px; 
  flex-wrap: wrap; 
}

.legend { 
  display: flex; 
  align-items: center; 
  gap: 14px; 
  color: #B7B6C2; 
  font-size: 12px; 
}

.legend-item { 
  display: flex; 
  align-items: center; 
  gap: 8px; 
}

.legend-item .dot { 
  display: inline-block; 
  width: 12px; 
  height: 8px; 
  border-radius: 4px; 
}

.legend-item .dot.bar { 
  background: #6B3EE2;
  width: 16px;
  height: 6px; 
}

.legend-item .dot.line { 
  background: #16C784; 
  width: 16px;
  height: 6px; 
  border-radius: 4px; 
}

.time-filters {
  display: flex;
  padding: 4px;
  justify-content: space-between;
  background-color: #302D4A;
  border-radius: 8px;
  width:100%;
  box-sizing: border-box;
  
  .time-filter-btn {
    background-color: #302D4A;
    border: none;
    border-radius: 6px;
    color: #B2ADE2;
    padding: 0 16px;
    cursor: pointer;
    transition: background-color 0.2s;
    font-family: Tomato Grotesk;
    font-weight: 500;
    font-style: Medium;
    font-size: 12px;
    line-height: 32px;
    letter-spacing: 0%;
    text-align: center;
    vertical-align: middle;
    text-transform: capitalize;

    &:hover {
      background: #343348;
    }
    
    &.active {
      background: #17152A;
      color: #fff;
    }
  }
}

.chart-body { 
  width: 100%;
  position: relative;
  flex: 1;
  min-height: 0;
} 

.chart { 
  width: 100%;
  height: 100%;
  min-height: 200px;
}

.loading-overlay {
  position: absolute;
  left: 0;
  top: 0;
  right: 0;
  bottom: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 8px;
  background:#1C1833;
}

.loading-text {
  color: #FFFFFF;
  font-weight: 600;
  font-size: 16px;
}

.no-data-overlay {
  position: absolute;
  left: 0;
  top: 0;
  right: 0;
  bottom: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 8px;
}

.no-data-title {
  color: #FFFFFF;
  font-weight: 600;
  font-size: 20px;
  line-height: 1.2;
}

.no-data-subtitle {
  color: #9E9CB6;
  font-size: 14px;
  line-height: 1.2;
}

// 底部弹窗样式
.bottom-dialog-mask {
  position: fixed;
  left: 0;
  top: 0;
  width: 100vw;
  height: 100vh;
  background: rgba(28, 24, 51, 0.4);
  z-index: 2000;
  display: flex;
  align-items: flex-end;
  justify-content: center;
}

.bottom-dialog {
  width: 100%;
  background: #282544;
  border-radius: 12px 12px 0 0;
  box-shadow: 0 0 12px rgba(0, 0, 0, 0.18);
  padding: 16px 12px;
  margin-bottom: 0;
  animation: slideUp 0.25s cubic-bezier(0.4, 0, 0.2, 1);
}

@keyframes slideUp {
  from { transform: translateY(100%); }
  to { transform: translateY(0); }
}

.dialog-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 14px;
}

.dialog-title {
  font-family: 'Tomato Grotesk', sans-serif;
  font-size: 14px;
  font-weight: 600;
  color: #fff;
  display: flex;
  align-items: center;
}

.dialog-date {
  font-size: 11px;
  color: #9092A8;
}

.panel-metrics {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.metrics-row {
  display: flex;
  justify-content: flex-start;
  margin-bottom: 8px;
}

.metric {
  font-family: 'Tomato Grotesk', sans-serif;
  display: flex;
  align-items: center;
  font-size: 14px;
  color: #fff;
  font-weight: 500;
  gap: 5px;
}

.metric-value {
  font-family: 'Tomato Grotesk', sans-serif;
  font-size: 14px;
  font-weight: 600;
  color: #fff;
}

.dialog-footer {
  display: flex;
  justify-content: center;
  margin-top: 16px;
}

.dialog-close-btn {
  width: 100%;
  height: 42px;
  border: none;
  border-radius: 6px;
  background: #39365A;
  color: #fff;
  font-size: 14px;
  font-weight: 600;
  cursor: pointer;
  transition: background 0.2s;
}

.dialog-close-btn:hover {
  background: #4B476B;
}
</style>