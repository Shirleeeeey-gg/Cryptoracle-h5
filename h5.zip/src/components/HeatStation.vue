<template>
  <div class="heat-station">
    <div class="heat-station-header">
      <span class="title">Top Sectors</span>
      <!-- <img src="@/assets/dashboard/icon-tanhao.svg" alt="Info" class="icon-info"> -->
    </div>
    
    <div class="charts-grid">
      <div 
        v-for="(item, index) in chartData" 
        :key="index"
        class="chart-item"
        @mouseenter="hoveredIndex = index"
        @mouseleave="hoveredIndex = -1"
        @click="handleClick(index)"
      >
        <div class="chart-label" v-html="item.label"></div>
        <div class="circle-chart">
          <svg width="167" height="167" viewBox="0 0 167 167" class="circle-svg">
            <defs>
              <linearGradient 
                :id="`gradient-${index}`" 
                x1="0%" y1="0%" x2="100%" y2="0%"
                gradientUnits="objectBoundingBox"
              >
                <stop offset="0%" :stop-color="item.colors.start" />
                <stop offset="100%" :stop-color="item.colors.end" />
              </linearGradient>
            </defs>
            
            <!-- 背景圆 -->
            <circle
              cx="83.5"
              cy="83.5"
              r="78"
              fill="none"
              stroke="#16122D"
              stroke-width="10"
            />
            
            <!-- 进度圆 -->
            <circle
              cx="83.5"
              cy="83.5"
              r="78"
              fill="none"
              :stroke="`url(#gradient-${index})`"
              stroke-width="10"
              stroke-linecap="round"
              :stroke-dasharray="circumference"
              :stroke-dashoffset="isAnimated ? getStrokeDashoffset(item.percentage) : circumference"
              transform="rotate(-90 83.5 83.5)"
              class="progress-circle"
              :style="{ 
                transitionDelay: `${index * 200}ms`,
                transitionDuration: '1500ms'
              }"
            />
          </svg>
          
          <!-- 中心内容 -->
          <div class="chart-center">
            <div class="percentage">{{ $formatNumber(item.percentage) }}</div>
            <div class="change-wrapper">
              <span class="change" :style="{ color: item.change > 0 ? '#16C784' : '#FF4D5E' }">
                <img src="@/assets/project/arrow-up-green.svg" class="arrow-icon" alt="" v-if="item.change > 0" />
                <img src="@/assets/project/arrow-down-red.svg" class="arrow-icon" alt="" v-else />
                {{ Math.abs(Number(item.change)).toFixed(2) }} %
              </span>
            </div>
          </div>
        </div>
        
        
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import {getProjectThreeCirclesDataApi} from '@/api/dashboard'
import { useRouter } from 'vue-router'

const router = useRouter()
const hoveredIndex = ref(-1)
const isAnimated = ref(false)

function handleClick(index){
  router.push({
    name:'hot-section',
    query:{
      type:index + 1
    }
  })
}

const chartData = computed(()=>[
  {
    label: 'Callout Highlights',
    percentage: pageData.value.communityEmotional,
    change: pageData.value.communityPercent,
    colors: {
      start: 'rgba(129, 82, 255, 1)',
      end: 'rgba(129, 82, 255, 0)'
    }
  },
  // {
  //   label: 'Alpha Hunter',
  //   percentage: 46.3,
  //   change: 2.7,
  //   colors: {
  //     start: 'rgba(76,255,187,1)',
  //     end: 'rgba(76,255,187,0)'
  //   }
  // },
  {
    label: 'Unusual Market Movers',
    percentage: pageData.value.mainstreamEmotional,
    change: pageData.value.mainstreamPercent,
    colors: {
      start: 'rgba(76,255,187,1)',
      end: 'rgba(76,255,187,0)'
    }
  },
  {
    label: 'Sentiment Surge',
    percentage: pageData.value.emotionsHighEmotional,
    change: pageData.value.emotionsHighPercent,
    colors: {
      start: 'rgba(234, 140, 0, 1)',
      end: 'rgba(234, 140, 0, 0)'
    }
  }
])

const circumference = computed(() => 2 * Math.PI * 78)

const getStrokeDashoffset = (percentage) => {
  // 将percentage值转换为0-1的进度比例，2000相当于100%
  const progress = Math.min(percentage / 2000, 1) // 限制最大值为1
  return circumference.value * (1 - progress)
}
const pageData = ref({})
onMounted(async () => {
  const res = await getProjectThreeCirclesDataApi()
  if(res.code === 200){
    pageData.value = res.data
  }
  // 延迟启动动画
  setTimeout(() => {
    isAnimated.value = true
  }, 300)
})
</script>

<style lang="scss" scoped>
.heat-station {
  width: 100%;
  box-sizing: border-box;
  padding: 0 12px;
  color: #fff;
  font-family: 'Tomato Grotesk', Arial, sans-serif;
}

.heat-station-header {
  display: flex;
  align-items: center;
  margin-bottom: 15px;
  
  .title {
    font-size: 14px;
    font-weight: 600;
  }
  
  .icon-info {
    width: 6px;
    height: 6px;
    margin-left: 3px;
    opacity: 0.7;
  }
}

.charts-grid {
  display: flex;
  justify-content: space-between;
}

.chart-item {
  width:113px;
  height:131px;
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 10px;
  border-radius: 12px;
  transition: background-color 0.3s ease;
  background-color: #1C1833;
  cursor: pointer;
  position: relative;
  
  &.is-hovered {
    background-color: #2D2948;
    .chart-label {
      color: #FFFFFF;
    }
  }
  
  &:hover {
    background-color: rgba(255, 255, 255, 0.08);
    .chart-label {
      color: #FFFFFF;
    }
  }
}

.circle-chart {
  position: relative;
  width: 83.5px;
  height: 83.5px;
  margin-bottom: 6px;
}

.circle-svg {
  width: 83.5px;
  height: 83.5px;
}

.progress-circle {
  transition: stroke-dashoffset cubic-bezier(0.4, 0, 0.2, 1);
}

.chart-center {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  text-align: center;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 1px;
}

.percentage {
  font-size: 24px;
  font-weight: 600;
  line-height: 1.2;
  color: #FFFFFF;
}

.change-wrapper {
  display: flex;
  align-items: center;
  gap: 2px;
}

.arrow-icon {
  width: 8px;
  height: 8px;
}

.change {
  font-size: 10px;
  font-weight: 600;
  line-height: 1.2;
  display: flex;
  align-items: center;
  gap: 2px;
  .arrow-icon{
    width: 8px;
    height: 8px;
  }
}

.chart-label {
  height:18px;
  font-size: 9px;
  font-weight: 500;
  text-align: center;
  line-height: 1.2;
  color: #9E9CB6;
  word-break: break-word;
  margin-bottom: 6px;
}
</style> 