<template>
  <div class="chart-container" ref="chartContainer"></div>
</template>

<script setup>
import { ref, onMounted, onUnmounted, watch, computed } from 'vue';
import * as echarts from 'echarts/core';
import { LineChart } from 'echarts/charts';
import { GridComponent } from 'echarts/components';
import { SVGRenderer } from 'echarts/renderers';

// 注册必要的组件
echarts.use([LineChart, GridComponent, SVGRenderer]);

const props = defineProps({
  data: {
    type: Array,
    required: true
  },
  color: {
    type: String,
    default: '#16C784'
  }
});

const chartContainer = ref(null);
let chartInstance = null;
let resizeObserver = null;

const xData = computed(() => props.data.map(item => item.time));
const yData = computed(() => props.data.map(item => item.emotional ?? 0));

// 初始化图表
const initChart = () => {
  if (!chartContainer.value) return;
  
  chartInstance = echarts.init(chartContainer.value);
  updateChart();
  
  // 监听容器尺寸变化（表格列宽变化时也能自适应）
  if (typeof ResizeObserver !== 'undefined') {
    resizeObserver = new ResizeObserver(() => {
      handleResize();
    });
    resizeObserver.observe(chartContainer.value);
  }

  // 兜底：监听窗口大小变化
  window.addEventListener('resize', handleResize);
};

// 更新图表
const updateChart = () => {
  if (!chartInstance) return;
  
  const option = {
    grid: {
      left: 0,
      right: 0,
      top: 0,
      bottom: 0
    },
    xAxis: {
      type: 'category',
      show: false,
      data: xData.value
    },
    yAxis: {
      type: 'value',
      show: false
    },
    series: [
      {
        data: yData.value,
        type: 'line',
        smooth: true,
        symbol: 'none',
        lineStyle: {
          width: 2,
          color: props.color
        },
        areaStyle: {
          color: {
            type: 'linear',
            x: 0,
            y: 0,
            x2: 0,
            y2: 1,
            colorStops: [
              {
                offset: 0,
                color: props.color + '30' // 30% 透明度
              },
              {
                offset: 1,
                color: 'rgba(0, 0, 0, 0)'
              }
            ]
          }
        }
      }
    ],
    animation: false
  };
  
  chartInstance.setOption(option);
};

// 处理窗口大小变化
const handleResize = () => {
  if (chartInstance) {
    chartInstance.resize();
  }
};

// 监听数据变化
watch(() => [props.data, props.color], () => {
  updateChart();
}, { deep: true });

// 组件挂载时初始化图表
onMounted(() => {
  initChart();
});

// 组件卸载时清理
onUnmounted(() => {
  if (chartInstance) {
    chartInstance.dispose();
    chartInstance = null;
  }
  if (resizeObserver) {
    resizeObserver.disconnect();
    resizeObserver = null;
  }
  window.removeEventListener('resize', handleResize);
});
</script>

<style scoped>
.chart-container {
  width: 100%;
  height: 100%;
}
</style> 