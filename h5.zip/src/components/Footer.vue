<template>
  <div class="footer">
    <img class="footer-logo" src="@/assets/common-footer-logo.png" alt="footer-logo">
    <div class="footer-txt">Copyright © 2025. All rights reserved</div>
  </div>
</template>

<script setup>

</script>

<style lang="scss" scoped>
.footer {
  width: 100%;
  height: 151px;
  background: url('@/assets/common-footer-bg.png') no-repeat center center;
  background-size: 100% 100%;
  margin-top: 8px;
  box-sizing: border-box;
  padding-top: 58px;

  .footer-logo {
    display: block;
    width: 151.5px;
    margin: 0 auto;
    margin-bottom: 12px;
  }

  .footer-txt {
    font-family: Tomato Grotesk;
    font-weight: 400;
    font-size: 9px;
    line-height: 9px;
    letter-spacing: 0%;
    text-align: center;
    color:#9D9BB8;
  }
}
</style>