<template>
  <div class="rank-list">
    <!-- 头部区域 -->
    <div class="header">
      <div class="title-section">
        <h2 class="title">{{ title }}</h2>
        <Tooltip :content="tooltipContent" v-if="tooltipContent" />
      </div>
      <div class="arrow-icon" @click="jumpList">
        <img src="@/assets/dashboard/icon-link-arrow-r.svg" alt="" />
      </div>
    </div>

    <!-- 排名列表 -->
    <div class="rank-items">
      <div 
        v-for="(item, index) in items" 
        :key="index" 
        class="rank-item"
      >
        <!-- 排名序号 -->
        <div class="rank-number">{{ index + 1 }}</div>
        
        <!-- 币种图标 -->
        <div class="coin-icon">
          <img :src="item.imageUrl" alt="" />
        </div>
        
        <!-- 币种信息 -->
        <div class="coin-info">
          <div class="coin-name">{{ item.coin }}</div>
          <div class="coin-subtitle" v-if="(type === 'sentiment' || type === 'dat') && item.communityChange">{{ (item.communityChange > 0 ? ('+' + item.communityChange) : item.communityChange) + ' ties' }}</div>
        </div>
        
        <!-- 右侧数值 -->
        <div class="value-section">
          <div class="main-value" v-if="type === 'callout'">{{ formatInteger(item.mention) }}</div>
          <div class="percentage" v-if="type === 'sentiment'">
            <img src="@/assets/dashboard/ranklist-icon-up.svg" v-if="item.emotionalVolatility > 0" alt="" class="trend-arrow" />
            <img src="@/assets/dashboard/ranklist-icon-down.svg" v-if="item.emotionalVolatility < 0" alt="" class="trend-arrow" />
            <span v-if="type === 'sentiment'" :class="{'red': item.emotionalVolatility < 0}">{{ formatValue((item.emotionalVolatility * 100)) }}%</span>
          </div>
          <div class="percentage" v-if="type === 'dat'">
            <img src="@/assets/dashboard/ranklist-icon-up.svg" v-if="item.mentionVolatility > 0" alt="" class="trend-arrow" />
            <img src="@/assets/dashboard/ranklist-icon-down.svg" v-if="item.mentionVolatility < 0" alt="" class="trend-arrow" />
            <span v-if="type === 'dat'" :class="{'red': item.mentionVolatility < 0}">{{ formatValue((item.mentionVolatility * 100)) }}%</span>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { getCurrentInstance } from 'vue'
import Tooltip from '@/views/dashboard/components/Tooltip.vue'
import { useRouter } from 'vue-router'
import { formatNumber } from '@/utils/format.js'

const router = useRouter()
const instance = getCurrentInstance()

function jumpList(){
  let jumptype ;
  if (props.type === 'callout'){
    jumptype = 'hightlights'
  }else if (props.type === 'sentiment'){
    jumptype = 'surge'
  }else if (props.type === 'dat'){
    jumptype = 'dat'
  }
  router.push({
    name: 'token-list',
    query: {
      type: jumptype
    }
  })
}

const props = defineProps({
  // 组件类型：'callout', 'sentiment' 或 'dat'
  type: {
    type: String,
    default: 'callout',
    validator: (value) => ['callout', 'sentiment', 'dat'].includes(value)
  },
  // 标题
  title: {
    type: String,
    default: 'Rank List'
  },
  // Tooltip内容
  tooltipContent: {
    type: String,
    default: ''
  },
  // 排名数据
  items: {
    type: Array,
    default: () => []
  }
})

/**
 * 格式化整数显示（带千分符，不保留小数）
 * 用于 callout 类型的 mention 数值显示
 */
const formatInteger = (value) => {
  if (typeof value === 'number') {
    // 使用 formatNumber 函数，小数位数为 0，保留千分符
    return formatNumber(value, 0);
  }
  return value;
}

/**
 * 格式化数值显示，保留两位小数
 * 用于 sentiment 和 dat 类型的百分比显示
 */
const formatValue = (value) => {
  if (typeof value === 'number') {
    // 使用全局过滤器保留两位小数
    const decimalFormat = instance?.appContext?.config?.globalProperties?.$filters?.decimal;
    if (typeof decimalFormat === 'function') {
      return decimalFormat(value);
    }
    // 如果没有全局过滤器，使用默认格式化
    return value.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  }
  return value
}
</script>

<style lang="scss" scoped>
 .rank-list {
  background: #1C1833;
  border-radius: 16px; // 16 * 2
  padding: 16px;       // 16 * 2
  box-sizing: border-box;
  width: 100%;
  margin-bottom: 16px; // 16 * 2
}

.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 24px; // 24 * 2
  padding: 0 8px;     // 8 * 2
}

.title-section {
  display: flex;
  align-items: center;
}

.title {
  color: #FFFFFF;
  font-size: 18px; // 18 * 2
  font-weight: 500;
  margin: 0;
  font-family: 'Tomato Grotesk', sans-serif;
}

.arrow-icon {
  img {
    width: 20px;   // 20 * 2
    height: 20px;  // 20 * 2
    cursor: pointer;
    transition: opacity 0.2s;
    
    &:hover {
      opacity: 0.8;
    }
  }
}

.rank-items {
  display: flex;
  flex-direction: column;
}

.rank-item {
  display: flex;
  align-items: center;
  padding: 8px 0; // 8 * 2
  transition: background-color 0.2s;
}

.rank-number {
  width: 18px;   // 18 * 2
  height: 20px;  // 20 * 2
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 14px; // 14 * 2
  font-weight: 500;
  color: #A4A3AD;
  margin-right: 2px; // 2 * 2
}

.coin-icon {
  margin-right: 9px; // 9 * 2
  
  img {
    display: block;
    width: 21px;   // 21 * 2
    height: 21px;  // 21 * 2
    border-radius: 50%;
  }
}

.coin-info {
  flex: 1;
  display: flex;
  gap: 8px; // 8 * 2
  align-items: center;
}

.coin-name {
  color: #FFFFFF;
  font-size: 14px; // 14 * 2
  font-weight: 500;
  max-width: 120px; // 120 * 2
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-family: 'Tomato Grotesk', sans-serif;
}

.coin-subtitle {
  color: #9E9CB6;
  font-size: 12px; // 12 * 2
  font-weight: 400;
  font-family: 'Tomato Grotesk', sans-serif;
}

.value-section {
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  gap: 2px; // 2 * 2
}

.main-value {
  color: #FFFFFF;
  font-size: 14px; // 14 * 2
  font-weight: 500;
  font-family: 'Tomato Grotesk', sans-serif;
}

.percentage {
  display: flex;
  align-items: center;
  gap: 4px; // 4 * 2
  
  .trend-arrow {
    width: 10px;   // 10 * 2
    height: 10px;  // 10 * 2
  }
  
  span {
    color: #16C784;
    font-size: 12px; // 12 * 2
    font-weight: 500;
    font-family: 'Tomato Grotesk', sans-serif;
    &.red{
      color: #EA3943;
    }
  }
}
</style>

