<template>
  <div class="navbar">
    <!-- 主导航栏 -->
    <div class="navbar-main" :style="getNavbarStyle()">
      <div class="navbar-container">
        <!-- Logo -->
        <div class="navbar-logo">
          <img src="@/assets/images/logo.png" alt="CryptoOracle" />
        </div>

        <!-- 右侧按钮组 -->
        <div class="navbar-actions">
          <!-- 搜索按钮 -->
          <img src="@/assets/icon-search.png" alt="Search" class="navbar-search" @click="handleSearchClick" />
          <!-- 导航按钮 -->
          <img src="@/assets/images/nav-button.png" alt="Menu" class="navbar-toggle" @click="toggleMenu" />
        </div>
      </div>
    </div>

    <!-- 侧边菜单 -->
    <div class="sidebar" :class="{ open: isMenuOpen }">
      <div class="sidebar-content">
        <div class="navbar-container">
          <!-- Logo在侧边栏中 -->
          <div class="sidebar-logo">
            <img src="@/assets/images/logo.png" alt="CryptoOracle" />
          </div>
          <img src="@/assets/images/icon-close.png" alt="Menu" class="navbar-close" @click="toggleMenu" />
        </div>

        <!-- 可滚动内容区域 -->
        <div class="sidebar-scrollable">
          <!-- 菜单项 -->
          <nav class="sidebar-nav">
            <div class="nav-item" @click="navigateTo('home')">
              Home
            </div>
            <div class="nav-item" @click="navigateTo('dashboard')">
              Dashboard
            </div>
            <div class="nav-item" @click="navigateTo('cases')">
              Cases
            </div>
            <div class="nav-item" @click="navigateTo('insights')">
              Insight
            </div>
            <div class="nav-item resources-item" :class="{ 'expanded': isResourcesExpanded }" @click="toggleResources">
              <span>Resources</span>
              <img :src="iconArrow" alt="arrow" class="resources-arrow" />
            </div>
            <div v-if="isResourcesExpanded" class="resources-submenu">
              <div class="nav-item submenu-item" 
                   :class="{ 'active': activeResourcesSubmenu === 'user-guide' }"
                   @click="jumpPage('resources-user-guide')">
                <img :src="iconUser" alt="User Guide" class="submenu-icon" />
                <span>User Guide</span>
              </div>
              <div class="nav-item submenu-item" 
                   :class="{ 'active': activeResourcesSubmenu === 'api-docs' }"
                   @click="jumpPage('resources-api-docs')">
                <img :src="iconApi" alt="API Docs" class="submenu-icon" />
                <span>API Docs</span>
              </div>
            </div>
            <div class="nav-item" @click="navigateTo('about-us')">
              About Us
            </div>
            <div class="nav-item" @click="navigateTo('faq')">
              FAQ
            </div>
            <div class="nav-item" @click="navigateTo('contact')">
              Contact Us
            </div>
            <div class="nav-item disabled">
              <span>Discover</span> 
              <span class="coming-soon">Coming soon</span>
            </div>
          </nav>

          <!-- 用户信息区域（已登录时显示） -->
          <div v-if="isLoggedIn" class="user-section">
            <div class="user-info" @click="navigateTo('profile')">
              <div class="user-avatar">
                <span>{{ avatarLetter }}</span>
              </div>
              <div class="user-name">{{ userName }}</div>
            </div>
            <div class="logout-button" @click="handleLogoutClick">
              Log out
            </div>
          </div>

          <!-- 未登录时显示 Log In 按钮 -->
          <div v-else class="login-section">
            <div class="login-button" @click="handleLoginClick">
              Log In
            </div>
          </div>
            
          <!-- Footer 区域（始终显示） -->
          <div class="sidebar-footer">
            <!-- 法律链接 -->
            <div class="footer-links">
              <span class="footer-link" @click="handleTermsClick">Terms of Use</span>
              <span class="footer-separator">•</span>
              <span class="footer-link" @click="handlePrivacyClick">Privacy Policy</span>
            </div>
            
            <!-- 分隔线 -->
            <div class="footer-divider"></div>
            
            <!-- 社交媒体图标 -->
            <div class="footer-social-icons">
              <img 
                src="@/assets/login/icon-x.svg" 
                alt="X" 
                class="social-icon" 
                @click="jumpLink('https://x.com/web3cryptoracle')"
              />
              <img 
                src="@/assets/login/icon-youtube.svg" 
                alt="YouTube" 
                class="social-icon" 
                @click="jumpLink('https://www.youtube.com/@Cryptoracle_AI')"
              />
              <img 
                src="@/assets/login/icon-me.svg" 
                alt="Me" 
                class="social-icon" 
                @click="jumpLink('https://www.metaera.hk/home_wz/4357')"
              />
              <img 
                src="@/assets/login/icon-cc.svg" 
                alt="CC" 
                class="social-icon" 
                @click="jumpLink('https://www.chaincatcher.com/specialt/4672')"
              />
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 遮罩层 -->
    <div class="overlay" :class="{ active: isMenuOpen }" @click="closeMenu"></div>

    <!-- 登录弹窗 -->
    <Login :visible="isLoginVisible" @update:visible="isLoginVisible = $event" @close="handleLoginClose" @register="handleRegister" />

    <!-- 注册弹窗 -->
    <Register v-model:visible="isRegisterVisible" />

    <!-- 搜索弹窗 -->
    <Search :visible="isSearchVisible" @update:visible="isSearchVisible = $event" @close="handleSearchClose" />
  </div>
</template>

<script setup>
import { ref, computed, onMounted, onUnmounted } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '@/store/user'
import { logoutApi } from '@/api/login'
import { ElMessage } from 'element-plus'
import iconArrow from '@/assets/login/icon-arrow-down.svg'
import iconUser from '@/assets/login/icon-user-guide.svg'
import iconApi from '@/assets/login/icon-api-docs.svg'
import Login from '@/components/Login/Login.vue'
import Register from '@/components/Login/Register.vue'
import Search from '@/components/Search.vue'

const router = useRouter()
const userStore = useUserStore()
const isMenuOpen = ref(false)
const scrollY = ref(0)
const isResourcesExpanded = ref(false)
const activeResourcesSubmenu = ref('')
const isLoginVisible = ref(false)
const isRegisterVisible = ref(false)
const isSearchVisible = ref(false)

// 用户登录状态
const isLoggedIn = computed(() => userStore.isLoggedIn)

// 用户名
const userName = computed(() => userStore.username || 'User')

// 头像字母：取用户名的首字母，如果没有用户名则取邮箱的首字母
const avatarLetter = computed(() => {
  const name = userStore.username || userStore.email || 'U'
  return name.charAt(0).toUpperCase()
})

const toggleMenu = () => {
  isMenuOpen.value = !isMenuOpen.value
}

const closeMenu = () => {
  isMenuOpen.value = false
  isResourcesExpanded.value = false
  activeResourcesSubmenu.value = ''
}

const navigateTo = (name) => {
  // 这里可以添加路由导航逻辑
  closeMenu()
  router.push({ name })
}

const toggleResources = () => {
  isResourcesExpanded.value = !isResourcesExpanded.value
}

const jumpPage = (name) => {
  closeMenu()
  router.push({ name })
}

const handleScroll = () => {
  scrollY.value = window.scrollY
}

onMounted(() => {
  window.addEventListener('scroll', handleScroll)
  // 监听 401 错误触发的登录弹框显示事件
  window.addEventListener('show-login-modal', handleShowLoginModal)
})

onUnmounted(() => {
  window.removeEventListener('scroll', handleScroll)
  // 移除登录弹框显示事件监听
  window.removeEventListener('show-login-modal', handleShowLoginModal)
})

const getNavbarStyle = () => {
  const maxScroll = 80
  const y = Math.min(scrollY.value, maxScroll)
  const alpha = y / maxScroll
  return {
    background: `rgba(3,2,25,${alpha})`,
    borderBottom: alpha > 0 ? '0.5px solid rgba(77, 73, 110, 1)' : 'none',
    transition: 'background 0.3s, border-bottom 0.3s'
  }
}

/**
 * 处理登出逻辑
 * 调用登出接口，成功后清除用户信息
 */
const handleLogoutClick = async () => {
  try {
    // 调用登出接口
    await logoutApi()
    
    // 接口调用成功后，清除用户信息（会自动清除持久化的数据）
    userStore.clearUserInfo()
    
    // 关闭侧边菜单
    closeMenu()
    
    // 登出成功提示
    ElMessage.success('Logged out successfully')
    
    // 跳转到首页
    router.push({ name: 'home' })
    
  } catch (error) {
    // 登出失败时的错误处理
    console.error('Logout error:', error)
    // 错误信息已通过 request.js 中的 ElMessage 显示
  }
}

// 处理条款点击
const handleTermsClick = () => {
  closeMenu()
  // 如果路由存在则跳转，否则使用外部链接
  if (router.resolve({ name: 'terms-of-use' }).matched.length > 0) {
    router.push({ name: 'terms-of-use' })
  } else {
    window.open('/terms-of-use', '_blank')
  }
}

// 处理隐私政策点击
const handlePrivacyClick = () => {
  closeMenu()
  // 如果路由存在则跳转，否则使用外部链接
  if (router.resolve({ name: 'privacy-policy' }).matched.length > 0) {
    router.push({ name: 'privacy-policy' })
  } else {
    window.open('/privacy-policy', '_blank')
  }
}

// 处理外部链接跳转
const jumpLink = (url) => {
  window.open(url, '_blank')
}

// 处理登录按钮点击
const handleLoginClick = () => {
  isLoginVisible.value = true
  closeMenu()
}

// 处理登录弹窗关闭
const handleLoginClose = () => {
  isLoginVisible.value = false
}

// 处理注册按钮点击（从登录弹窗触发）
const handleRegister = () => {
  isLoginVisible.value = false
  isRegisterVisible.value = true
}

// 处理搜索按钮点击
const handleSearchClick = () => {
  isSearchVisible.value = true
}

// 处理搜索弹窗关闭
const handleSearchClose = () => {
  isSearchVisible.value = false
}

// 处理显示登录弹框事件（用于 401 错误时自动弹出登录弹框）
const handleShowLoginModal = () => {
  isLoginVisible.value = true
}
</script>

<style lang="scss" scoped>
.navbar {
  position: fixed;
  z-index: 1000;
  width:100%;
  top:0;
  left:0;
}

.navbar-main {
  padding: 0;
  position: relative;
  z-index: 1001;
  background: transparent;
  border-bottom: none;
  transition: background 0.3s, border-bottom 0.3s;
}

.navbar-container {
  padding: 0 15px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  height: 60px;
}

.navbar-logo {
  img {
    width: 137px;
    height: 25px;
    object-fit: contain;
  }
}

.navbar-actions {
  display: flex;
  align-items: center;
  gap: 16px;
}

.navbar-search {
  width: 32px;
  height: 32px;
  object-fit: contain;
  cursor: pointer;
  transition: opacity 0.2s ease;
  
  &:active {
    opacity: 0.7;
  }
}

.navbar-toggle {
  background: none;
  border: none;
  padding: 0;
  width: 43px;
  height: 27px;
  object-fit: contain;
  cursor: pointer;
  transition: opacity 0.2s ease;
  
  &:active {
    opacity: 0.7;
  }
}

.sidebar {
  position: fixed;
  top: 0;
  right: -100vw;
  width: 100vw;
  height: 100vh;
  transition: right 0.3s ease;
  z-index: 1002;
  background-color: #030219;
}

.sidebar.open {
  right: 0;
}

.sidebar-content {
  height: 100vh;
  display: flex;
  flex-direction: column;
  overflow: hidden;

  .sidebar-container {
    padding: 0 15px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    height: 60px;
    flex-shrink: 0;
  }
}

.sidebar-logo {

  img {
    width: 137px;
    height: 25px;
    object-fit: contain;
  }
}

.navbar-close{
  width: 27px;
  height: 27px;
  object-fit: contain;
}

// 可滚动内容区域
.sidebar-scrollable {
  flex: 1;
  overflow-y: auto;
  overflow-x: hidden;
  display: flex;
  flex-direction: column;
  min-height: 0; // 确保 flex 子元素可以正确收缩
  
  // 自定义滚动条样式
  &::-webkit-scrollbar {
    width: 4px;
  }
  
  &::-webkit-scrollbar-track {
    background: transparent;
  }
  
  &::-webkit-scrollbar-thumb {
    background: rgba(255, 255, 255, 0.2);
    border-radius: 2px;
    
    &:hover {
      background: rgba(255, 255, 255, 0.3);
    }
  }
}

.sidebar-nav {
  padding: 0 20px;
  display: flex;
  flex-direction: column;
  gap: 0;
  margin-top: 32px;
  flex-shrink: 0;
}

.nav-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  height: 50px;
  border-bottom: 0.5px solid #292B3A;
  color: #ffffff;
  text-decoration: none;
  transition: all 0.3s ease;
  font-family: Tomato Grotesk;
  font-weight: 500;
  font-size: 15px;


  

  &.disabled {
    cursor: default;

    span:first-child {
      color: #ffffff;
    }
  }

  &.resources-item {
    cursor: pointer;
    
    .resources-arrow {
      width: 24px;
      height: 24px;
    }
    &.expanded{
      .resources-arrow {
        width: 24px;
        height: 24px;
        transform: rotate(180deg);
      }
    }
  }

  &.submenu-item {
    height: 50px;
    color: #fff;
    transform: none;
    display: flex;
    align-items: center;
    gap: 12px;
    &:first-child{
      border-bottom: none;
    }
    .submenu-icon {
      width: 28px;
      height: 28px;
      flex-shrink: 0;
    }

    span {
      flex: 1;
    }
  }
}

.resources-submenu {
  display: flex;
  flex-direction: column;
  gap: 0;
  background-color: transparent;
}

.coming-soon {
  font-family: Tomato Grotesk;
  font-weight: 500;
  font-size: 12px;
  line-height: 12px;
  letter-spacing: 0%;
  text-align: right;
  vertical-align: middle;
  color:rgba(255, 255, 255, 0.4);
}

.overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100vw;
  height: 100vh;
  background: rgba(0, 0, 0, 0.5);
  opacity: 0;
  visibility: hidden;
  transition: all 0.3s ease;
  z-index: 1000;

  &.active {
    opacity: 1;
    visibility: visible;
  }
}

// 用户信息区域
.user-section {
  padding: 20px;
  margin-top: auto;
  flex-shrink: 0;

  .user-info {
    display: flex;
    align-items: center;
    gap: 12px;
    margin-bottom: 16px;
    border-bottom: 0.5px solid #292B3A;
    padding-bottom: 16px;
    .user-avatar {
      width: 28px;
      height: 28px;
      display: flex;
      justify-content: center;
      align-items: center;
      border-radius: 50%;
      border: 1px solid #EEEDF7;
      background-color: #A6A0DB;
      flex-shrink: 0;
      box-sizing: border-box;

      span {
        font-family: Tomato Grotesk;
        font-weight: 600;
        font-style: SemiBold;
        font-size: 24px;
        color: rgba(0, 0, 0, 0.4);
      }
    }

    .user-name {
      font-family: Tomato Grotesk;
      font-weight: 500;
      font-size: 16px;
      line-height: 24px;
      color: #EEEDF7;
      flex: 1;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
  }

  .logout-button {
    width: 100%;
    height: 56px;
    display: flex;
    justify-content: center;
    align-items: center;
    background: rgba(48, 45, 72, 1);
    border-radius: 12px;
    font-family: Tomato Grotesk;
    font-weight: 500;
    font-size: 16px;
    color: #EEEDF7;
    cursor: pointer;
    transition: background-color 0.2s ease;

    &:active {
      background: rgba(48, 45, 72, 0.8);
    }
  }
}

// 未登录时的登录按钮区域
.login-section {
  padding: 20px;
  margin-top: auto;
  flex-shrink: 0;

  .login-button {
    width: 100%;
    height: 56px;
    display: flex;
    justify-content: center;
    align-items: center;
    background: #7644FB;
    border-radius: 12px;
    font-family: Tomato Grotesk;
    font-weight: 500;
    font-size: 16px;
    color: #ffffff;
    cursor: pointer;
    transition: background-color 0.2s ease, transform 0.1s ease;

    &:active {
      background: #8D67FF;
      transform: scale(0.98);
    }
  }
}

// Footer 区域样式
.sidebar-footer {
  padding: 0 20px 20px;
  margin-top: auto;
  flex-shrink: 0;

  .footer-links {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    margin-bottom: 16px;

    .footer-link {
      font-family: Tomato Grotesk;
      font-weight: 500;
      font-size: 12px;
      color: #8D67FF;
      cursor: pointer;

    }

    .footer-separator {
      font-family: Tomato Grotesk;
      font-weight: 500;
      font-size: 13px;
      color: #B2ADE2;
    }
  }

  .footer-divider {
    width: 100%;
    height: 0.5px;
    background: #292B3A;
    margin-bottom: 16px;
  }

  .footer-social-icons {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 16px;

    .social-icon {
      width: 40px;
      height: 40px;
      cursor: pointer;
      transition: opacity 0.2s ease;

      &:active {
        opacity: 0.7;
      }
    }
  }
}
</style>