<template>
  <div class="gitbook-iframe-content">
    <!-- 进度条容器 -->
    <div class="progress-container" v-show="isLoading">
      <div class="progress-bar" :style="{ width: progress + '%' }"></div>
    </div>
    <iframe 
      ref="iframe"
      :src="src" 
      frameborder="0"
      @load="onIframeLoad"
    ></iframe>
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted } from 'vue'

// 定义 props
const props = defineProps({
  src: {
    type: String,
    required: true
  }
})

const isLoading = ref(true)
const progress = ref(0)
const iframe = ref(null)
let progressInterval = null

// 模拟进度条加载
const startProgress = () => {
  progress.value = 0
  progressInterval = setInterval(() => {
    if (progress.value < 90) {
      // 前90%慢慢加载，模拟真实加载过程
      const increment = Math.random() * 10 + 2
      progress.value = Math.min(progress.value + increment, 90)
    }
  }, 200)
}

// iframe加载完成事件
const onIframeLoad = () => {
  // 快速完成剩余的进度
  progress.value = 100
  
  // 延迟隐藏进度条，让用户看到100%的效果
  setTimeout(() => {
    isLoading.value = false
    if (progressInterval) {
      clearInterval(progressInterval)
      progressInterval = null
    }
  }, 300)
}

onMounted(() => {
  startProgress()
})

onUnmounted(() => {
  if (progressInterval) {
    clearInterval(progressInterval)
  }
})
</script>

<style scoped lang="scss">
.gitbook-iframe-content {
  width: 100%;
  height: 100%;
  position: relative;
  
  .progress-container {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 2px;
    background-color: rgba(255, 255, 255, 0.1);
    z-index: 10;
    overflow: hidden;
    
    .progress-bar {
      height: 100%;
      background: linear-gradient(90deg, #6366f1, #8b5cf6, #a855f7, #c084fc);
      background-size: 200% 100%;
      animation: shimmer 2s infinite linear;
      transition: width 0.3s ease;
      border-radius: 0 1px 1px 0;
    }
    
    @keyframes shimmer {
      0% {
        background-position: -200% 0;
      }
      100% {
        background-position: 200% 0;
      }
    }
  }
  
  iframe {
    border: none;
    width: 100%;
    height: 100%;
  }
}
</style> 