<template>
  <teleport to="body">
    <transition name="co-fade">
      <div v-if="visible" class="co-search-mask" @click="closeModal"></div>
    </transition>
    <transition name="co-dialog">
      <div v-if="visible" class="co-search-dialog" role="dialog" aria-modal="true" @click.stop>
        <!-- 搜索框区域 -->
        <div class="search-header">
          <img class="search-icon" :src="iconSrc" alt="" />
          <input
            v-model="keyword"
            class="search-input"
            placeholder="Search Token"
            @keydown.esc="closeModal"
          />
          <button class="close-btn" aria-label="Close" @click="closeModal">
            <img :src="iconClose" alt="" />
          </button>
        </div>

        <!-- 热门代币区域（无输入时显示） -->
        <div v-if="!hasKeyword" class="heat-section">
          <div class="heat-title">
            <img class="flame" :src="iconFlame" alt="" />
            <span>Trending Tokens</span>
          </div>
          <div class="chips">
            <div
              v-for="t in hotTokens"
              :key="t.id || t.coin"
              class="chip"
              @click="selectToken(t)"
            >
              {{ t.coin }}
            </div>
          </div>
        </div>

        <!-- 搜索结果区域（有输入时显示） -->
        <div v-else class="results-section">
          <div class="results-title">Search Tokens</div>
          <div class="results-list" role="listbox">
            <div
              v-for="(r, idx) in searchResults"
              :key="(r.id ?? r.coin ?? idx) + '-' + idx"
              class="result-item"
              role="option"
              @click="selectResult(r)"
            >
              <img class="token-icon" :src="r.imageUrl" alt="" />
              <div class="token-texts">
                <span class="token-name">{{ r.coin }}</span>
                <span class="token-symbol">{{ r.name }}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </transition>
  </teleport>
</template>

<script setup>
import { ref, watch, onMounted, onBeforeUnmount, computed } from 'vue';
import iconSearch from '@/assets/search/icon-search.svg';
import iconFlame from '@/assets/icon-community.svg';
import iconClose from '@/assets/search/icon-close.svg';
import { getHotCoinApi, getSearchCoinApi } from '@/api/common'
import { useRouter } from 'vue-router';

const props = defineProps({
  visible: {
    type: Boolean,
    default: false
  }
});

const emit = defineEmits(['update:visible', 'close']);

const iconSrc = iconSearch;
const keyword = ref('');
const hotTokens = ref([]);
const searchResults = ref([]);
const selectedIndex = ref(0);
const hasKeyword = computed(() => keyword.value.trim().length > 0);

const closeModal = () => {
  emit('update:visible', false);
  emit('close');
  keyword.value = '';
  searchResults.value = [];
  selectedIndex.value = 0;
  clearTimeout(debounceTimer);
};

const onKeydown = (e) => {
  if (e.key === 'Escape') closeModal();
};

watch(() => props.visible, (val) => {
  if (val) {
    window.addEventListener('keydown', onKeydown);
    document.documentElement.style.overflow = 'hidden';
    setTimeout(() => {
      const inputEl = document.querySelector('.co-search-dialog .search-input');
      if (inputEl) inputEl.focus();
    });
  } else {
    window.removeEventListener('keydown', onKeydown);
    document.documentElement.style.overflow = '';
  }
});

onMounted(async () => {
  try {
    const res = await getHotCoinApi();
    const list = (res && Array.isArray(res.data)) ? res.data : [];
    hotTokens.value = list;
  } catch (e) {
    hotTokens.value = [];
  }
});

onBeforeUnmount(() => {
  window.removeEventListener('keydown', onKeydown);
  document.documentElement.style.overflow = '';
});

const selectToken = (t) => {
  keyword.value = (t && typeof t === 'object') ? (t.coin || '') : (t || '');
};

const router = useRouter();
const selectResult = (item) => {
  keyword.value = item && item.coin ? item.coin : '';
  router.push({
    name: 'project',
    query: {
      coin: item.coin,
      id: item.id
    }
  });
  closeModal();
};

// 监听输入，改为调用后端搜索接口
let debounceTimer = null;
let lastQuery = '';
watch(keyword, async (val) => {
  const q = (val || '').trim();
  if (!q) {
    searchResults.value = [];
    selectedIndex.value = 0;
    clearTimeout(debounceTimer);
    lastQuery = '';
    return;
  }
  clearTimeout(debounceTimer);
  debounceTimer = setTimeout(async () => {
    const current = q;
    lastQuery = current;
    try {
      const res = await getSearchCoinApi({ coin: current });
      const list = (res && Array.isArray(res.data)) ? res.data : [];
      // 仅保留需要的字段
      const mapped = list.map(item => ({
        id: item.id,
        coin: item.coin,
        name: item.name,
        imageUrl: item.imageUrl
      })).filter(it => it && it.coin);
      // 忽略过期返回
      if (lastQuery === current) {
        searchResults.value = mapped;
        selectedIndex.value = 0;
      }
    } catch (e) {
      if (lastQuery === current) {
        searchResults.value = [];
        selectedIndex.value = 0;
      }
    }
  }, 250);
});
</script>

<style scoped lang="scss">
.co-search-mask {
  position: fixed;
  inset: 0;
  background: rgba(0, 0, 0, 0.6);
  z-index: 1000;
}

.co-search-dialog {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  width: 100vw;
  height: 100vh;
  background: #1a152d;
  z-index: 1001;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

/* 搜索框区域 */
.search-header {
  display: flex;
  align-items: center;
  padding: 16px 20px;
  gap: 12px;
  flex-shrink: 0;
}

.search-icon {
  width: 18px;
  height: 18px;
  flex-shrink: 0;
}

.search-input {
  flex: 1;
  background: transparent;
  border: none;
  outline: none;
  font-family: Tomato Grotesk;
  font-size: 16px;
  color: #FFFFFF;
  line-height: 20px;
}

.search-input::placeholder {
  color: rgba(255, 255, 255, 0.5);
}

.close-btn {
  width: 32px;
  height: 32px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: rgba(255, 255, 255, 0.1);
  border: none;
  border-radius: 50%;
  padding: 0;
  cursor: pointer;
  flex-shrink: 0;
  transition: background-color 0.2s ease;
}

.close-btn:active {
  background: rgba(255, 255, 255, 0.2);
}

.close-btn img {
  width: 16px;
  height: 16px;
}

/* 热门代币区域 */
.heat-section {
  flex: 1;
  overflow-y: auto;
  padding: 0 20px 20px;
}

.heat-title {
  display: flex;
  align-items: center;
  gap: 6px;
  color: #FFFFFF;
  font-family: Tomato Grotesk;
  font-size: 16px;
  font-weight: 500;
  margin-bottom: 16px;
}

.flame {
  width: 18px;
  height: 18px;
}

.chips {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
}

.chip {
  height: 36px;
  padding: 0 16px;
  border-radius: 18px;
  background: #5F578C;
  color: #FFFFFF;
  border: none;
  font-family: Tomato Grotesk;
  font-weight: 500;
  font-size: 14px;
  cursor: pointer;
  display: flex;
  align-items: center;
  transition: background-color 0.2s ease;
}

.chip:active {
  background: #6b6696;
}

/* 搜索结果区域 */
.results-section {
  flex: 1;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  padding: 0 20px 20px;
}

.results-title {
  padding: 0 0 12px 0;
  color: rgba(255, 255, 255, 0.6);
  font-family: Tomato Grotesk;
  font-size: 14px;
  flex-shrink: 0;
}

.results-list {
  flex: 1;
  overflow-y: auto;
  padding: 0;
}

.result-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 12px;
  border-radius: 12px;
  cursor: pointer;
  margin-bottom: 8px;
  transition: all 0.2s ease;
  
  &:last-child {
    margin-bottom: 0;
  }
}

.token-icon {
  width: 24px;
  height: 24px;
  border-radius: 50%;
  flex-shrink: 0;
  object-fit: cover;
}

.token-texts {
  display: flex;
  gap: 4px;
  flex: 1;
  min-width: 0;
}

.token-name {
  color: #FFFFFF;
  font-size: 16px;
  font-family: Tomato Grotesk;
  font-weight: 600;
  line-height: 20px;
}

.token-symbol {
  color: rgba(255, 255, 255, 0.6);
  font-size: 14px;
  font-family: Tomato Grotesk;
  line-height: 18px;
}

/* Transition: mask fade */
.co-fade-enter-active,
.co-fade-leave-active {
  transition: opacity 0.22s ease;
}

.co-fade-enter-from,
.co-fade-leave-to {
  opacity: 0;
}

/* Transition: dialog slide up */
.co-dialog-enter-active,
.co-dialog-leave-active {
  transition: opacity 0.24s ease, transform 0.24s ease;
}

.co-dialog-enter-from,
.co-dialog-leave-to {
  opacity: 0;
  transform: translateY(20px);
}

/* 自定义滚动条样式 */
.heat-section::-webkit-scrollbar,
.results-list::-webkit-scrollbar {
  width: 4px;
}

.heat-section::-webkit-scrollbar-track,
.results-list::-webkit-scrollbar-track {
  background: transparent;
}

.heat-section::-webkit-scrollbar-thumb,
.results-list::-webkit-scrollbar-thumb {
  background: rgba(255, 255, 255, 0.2);
  border-radius: 2px;
}

.heat-section::-webkit-scrollbar-thumb:hover,
.results-list::-webkit-scrollbar-thumb:hover {
  background: rgba(255, 255, 255, 0.3);
}
</style>
