<template>
  <div class="kol-discussion-container">
    <div class="title">KOL Discussion Hub</div>
    <div class="table-wrapper">
      <div class="table-scroll">
        <table class="kol-table">
          <thead>
            <tr>
              <th class="index-header">#</th>
              <th class="kol-name-header">KOL Name</th>
              <th class="followers-header">Followers(24h)</th>
              <th class="buzz-header">Buzz(24h)</th>
              <th class="tokens-header">Most Discussed Tokens</th>
              <th class="trend-header">Trends(24h)</th>
            </tr>
          </thead>
          <tbody>
            <tr 
              v-for="(item, index) in kolData" 
              :key="item.id || index"
              class="kol-row"
              @click="handleRowClick(item)"
            >
              <td class="index-cell">
                <span>{{ index + 1 }}</span>
              </td>
              <td class="kol-name-cell">
                <div class="kol-info">
                  <div class="kol-avatar">
                    <img :src="item.avatar" :alt="item.name" />
                  </div>
                  <div class="kol-name-wrapper">
                    <div class="kol-name">{{ $filters.tokenName(item.name) }}</div>
                  </div>
                </div>
              </td>
              <td class="followers-cell">
                <span>{{ $filters.integer ? $filters.integer(item.followers) : formatNumber(item.followers) }}</span>
              </td>
              <td class="buzz-cell">
                <div class="buzz-box">
                  <div class="buzz-wrapper">
                    <div class="buzz-bar" :style="{ width: item.buzzPercentage + '%' }"></div>
                  </div>
                  <span class="buzz-value">{{ item.buzz }}</span>
                </div>
              </td>
              <td class="tokens-cell">
                <div class="tokens-wrapper">
                  <span v-for="(token, tokenIndex) in item.mainTokens" :key="tokenIndex" class="token-tag">
                    {{ token }}
                  </span>
                </div>
              </td>
              <td class="trend-cell">
                <div class="trend-wrapper">
                  <img 
                    v-if="item.trend != 0"
                    :src="item.trend > 0 ? ArrowTop : ArrowBottom" 
                    :alt="item.trend > 0 ? 'up' : 'down'" 
                    class="trend-arrow" 
                  />
                  <span :class="{ 'green-text': item.trend > 0, 'red-text': item.trend < 0 }">
                    {{ Math.abs(item.trend).toFixed(2) }}%
                  </span>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import { useRouter } from 'vue-router'
import ArrowTop from '@/assets/dashboard/arrow-top.svg'
import ArrowBottom from '@/assets/dashboard/arrow-bottom.svg'
import { getKolListApi } from '@/api/common.js'

const loading = ref(false)
const router = useRouter()

// 格式化数字
const formatNumber = (num) => {
  if (num >= 1000000) {
    return (num / 1000000).toFixed(1) + 'M'
  } else if (num >= 1000) {
    return (num / 1000).toFixed(1) + 'K'
  }
  return num.toString()
}

const handleRowClick = (row) => {
  console.log('点击了KOL:', row.name)
  // 可以跳转到KOL详情页
  // router.push(`/kol-detail?id=${row.id}`)
}

const getKolData = async () => {
  if (loading.value) return
  loading.value = true
  try {
    const res = await getKolListApi()
    const list = Array.isArray(res?.data) ? res.data : []
    kolData.value = list.map((item, idx) => {
      const volumeRatio = Number(item.volumeRatio ?? 0)
      const volumeChange = Number(item.volumeChange ?? 0)
      const buzzPercent = Math.max(0, Math.min(100, volumeRatio * 100))
      return {
        id: item.channelId || idx + 1,
        name: item.title || '-',
        handle: item.platform || '',
        avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(item.title || 'KOL')}`,
        followers: Number(item.memberNum ?? 0),
        buzz: `${(buzzPercent * 10).toFixed(2)}`,
        buzzPercentage: buzzPercent,
        mainTokens: (item.coinTag || '')
          .split(',')
          .map(s => s.trim())
          .filter(Boolean),
        trend: volumeChange * 100
      }
    })
  } catch (error) {
    console.error('加载数据失败:', error)
    kolData.value = []
  } finally {
    loading.value = false
  }
}

onMounted(async () => {
  await getKolData()
})

const kolData = ref([])
</script>

<style scoped lang="scss">
.kol-discussion-container {
  width: 100%;
  margin: 0 auto;
  background-color: #1C1833;
  border-radius: 16px;
  padding: 20px 12px;
  box-sizing: border-box;
}

.title {
  font-family: Tomato Grotesk, Arial, sans-serif;
  font-weight: 600;
  font-size: 14px;
  color: #fff;
  margin-bottom: 15px;
}

.table-wrapper {
  width: 100%;
  overflow-x: auto;
  -webkit-overflow-scrolling: touch;
  scrollbar-width: thin;
  scrollbar-color: rgba(255, 255, 255, 0.2) transparent;
  
  &::-webkit-scrollbar {
    height: 4px;
  }
  
  &::-webkit-scrollbar-track {
    background: transparent;
  }
  
  &::-webkit-scrollbar-thumb {
    background: rgba(255, 255, 255, 0.2);
    border-radius: 2px;
  }
}

.table-scroll {
  min-width: 800px;
}

.kol-table {
  width: 100%;
  min-width: 800px;
  border-collapse: collapse;
  background-color: #0B0527;
  border: 1px solid #323546;
  border-radius: 12px;
  overflow: hidden;
  table-layout: auto;
}

thead {
  background-color: #27243D;
}

th {
  font-family: Tomato Grotesk, Arial, sans-serif;
  font-weight: 500;
  font-size: 12px;
  color: #fff;
  padding: 12px 8px;
  text-align: left;
  border-bottom: none;
  white-space: nowrap;
  
  &.index-header {
    min-width: 40px;
    text-align: center;
    padding-left: 8px;
  }
  
  &.kol-name-header {
    min-width: 150px;
    padding-left: 12px;
  }
  
  &.followers-header {
    min-width: 120px;
    text-align: center;
  }
  
  &.buzz-header {
    min-width: 100px;
    text-align: center;
  }
  
  &.tokens-header {
    min-width: 200px;
    text-align: center;
  }
  
  &.trend-header {
    min-width: 100px;
    text-align: center;
  }
}

tbody {
  tr {
    height: 60px;
    border-bottom: 1px solid rgba(50, 53, 70, 0.5);
    cursor: pointer;
    transition: background-color 0.2s;
    background-color: #0B0527;
    
    &:last-child {
      border-bottom: none;
    }
    
    &:hover,
    &:active {
      background-color: #2F2B51;
    }
  }
}

td {
  font-family: Tomato Grotesk, Arial, sans-serif;
  font-weight: 600;
  font-size: 12px;
  color: #fff;
  padding: 12px 8px;
  background-color: transparent;
  vertical-align: middle;
  
  &.index-cell {
    min-width: 40px;
    text-align: center;
    padding-left: 8px;
  }
  
  &.kol-name-cell {
    min-width: 150px;
    padding-left: 12px;
  }
  
  &.followers-cell {
    min-width: 120px;
    text-align: center;
  }
  
  &.buzz-cell {
    min-width: 100px;
    text-align: center;
  }
  
  &.tokens-cell {
    min-width: 200px;
    text-align: center;
  }
  
  &.trend-cell {
    min-width: 100px;
    text-align: center;
  }
}

.kol-info {
  display: flex;
  align-items: center;
}

.kol-avatar {
  width: 32px;
  height: 32px;
  border-radius: 50%;
  overflow: hidden;
  margin-right: 12px;
  flex-shrink: 0;
}

.kol-avatar img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.kol-name-wrapper {
  display: flex;
  flex-direction: column;
  min-width: 0;
}

.kol-name {
  font-weight: 600;
  font-size: 12px;
  color: #fff;
  line-height: 16px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.buzz-box {
  display: flex;
  align-items: center;
  justify-content: center;
}

.buzz-wrapper {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100px;
  height: 8px;
  background-color: #18171E;
  border-radius: 40px;
  margin: 0 auto;
}

.buzz-bar {
  position: absolute;
  left: 0;
  top: 0;
  height: 100%;
  background: linear-gradient(90deg, #7644FB 0%, #9D6CFF 100%);
  border-radius: 10px;
  transition: width 0.3s ease;
}

.buzz-value {
  position: relative;
  font-size: 12px;
  font-weight: 600;
  color: #fff;
  margin-left: 8px;
  white-space: nowrap;
}

.tokens-wrapper {
  display: flex;
  align-items: center;
  justify-content: center;
  flex-wrap: wrap;
  gap: 8px;
}

.token-tag {
  font-family: Tomato Grotesk;
  font-weight: 600;
  font-style: SemiBold;
  font-size: 12px;
  line-height: 16px;
  letter-spacing: 0%;
  text-align: right;
  vertical-align: middle;
  text-transform: capitalize;
  color: #fff;
  white-space: nowrap;
}

.trend-wrapper {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 4px;
}

.trend-arrow {
  width: 12px;
  height: 12px;
}

.green-text {
  color: #16C784;
}

.red-text {
  color: #EA3943;
}
</style>

