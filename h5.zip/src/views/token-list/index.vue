<template>
  <div class="token-list-container">
    <Navbar />
    <div class="token-list-content">
      <template v-if="type == 'co10'">
        <div class="page-title">
          CO10 Tokens List
        </div>
        <div class="page-desc">
          The CO10 Token List selects the top 10 tokens by market capitalization, updates the token list once a quarter, and ranks them based on private domain discussion popularity.
        </div>
      </template>
      <template v-else-if="type == 'coall'">
        <div class="page-title">
          CO All Tokens List
        </div>
        <div class="page-desc">
          Cryptoracle mainly covers cryptocurrencies listed on mainstream exchanges, and collects, mines, and quantifies private domain data.
        </div>
      </template>
      <template v-else-if="type == 'hightlights'">
        <div class="page-title">
          Callout Highlights
        </div>
        <div class="page-desc">
          We analyze token popularity trends across various communities using multiple dimensions, including discussion volume, frequency of mentions in private domain groups, and commentary from high-weighted users, to rank the Top 10 Tokens.
        </div>
      </template>
      <template v-else-if="type == 'surge'">
        <div class="page-title">
          Sentiment Momentum
        </div>
        <div class="page-desc">
          Top 10 Tokens by Rapid Sentiment Acceleration in Private Communities (24H) ,These tokens exhibit the fastest-growing sentiment or engagement in the past 24 hours. Mentions may originate from any user or group, and those with high frequency are included in the ranking
        </div>
      </template>
      <template v-else-if="type == 'dat'">
        <div class="page-title">
          DAT Rankings
        </div>
        <div class="page-desc">
          View cryptocurrencies from the perspective of digital asset treasury， when examining the development of cryptocurrencies, rank the cryptocurrencies in descending order based on their mention popularity in private domains.  
        </div>
      </template>
    </div>
    <TokenTable ref="tokenTableRef" :apiFunc="listApi" :type="type" />

    <Footer />
    <BottomNav v-if="type === 'co10'" @login="handleLogin" />
    <Login v-model:visible="loginVisible" @register="handleRegister" />
    <Register v-model:visible="registerVisible" />
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted, computed } from 'vue'
import Navbar from '@/components/Navbar.vue'
import Footer from '@/components/Footer.vue'
import BottomNav from '@/components/BottomNav.vue'
import Login from '@/components/Login/Login.vue'
import Register from '@/components/Login/Register.vue'
import TokenTable from '@/views/token-list/components/TokenTable.vue'
import { 
  getCO10TokenListApi,
  getCOAllTokenListApi,
  getCORankingCalloutHighlightsApi,
  getCORankingSentimentSurgeApi,
  getCORankingDATApi
} from '@/api/tokenlist'
import { useRoute } from 'vue-router'

const tokenTableRef = ref(null)
const loginVisible = ref(false)
const registerVisible = ref(false)

const route = useRoute()

const type = computed(() => {
  return route.query.type
})

const listApi = computed(() => {
  switch (type.value) {
    case 'co10':
      return getCO10TokenListApi
    case 'coall':
      return getCOAllTokenListApi
    case 'hightlights':
      return getCORankingCalloutHighlightsApi
    case 'surge':
      return getCORankingSentimentSurgeApi
    case 'dat':
      return getCORankingDATApi
    default:
      return getCO10TokenListApi
  }
})

// 处理登录按钮点击
const handleLogin = () => {
  loginVisible.value = true
}

// 处理注册按钮点击（从登录弹窗触发）
const handleRegister = () => {
  loginVisible.value = false
  registerVisible.value = true
}

// 滚动处理函数
const handleScroll = () => {
  
  const { scrollTop, scrollHeight, clientHeight } = document.documentElement
  
  // 当滚动到距离底部100px时开始加载下一页
  if (scrollTop + clientHeight >= scrollHeight - 100) {
    tokenTableRef.value.loadNextPage()
  }
}

onMounted(() => {
  // 只有coall类型才启用滚动翻页
  if (type.value === 'coall') {
    window.addEventListener('scroll', handleScroll)
  }
})

onUnmounted(() => {
  // 只有coall类型才移除滚动监听
  if (type.value === 'coall') {
    window.removeEventListener('scroll', handleScroll)
  }
})
</script>

<style lang="scss" scoped>
.token-list-container {
  width: 100%;
  height: 100%;
  min-height: 100vh;
  background-color: #0A061D;
  padding-top: 60px;
  padding-bottom: 84px; /* BottomNav高度：60px min-height + 24px padding（仅在type===co10时显示） */
  .token-list-content {
    padding: 40px 16px;

    .page-title {
      font-family: Tomato Grotesk;
      font-weight: 400;
      font-size: 18px;
      line-height: 100%;
      letter-spacing: 0%;
      color: #fff;
      margin-bottom: 16px;
    }

    .page-desc {
      font-family: Tomato Grotesk;
      font-weight: 500;
      font-size: 14px;
      line-height: 20px;
      color: #9E9CB6;
    }
  }
}
</style>
