<template>
  <div class="token-list-container">
    <!-- <div class="title">CO50 Token List</div> -->
    <div class="table-wrapper" ref="tableWrapper" >
      <el-table :data="tokenData" class="custom-table" @row-click="handleRowClick" @scroll="handleScroll">
        <el-table-column type="index" label="#" align="center" min-width="40" fixed="left" />

        <el-table-column label="Name" min-width="90" fixed="left">
          <template #default="scope">
            <div class="token-info" v-if="scope && scope.row">
              <div class="token-image">
                <img :src="scope.row.imageUrl" :alt="scope.row.name" />
              </div>
              <div class="token-name-wrapper">
                <div class="token-name">{{ scope.row.name }}</div>
                <div class="token-symbol">{{ scope.row.coin }}</div>
              </div>
            </div>
          </template>
        </el-table-column>

        <el-table-column label="Buzz(24h)" align="center" min-width="90">
          <template #default="scope">
            <div class="mention-wrapper" v-if="scope && scope.row">
              <img class="kol-icon" v-if="scope.$index < 5" src="@/assets/icons/tokens/up-arrow.svg" alt="KOL" />
              <span>{{ $filters.heat(scope.row.heat) }}</span>
            </div>
          </template>
        </el-table-column>

        <el-table-column prop="privateCommunity" label="Communities(24h)" min-width="140" align="center">
          <template #default="scope">
            <span v-if="scope && scope.row">{{ $filters.integer(scope.row.privateCommunity) }}</span>
          </template>
        </el-table-column>
        
        <el-table-column prop="kol" label="KOLs(24h)" align="center" min-width="90">
          <template #default="scope">
            <span v-if="scope && scope.row">{{ $filters.integer(scope.row.kol) }}</span>
          </template>
        </el-table-column>
        
        <el-table-column prop="privateCommunityScale" label="Followers(24h)" align="center" min-width="180">
          <template #default="scope">
            <span v-if="scope && scope.row">{{ $filters.integer(scope.row.privateCommunityScale) }}</span>
          </template>
        </el-table-column>

        <el-table-column prop="mention" label="Mentions(24h)" align="center" min-width="130">
          <template #default="scope">
            <span v-if="scope && scope.row">{{ $filters.integer(scope.row.mention) }}</span>
          </template>
        </el-table-column>

        <el-table-column label="Price" align="center" min-width="90">
          <template #default="scope">
            <span v-if="scope && scope.row" :class="{ 'green-text': scope.row.emotional > 0, 'red-text': scope.row.emotional < 0 }">
              {{ $filters.price(scope.row.price) }}
            </span>
          </template>
        </el-table-column>

        <el-table-column prop="volume" label="Volume(24h)" align="center" min-width="100">
          <template #default="scope">
            <span v-if="scope && scope.row">${{ $filters.volume(scope.row.volume) }}</span>
          </template>
        </el-table-column>

        <el-table-column label="Sentiment" align="center" min-width="110">
          <template #default="scope">
            <span v-if="scope && scope.row" :class="{ 'green-text': scope.row.emotional > 0, 'red-text': scope.row.emotional < 0 }">
              {{ $filters.decimal(scope.row.emotional) }}
            </span>
          </template>
        </el-table-column>

        <el-table-column label="Trends(24h)" align="center" width="160">
          <template #default="scope">
            <div class="sentiment-trend" v-if="scope && scope.row">
              <SentimentTrendChart :data="scope.row.emotionalData ? JSON.parse(scope.row.emotionalData) : []"
                :color="scope.row.emotional > 0 ? '#16C784' : '#EA3943'" />
            </div>
          </template>
        </el-table-column>
      </el-table>
      
      <!-- 加载状态 -->
      <!-- <div v-if="loading" class="loading-wrapper">
        <div class="loading-text">loading...</div>
      </div> -->
      
      <!-- 没有更多数据提示 -->
      <!-- <div v-if="noMoreData && tokenData.length > 0" class="no-more-data">
        no more data
      </div> -->
      
      <!-- Slide For More 提示 -->
      <!-- <div v-if="!noMoreData && tokenData.length > 0" class="slide-for-more">
        <div class="slide-text">Slide For More</div>
      </div> -->
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, nextTick } from 'vue';
import SentimentTrendChart from '@/components/charts/SentimentTrendChart.vue';
import { getProjectThreeCirclesListDataApi } from '@/api/dashboard'
import { useRouter,useRoute } from 'vue-router'

const pageNum = ref(1)
const pageSize = ref(50)
const total = ref(0)
const current = ref(1)
const pages = ref(2)
const loading = ref(false)
const noMoreData = ref(false)
const tableWrapper = ref(null)

const route = useRoute()

const router = useRouter()
const handleRowClick = (row) => {
  //找出点击的这行的index
  const index = tokenData.value.findIndex(item => item.id === row.id)
  router.push(`/project?id=${row.id}&coin=${row.coin}&rank=${index+1}`)
}

const getCO50TokenList = async (isLoadMore = false) => {
  if (loading.value || noMoreData.value) return
  
  loading.value = true
  
  try {
    const res = await getProjectThreeCirclesListDataApi({ type:route.query.type })
    if (res.code === 200) {
        tokenData.value = res.data
      
      total.value = res.data.total
      current.value = res.data.current
      pages.value = res.data.pages
      
      // 检查是否已经加载到最后一页
      if (current.value >= pages.value) {
        noMoreData.value = true
      }
    }
  } catch (error) {
    console.error('加载数据失败:', error)
  } finally {
    loading.value = false
  }
}

// 滚动事件处理 - 由父组件触发
const loadNextPage = async () => {
  if (loading.value || noMoreData.value) return
  
  pageNum.value++
  await getCO50TokenList(true)
}

// 滚动事件处理
const handleScroll = async () => {
  return 
  if (loading.value || noMoreData.value) return
  
  const wrapper = tableWrapper.value
  if (!wrapper) return
  
  const { scrollTop, scrollHeight, clientHeight } = wrapper
  
  // 当滚动到距离底部25px时开始加载
  if (scrollTop + clientHeight >= scrollHeight - 50) {
    pageNum.value++
    await getCO50TokenList(true)
  }
}

onMounted(async () => {
  await getCO50TokenList()
})

// 模拟数据
const tokenData = ref([]);

// 导出方法供父组件调用
defineExpose({
  loadNextPage,
  loading,
  noMoreData
})
</script>

<style scoped>
:deep(.el-table td.el-table__cell){
  font-size: 11px;
}
:deep(.el-table--fit .el-table__inner-wrapper:before){
  display:none!important;
}
/* 表体行边框样式 */
:deep(.el-table__body .el-table__row:not(:last-child)) {
  border-bottom: 0.5px solid rgba(50, 53, 70, 0.5);
}
:deep(.el-table td.el-table__cell, .el-table th.el-table__cell.is-leaf){
  border-bottom: 0.5px solid rgba(50, 53, 70, 0.5);
}
:deep(.el-table .cell){
  padding:0!important;
}
:deep(.el-pagination button){
  background:transparent!important;
  color:rgba(255,255,255,0.6)!important;
}
:deep(.el-pager li){
  background:transparent!important;
  color:rgba(255,255,255,0.6)!important;
  width:16px;
  height:16px;
  border-radius: 3.5px;
  margin:0 2px;
}
:deep(.el-pager li.is-active){
  background:#7644FB!important;
  color:#fff!important;
}
:deep(.el-table) {
  border: none !important;
  background: transparent !important;
}

:deep(.el-table__row) {
  background: transparent !important;
  border-radius: 4px !important;
  cursor: pointer;
}

:deep(.el-table__header-wrapper) {
  border-radius: 4px;
  height:26px;
  background-color: #27243D;
}

.token-list-container {
  width:100%;
  box-sizing: border-box;
  background-color: transparent;
  border-radius: 8px;
  padding: 0 12px;
  box-sizing: border-box;
  margin-top: 35px;
  margin-bottom:30px;
}

.title {
  font-family: Tomato Grotesk, Arial, sans-serif;
  font-weight: 600;
  font-size: 14px;
  line-height: 15px;
  padding-top: 15px;
  color: #fff;
  margin-bottom: 17.5px;
}
.table-wrapper{
  padding-bottom: 10px;
}



.loading-wrapper {
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 10px;
  background-color: #0B0527;
}

.loading-text {
  color: #9E9CB6;
  font-size: 7px;
  font-family: Tomato Grotesk, Arial, sans-serif;
}

.no-more-data {
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 10px;
  color: #9E9CB6;
  font-size: 7px;
  font-family: Tomato Grotesk, Arial, sans-serif;
  border-top: 0.5px solid rgba(50, 53, 70, 0.5);
}

/* 自定义Element Plus Table样式 */
:deep(.el-table) {
  background-color: #0B0527;
  border: 0.5px solid #323546;
  border-radius: 6px;
  overflow: hidden;
}

:deep(.el-table__inner-wrapper) {
  border-radius: 6px;
}

/* 表头样式 */
:deep(.el-table__header-wrapper th.el-table__cell) {
  background-color: #27243D !important;
  color: #fff;
  font-family: Tomato Grotesk, Arial, sans-serif;
  font-weight: 500;
  font-size: 10px;
  padding: 8px 0;
  border-bottom: none;
}

/* 表头行样式 */
:deep(.el-table__header-row) {
  height: 25px;
}

/* 表体单元格样式 */
:deep(.el-table__body .el-table__cell) {
  font-family: Tomato Grotesk, Arial, sans-serif;
  font-weight: 600;
  font-size: 12px;
  color: #fff;
  padding: 12.5px;
  background-color: #030219;
}

/* 表体行样式 */
:deep(.el-table__body .el-table__row) {
  height: 35px;
  background-color: #0B0527;
}

/* 表体行边框样式 */
:deep(.el-table__body .el-table__row:not(:last-child)) {
  border-bottom: 0.5px solid rgba(50, 53, 70, 0.5);
}
:deep(.el-table td.el-table__cell, .el-table th.el-table__cell.is-leaf){
  border-bottom: 0.5px solid rgba(50, 53, 70, 0.5);
}

/* 表体行悬停样式 */
:deep(.el-table__body .el-table__row:hover) {
  background-color: #2F2B51 !important;
}

:deep(.el-table__body tr:hover > td.el-table__cell) {
  background-color: #2F2B51 !important;
}

:deep(.el-table::before) {
  display: none;
}

.token-info {
  display: flex;
  align-items: center;
}

.token-image {
  width: 24px;
  height: 24px;
  border-radius: 50%;
  overflow: hidden;
  margin-right: 4px;
  flex-shrink: 0;
}

.token-image img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.token-name-wrapper {
}

.token-name {
  font-weight: 600;
  font-size: 12px;
  color: #fff;
  margin-bottom: 2px;
}

.token-symbol {
  font-weight: 500;
  font-size: 9px;
  line-height: 10px;
  color: #9E9CB6;
}

.green-text {
  color: #16C784;
}

.red-text {
  color: #EA3943;
}

.mention-wrapper {
  display: flex;
  align-items: center;
  justify-content: center;
}

.kol-icon {
  width: 7.5px;
  height: 9.5px;
  margin-right: 1px;
}

.sentiment-trend {
  height: 18px;
  padding: 0 2px;
}

.slide-for-more {
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 10px;
  color: #9E9CB6;
  font-size: 9px;
  font-family: Tomato Grotesk, Arial, sans-serif;
  border-top: 0.5px solid rgba(50, 53, 70, 0.5);
}

.slide-text {
  margin-right: 4px;
}

.slide-icon {
  width: 12px;
  height: 12px;
}
</style>