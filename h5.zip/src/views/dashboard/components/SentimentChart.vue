<template>
  <div class="sentiment-chart-container">
    <div class="chart-header">
      <div class="chart-title-box">
        <h2 class="chart-title">Sentiment & Market</h2>
        <Tooltip
          content="Integrate real-time sentiment data (from community and on-chain sources), quantify community sentiment dynamics, and track correlations between market sentiment trends and target cryptocurrency price actions." />
      </div>

      <!-- <div class="info-icon">
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
          <circle cx="8" cy="8" r="7.5" stroke="#666" stroke-opacity="0.6" />
          <text x="8" y="11" text-anchor="middle" font-size="10" fill="#666">i</text>
        </svg>
      </div> -->
      <div class="time-filters">
        <button v-for="period in timePeriods" :key="period.value"
          :class="['time-filter-btn', { active: selectedPeriod === period.value }]"
          @click="setTimePeriod(period.value)">
          {{ period.label }}
        </button>
      </div>
    </div>

    <div class="charts-wrapper" ref="chartsContainer">
      <div class="charts-inner">
        <!-- 蜡烛图容器 -->
        <div class="candlestick-chart" ref="candlestickChart" @click="handleChartClick"></div>
        <!-- 折线图容器 -->
        <div class="line-chart" ref="lineChart"></div>
      </div>

      <!-- 数据弹窗 -->
      <!-- <div class="data-tooltip" v-show="showTooltip" :style="tooltipStyle"> -->
      <div v-if="showTooltip" class="bottom-dialog-mask" @click.self="closeDialog">
        <div class="bottom-dialog">
          <div class="dialog-header">
            <span class="dialog-title">
              <img src="@/assets/images/dashboard/layer-icon-tb.svg" alt="" class="qb-icon">
              <span>AIVIX</span>
            </span>
            <span class="dialog-date">{{ tooltipData.date }} {{ tooltipData.dtStart }}</span>
          </div>
          <div class="panel-metrics">
            <div class="metrics-row">
              <div class="metric">
                <div class="metric-title">Open:</div>
                <div class="metric-value">${{ tooltipData.open }}</div>
              </div>
              <div class="metric">
                <div class="metric-title">High:</div>
                <div class="metric-value">${{ tooltipData.high }}</div>
              </div>
            </div>
            <div class="metrics-row">
              <div class="metric">
                <div class="metric-title">Low:</div>
                <div class="metric-value">${{ tooltipData.low }}</div>
              </div>
              <div class="metric">
                <div class="metric-title">Close:</div>
                <div class="metric-value">${{ tooltipData.close }}</div>
              </div>
            </div>
            <div class="metrics-row">
              <div class="metric" style="flex:1;">
                <div class="metric-title">Sentiment:</div>
                <div class="metric-value" style="color:#00C087">{{ tooltipData.predict }}</div>
              </div>
            </div>
          </div>
          <div class="dialog-footer">
            <button class="dialog-close-btn" @click="showTooltip = false">Close</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, computed, reactive, onUnmounted, watch } from 'vue';
import * as echarts from 'echarts';
import { getProjectTopChartDataApi } from '@/api/dashboard';
import dayjs from 'dayjs';
import Tooltip from '@/views/dashboard/components/Tooltip.vue'
import { formatNumberSmart } from '@/utils/format'

// 图表实例
const candlestickChart = ref(null);
const lineChart = ref(null);
const chartsContainer = ref(null);
let candlestickInstance = null;
let lineChartInstance = null;

// 存储文档级别事件处理器引用，方便销毁时清理
let documentMouseMoveHandler = null;
let documentWheelHandler = null;

// 时间间隔选项
const timePeriods = [
  { label: '15 Min', value: '15m' },
  { label: '30 Min', value: '30m' },
  { label: '1H', value: '1h' },
  { label: '4H', value: '4h' },
  { label: '1D', value: '1d' },
  { label: '7D', value: '1w' }
];

// 当前选中的时间间隔
const selectedPeriod = ref('15m');

// 设置时间间隔
const setTimePeriod = (period) => {
  if (selectedPeriod.value === period) return; // 避免重复请求
  selectedPeriod.value = period;
  // 直接调用更新，使用最新的 period 值
  if (isChartReady.value) {
    updateChartData(false);
  }
};

const selectedPeriodComputed = computed(() => props.selectedPeriod || selectedPeriod.value || '15m');

/**
 * 图表 tooltip 价格格式化：
 * 1. 支持科学计数法（如 2e-8 -> 0.00000002）
 * 2. 普通小数保持原样（如 0.27849 仍然是 0.27849，不会变成 0.278490000000000015）
 * 3. 去掉小数部分末尾无用的 0（如 0.10000000 -> 0.1）
 */
const formatPrice = (value) => {
  // 空值直接返回占位符
  if (value === null || value === undefined || value === "") {
    return "--";
  }

  // 先转成字符串，避免一上来就用 toFixed 产生精度问题
  let str = String(value).trim();

  // 处理带逗号的情况，比如 "105,357.72"
  str = str.replace(/,/g, "");

  // 基本校验，不是有效数字就原样返回
  const num = Number(str);
  if (!Number.isFinite(num)) {
    return String(value);
  }

  const hasExponent = /e/i.test(str);
  const sign = num < 0 ? "-" : "";

  if (hasExponent) {
    // 这里专门把科学计数法展开为普通十进制字符串
    let [mantissa, exponent] = str.toLowerCase().split("e");
    let exp = parseInt(exponent, 10);

    if (mantissa.startsWith("-") || mantissa.startsWith("+")) {
      mantissa = mantissa.slice(1);
    }

    let [intPart, fracPart = ""] = mantissa.split(".");
    let digits = intPart + fracPart;
    let dotIndex = intPart.length;
    let newIndex = dotIndex + exp;

    if (exp > 0) {
      if (newIndex >= digits.length) {
        digits = digits.padEnd(newIndex, "0");
      }
    } else if (exp < 0) {
      if (newIndex <= 0) {
        digits = digits.padStart(digits.length + (1 - newIndex), "0");
        newIndex = 1;
      }
    }

    const beforeDot = digits.slice(0, newIndex);
    const afterDot = digits.slice(newIndex);
    str = beforeDot + (afterDot ? "." + afterDot : "");
  } else {
    // 普通小数直接用 JS 默认字符串，避免 toFixed 带来的长尾
    str = num.toString();
  }

  // 去掉小数末尾多余 0 和多余的小数点
  str = str
    .replace(/(\.\d*?[1-9])0+$/, "$1")
    .replace(/\.0+$/, "")
    .replace(/^\+/, "");

  // 统一处理 -0 / +0
  if (str === "-0" || str === "+0") {
    return "0";
  }

  // 加回符号（num.toString() 已带符号，这里只处理科学计数那支）
  if (sign === "-" && !str.startsWith("-")) {
    str = "-" + str;
  }

  return str;
};

function getTimeRange(period, endTime) {
  const end = dayjs(endTime);
  let start;
  switch (period) {
    case "15m":
      start = end.subtract(1, "day");
      break;
    case "30m":
      start = end.subtract(2, "day");
      break;
    case "1h":
      start = end.subtract(4, "day");
      break;
    case "4h":
      start = end.subtract(16, "day");
      break;
    case "1d":
      start = end.subtract(200, "day");
      break;
    case "1w":
      start = end.subtract(420, "day");
      break;
    default:
      start = end.subtract(2, "day");
  }
  return {
    startTime: start.format("YYYY-MM-DD HH:mm:ss"),
    endTime: end.format("YYYY-MM-DD HH:mm:ss"),
  };
}

const axisLabelFormatter = (value, index) => {
  if (!value) return "";
  if (selectedPeriodComputed.value === "1d") {
    return index % 8 === 0 ? value : "";
  }
  if (value.includes("/")) return value;
  const spacing = Math.max(1, axisLabelSpacing);
  return index % spacing === 0 ? value : "";
};

// 弹窗数据和状态
const showTooltip = ref(false);
const tooltipStyle = ref({
  left: '0px',
  top: '0px'
});
const tooltipData = reactive({
  date: '2025-05-15',
  dtStart: '22:30',
  open: '105,357.72',
  high: '105,550.74',
  low: '104,975.97',
  close: '105,398.14',
  predict: '753,872.87'
});

// 图表数据缓存
const chartRawData = ref([]);
const coinData = ref({});
let isLoading = false;

const MIN_VISIBLE_CANDLES = 9;
const SPACING_SEQUENCE = [1, 2, 4, 8, 16, 24, 32];
const MAX_LABEL_SPACING = SPACING_SEQUENCE[SPACING_SEQUENCE.length - 1];
const MAX_VISIBLE_CANDLES = MIN_VISIBLE_CANDLES * MAX_LABEL_SPACING;

let axisLabelSpacing = 1;

const isChartReady = ref(false);

const updateFixedLabels = () => {
  if (
    chartRawData.value.length > 0 &&
    candlestickInstance &&
    lineChartInstance
  ) {
    const candlestickOption = candlestickInstance.getOption();
    const dataZoom = candlestickOption.dataZoom[0];
    const totalLength = chartRawData.value.length;
    const endIndex = Math.floor((totalLength * dataZoom.end) / 100) - 1;
    const lastVisibleData = chartRawData.value[Math.max(0, endIndex)];

    const highPricePixel = candlestickInstance.convertToPixel("grid", [
      0,
      lastVisibleData.highPrice,
    ])[1];

    const processedEmotional =
      (parseFloat(lastVisibleData.emotional) + 1) * 1000;
    const emotionalPixel = lineChartInstance.convertToPixel("grid", [
      0,
      processedEmotional,
    ])[1];

    candlestickInstance.setOption(
      {
        graphic: [
          {
            type: "group",
            right: 0,
            top: highPricePixel - 10,
            zlevel: 0,
            z: 101,
            silent: true,
            ignore: false,
            children: [
              {
                type: "rect",
                shape: { x: 0, y: 0, width: 50, height: 20, r: 4 },
                style: { fill: "#16C784", stroke: "none" },
                zlevel: 0,
                z: 101,
              },
              {
                type: "text",
                style: {
                  x: 25,
                  y: 10,
                  text: formatNumberSmart(lastVisibleData.highPrice, {
                    decimals: 2,
                  }),
                  fill: "#fff",
                  fontSize: 10,
                  textAlign: "center",
                  textVerticalAlign: "middle",
                },
                zlevel: 0,
                z: 102,
              },
            ],
          },
        ],
      },
      { notMerge: false }
    );

    lineChartInstance.setOption(
      {
        graphic: [
          {
            type: "group",
            right: 0,
            top: emotionalPixel - 10,
            zlevel: 0,
            z: 101,
            silent: true,
            ignore: false,
            children: [
              {
                type: "rect",
                shape: { x: 0, y: 0, width: 50, height: 20, r: 4 },
                style: { fill: "#16C784", stroke: "none" },
                zlevel: 0,
                z: 101,
              },
              {
                type: "text",
                style: {
                  x: 25,
                  y: 10,
                  text: formatNumberSmart(processedEmotional, { decimals: 2 }),
                  fill: "#fff",
                  fontSize: 10,
                  textAlign: "center",
                  textVerticalAlign: "middle",
                },
                zlevel: 0,
                z: 102,
              },
            ],
          },
        ],
      },
      { notMerge: false }
    );
  }
};

const updateAxisLabelSpacing = () => {
  if (!candlestickInstance || !chartRawData.value.length) return;
  const option = candlestickInstance.getOption();
  const dataZoom = option?.dataZoom?.[0];
  if (!dataZoom) return;

  const totalLength = chartRawData.value.length;
  let startIndex = 0;
  let endIndex = totalLength - 1;

  if (
    Number.isFinite(dataZoom.startValue) &&
    Number.isFinite(dataZoom.endValue)
  ) {
    startIndex = Math.max(0, Math.floor(dataZoom.startValue));
    endIndex = Math.min(totalLength - 1, Math.floor(dataZoom.endValue));
  } else {
    const startPercent = Number.isFinite(dataZoom.start) ? dataZoom.start : 0;
    const endPercent = Number.isFinite(dataZoom.end) ? dataZoom.end : 100;
    startIndex = Math.max(
      0,
      Math.floor((startPercent / 100) * totalLength)
    );
    endIndex = Math.min(
      totalLength - 1,
      Math.ceil((endPercent / 100) * totalLength) - 1
    );
  }

  const visibleCount = Math.max(1, endIndex - startIndex + 1);
  let spacing = SPACING_SEQUENCE[0];
  for (let i = 1; i < SPACING_SEQUENCE.length; i++) {
    const prevMultiplier = SPACING_SEQUENCE[i - 1];
    if (visibleCount > MIN_VISIBLE_CANDLES * prevMultiplier) {
      spacing = SPACING_SEQUENCE[i];
    } else {
      break;
    }
  }
  spacing = Math.min(spacing, MAX_LABEL_SPACING);

  axisLabelSpacing = spacing;
  candlestickInstance.setOption({
    xAxis: {
      axisLabel: {
        formatter: axisLabelFormatter,
      },
    },
  });
};

// 数据缩放配置
const dataZoomConfig = {
  type: 'inside',
  start: 70, // 显示最后30%的数据
  end: 100,
  zoomOnMouseWheel: false,
  moveOnMouseMove: true,
  moveOnMouseWheel: true,
  zoomLock: true
};

const props = defineProps({
  coin: {
    type: String,
    default: "",
  },
  id: {
    type: Number,
    default: 0,
  },
  selectedPeriod: {
    type: String,
    default: "15m",
  },
});

// 更新图表数据（从接口获取）
const updateChartData = async (isAppend = false, customEndTime = null) => {
  if (!isChartReady.value || isLoading) return;
  isLoading = true;
  try {
    let endTime;
    if (customEndTime) {
      endTime = dayjs(customEndTime).format("YYYY-MM-DD HH:mm:ss");
    } else if (isAppend && chartRawData.value.length > 0) {
      endTime = dayjs(chartRawData.value[0].dtStart).format(
        "YYYY-MM-DD HH:mm:ss"
      );
    } else {
      endTime = dayjs().format("YYYY-MM-DD HH:mm:ss");
    }

    let oldStartValue = null;
    let oldEndValue = null;
    let addCount = 0;
    if (isAppend && candlestickInstance) {
      const option = candlestickInstance.getOption();
      if (option.dataZoom && option.dataZoom[0]) {
        oldStartValue = option.dataZoom[0].startValue;
        oldEndValue = option.dataZoom[0].endValue;
      }
    }

    // 优先使用 selectedPeriod.value，如果没有则使用 props.selectedPeriod
    const currentTimeType = selectedPeriod.value || props.selectedPeriod || '15m';
    const { startTime } = getTimeRange(currentTimeType, endTime);

    const res = await getProjectTopChartDataApi({
      id: props.id,
      coin: props.coin,
      timeType: currentTimeType,
      startTime,
      endTime,
    });

    coinData.value = res.data?.coinData || {};
    let dataArr = Array.isArray(res) ? res : res?.data || [];
    dataArr = dataArr
      .slice()
      .sort((a, b) => new Date(a.dtStart) - new Date(b.dtStart));
    if (isAppend) {
      addCount = dataArr.length;
      chartRawData.value = [...dataArr, ...chartRawData.value];
    } else {
      chartRawData.value = dataArr;
    }

    const xAxisData = chartRawData.value.map((item, index, arr) => {
      let format = "HH:mm";

      if (["1d", "1w"].includes(selectedPeriodComputed.value)) {
        format = "MM/DD";
        return dayjs(item.dtStart).format(format);
      }

      if (["15m", "30m", "1h", "4h"].includes(selectedPeriodComputed.value) && index > 0) {
        const cur = dayjs(item.dtStart);
        const prev = dayjs(arr[index - 1].dtStart);
        if (!cur.isSame(prev, "day")) {
          return cur.format("MM/DD");
        }
      }

      return dayjs(item.dtStart).format(format);
    });
    const kLineData = chartRawData.value.map((item) => [
      item.openPrice,
      item.closePrice,
      item.lowPrice,
      item.highPrice,
    ]);

    const sentimentData = chartRawData.value.map((item) => {
      const emotionalValue = parseFloat(item.emotional);
      return (emotionalValue + 1) * 1000;
    });

    const totalLength = chartRawData.value.length;
    const minSpanPercent =
      totalLength > MIN_VISIBLE_CANDLES
        ? (MIN_VISIBLE_CANDLES / totalLength) * 100
        : 100;
    const maxSpanPercent =
      totalLength > MAX_VISIBLE_CANDLES
        ? (MAX_VISIBLE_CANDLES / totalLength) * 100
        : 100;
    const normalizedMinSpan = Math.min(100, Math.max(0, minSpanPercent));
    const normalizedMaxSpan = Math.min(
      100,
      Math.max(normalizedMinSpan, maxSpanPercent)
    );
    const INITIAL_VISIBLE_COUNT = 40;
    let initialStart = 0;
    if (totalLength > INITIAL_VISIBLE_COUNT) {
      initialStart = ((totalLength - INITIAL_VISIBLE_COUNT) / totalLength) * 100;
    } else {
      initialStart = 0;
    }

    const dynamicDataZoomConfig = {
      type: "inside",
      start: initialStart,
      end: 100,
      zoomOnMouseWheel: true,
      moveOnMouseMove: totalLength > INITIAL_VISIBLE_COUNT,
      moveOnMouseWheel: false,
      zoomLock: false,
      minSpan: normalizedMinSpan,
      maxSpan: normalizedMaxSpan,
    };

    const candlestickOption = {
      backgroundColor: "transparent",
      animation: false,
      grid: {
        left: 0,
        right: 0,
        top: 40,
        bottom: 40,
        containLabel: false,
        borderColor: "#666",
        borderWidth: 1,
      },
      xAxis: {
        type: "category",
        data: xAxisData,
        boundaryGap: false,
        position: "bottom",
        axisLine: { lineStyle: { color: "#666" } },
        axisTick: { show: false },
        axisLabel: {
          color: "#999",
          interval: 0,
          hideOverlap: true,
          formatter: axisLabelFormatter,
        },
        axisPointer: {
          show: true,
          type: "line",
          label: {
            show: true,
            backgroundColor: "#666",
            color: "#fff",
            padding: [4, 8],
            borderRadius: 4,
            formatter: function (params) {
              let format = "YYYY/MM/DD HH:mm";
              if (["4h"].includes(selectedPeriodComputed.value)) {
                format = "YYYY/MM/DD HH:mm";
              } else if (["1d", "1w"].includes(selectedPeriodComputed.value)) {
                format = "YYYY/MM/DD HH:mm";
              }

              const raw = chartRawData.value;
              if (!raw || !raw.length) return params.value || "";

              let idx = undefined;
              if (
                Array.isArray(params.seriesData) &&
                params.seriesData.length &&
                Number.isFinite(params.seriesData[0]?.dataIndex)
              ) {
                idx = params.seriesData[0].dataIndex;
              } else if (Number.isFinite(params.dataIndex)) {
                idx = params.dataIndex;
              } else if (params.value != null) {
                const target = String(params.value);
                idx = raw.findIndex((it) =>
                  dayjs(it.dtStart).format(
                    ["1d", "1w"].includes(selectedPeriodComputed.value)
                      ? "YYYY/MM/DD"
                      : ["4h"].includes(selectedPeriodComputed.value)
                      ? "YYYY-MM-DD HH:mm"
                      : "HH:mm"
                  ) === target
                );
              }

              if (!Number.isFinite(idx)) return params.value || "";
              const clamped = Math.max(0, Math.min(Math.round(idx), raw.length - 1));
              const dt = raw[clamped]?.dtStart;
              return dt ? dayjs(dt).format(format) : params.value || "";
            },
          },
          snap: false,
        },
        splitLine: {
          show: false,
          lineStyle: { color: "#333", opacity: 0.3 },
        },
      },
      yAxis: {
        type: "value",
        position: "right",
        scale: true,
        z: 50,
        axisLine: { lineStyle: { color: "#666" } },
        axisLabel: {
          color: "#999",
          inside: true,
          formatter: function (value) {
            return formatNumberSmart(value, { decimals: 2 });
          },
          interval: "auto",
          showMaxLabel: true,
          showMinLabel: true,
          margin: 4,
        },
        axisPointer: {
          show: true,
          label: {
            show: true,
            backgroundColor: "#666",
            color: "#fff",
            padding: [4, 8],
            borderRadius: 4,
            z: 10,
            formatter: function (params) {
              return formatNumberSmart(params.value, { decimals: 2 });
            },
          },
        },
        splitLine: {
          show: true,
          lineStyle: { color: "#333", opacity: 0.3 },
        },
      },
      dataZoom: [
        {
          ...dynamicDataZoomConfig,
          xAxisIndex: 0
        }
      ],
      tooltip: {
        trigger: "axis",
        backgroundColor: "rgba(0, 0, 0, 0.7)",
        borderColor: "#333",
        textStyle: { color: "#fff" },
        axisPointer: {
          type: "cross",
          lineStyle: {
            color: "#666",
            type: "dashed",
            width: 1,
          },
          crossStyle: {
            color: "#666",
            type: "dashed",
            width: 1,
          },
          animation: false,
          snap: false,
          triggerTooltip: true,
        },
        formatter: function () {
          return "";
        },
        position: function () {
          return [-999, -999];
        },
      },
      series: [
        {
          type: "candlestick",
          data: kLineData,
          clip: true,
          barWidth: "60%",
          barCategoryGap: "0",
          barGap: "0",
          barMinWidth: 10,
          barMaxWidth: 11,
          z: 1,
          itemStyle: {
            color: "#00C087",
            color0: "#FF5B5E",
            borderColor: "#00C087",
            borderColor0: "#FF5B5E",
          },
        },
      ],
    };

    const lineChartOption = {
      backgroundColor: "transparent",
      animation: false,
      grid: {
        left: 0,
        right: 0,
        top: 6,
        bottom: 6,
        containLabel: false,
        borderColor: "#666",
        borderWidth: 1,
      },
      xAxis: {
        type: "category",
        data: xAxisData,
        boundaryGap: false,
        axisLine: { show: false },
        axisTick: { show: false },
        axisLabel: { show: false },
        axisPointer: {
          show: true,
          type: "line",
          lineStyle: {
            color: "#666",
            type: "dashed",
          },
          label: {
            show: false,
          },
          snap: false,
        },
        splitLine: {
          show: false,
          lineStyle: { color: "#333", opacity: 0.3 },
        },
      },
      yAxis: {
        type: "value",
        position: "right",
        scale: true,
        z: 50,
        axisLine: { lineStyle: { color: "#666" } },
        axisLabel: {
          color: "#999",
          inside: true,
          formatter: function (value) {
            return formatNumberSmart(value, { decimals: 2 });
          },
          interval: "auto",
          showMaxLabel: true,
          showMinLabel: true,
          margin: 4,
        },
        axisPointer: {
          show: true,
          label: {
            show: true,
            backgroundColor: "#666",
            color: "#fff",
            padding: [4, 8],
            borderRadius: 4,
            z: 10,
            formatter: function (params) {
              return formatNumberSmart(params.value, { decimals: 2 });
            },
          },
        },
        splitNumber: 3,
        splitLine: {
          show: true,
          lineStyle: { color: "#333", opacity: 0.3 },
        },
      },
      dataZoom: [
        {
          ...dynamicDataZoomConfig,
          xAxisIndex: 0,
        },
      ],
      tooltip: {
        trigger: "axis",
        backgroundColor: "rgba(0, 0, 0, 0.7)",
        borderColor: "#333",
        textStyle: { color: "#fff" },
        axisPointer: {
          type: "cross",
          lineStyle: {
            color: "#666",
            type: "dashed",
            width: 1,
          },
          crossStyle: {
            color: "#666",
            type: "dashed",
            width: 1,
          },
          animation: false,
          snap: false,
          triggerTooltip: true,
        },
        formatter: function () {
          return "";
        },
        position: function () {
          return [-999, -999];
        },
      },
      series: [
        {
          name: "Sentiment",
          type: "line",
          data: sentimentData,
          symbol: "none",
          smooth: false,
          z: 1,
          lineStyle: {
            color: "#00C087",
            width: 2,
          },
          areaStyle: {
            color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
              { offset: 0, color: "rgba(0, 192, 135, 0.3)" },
              { offset: 1, color: "rgba(0, 192, 135, 0.1)" },
            ]),
          },
        },
      ],
    };

    candlestickInstance.setOption({ graphic: [] }, { notMerge: false });
    lineChartInstance.setOption({ graphic: [] }, { notMerge: false });

    candlestickInstance.setOption(candlestickOption);
    updateAxisLabelSpacing();
    lineChartInstance.setOption(lineChartOption);

    setTimeout(() => updateFixedLabels(), 100);

    if (
      isAppend &&
      candlestickInstance &&
      oldStartValue !== null &&
      oldEndValue !== null
    ) {
      candlestickInstance.dispatchAction({
        type: "dataZoom",
        startValue: oldStartValue + addCount,
        endValue: oldEndValue + addCount,
      });
      lineChartInstance.dispatchAction({
        type: "dataZoom",
        startValue: oldStartValue + addCount,
        endValue: oldEndValue + addCount,
      });
    }
  } catch (e) {
    console.error("图表数据获取失败", e);
  } finally {
    isLoading = false;
  }
};

const resizeCharts = () => {
  if (candlestickInstance && lineChartInstance) {
    candlestickInstance.resize();
    lineChartInstance.resize();
    setTimeout(() => updateFixedLabels(), 100);
  }
};

// 防止关闭后立刻又弹出
let justClosed = false;
const closeDialog = (e) => {
  if (e) e.stopPropagation();
  showTooltip.value = false;
  justClosed = true;
  setTimeout(() => { justClosed = false; }, 150);
};

const handleChartClick = (e) => {
  if (justClosed) return;
  const dataArr = chartRawData.value;
  if (!dataArr.length) return;
  const candlestickRect = candlestickChart.value.getBoundingClientRect();
  const chartOffsetX = e.clientX - candlestickRect.left;
  const chartOffsetY = e.clientY - candlestickRect.top;
  // 限定只在蜡烛图区域有效
  if (chartOffsetX < 0 || chartOffsetX > candlestickRect.width || chartOffsetY < 0 || chartOffsetY > candlestickRect.height) {
    return;
  }
  const pointInPixel = [chartOffsetX, chartOffsetY];
  const pointInGrid = candlestickInstance.convertFromPixel('grid', pointInPixel);
  if (pointInGrid && pointInGrid[0] >= 0) {
    const candlestickOption = candlestickInstance.getOption();
    const dataZoom = candlestickOption.dataZoom[0];
    const totalLength = dataArr.length;
    const startIndex = Math.floor(totalLength * dataZoom.start / 100);
    const endIndex = Math.floor(totalLength * dataZoom.end / 100);
    const dataIndex = Math.round(pointInGrid[0]);
    const actualIndex = Math.max(startIndex, Math.min(dataIndex, endIndex - 1));
    if (actualIndex >= 0 && actualIndex < dataArr.length) {
      const item = dataArr[actualIndex];
      const d = new Date(item.dtStart);
      tooltipData.dtStart = d.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false });
      tooltipData.date = d.toISOString().split('T')[0];
      tooltipData.open = formatNumberSmart(item.openPrice, { decimals: 2 });
      tooltipData.close = formatNumberSmart(item.closePrice, { decimals: 2 });
      tooltipData.low = formatNumberSmart(item.lowPrice, { decimals: 2 });
      tooltipData.high = formatNumberSmart(item.highPrice, { decimals: 2 });
      const processedEmotional = (parseFloat(item.emotional) + 1) * 1000;
      tooltipData.predict = formatNumberSmart(processedEmotional, { decimals: 2 });
      showTooltip.value = true;
    }
  }
};

onMounted(() => {
  // 延时保证 DOM 渲染完毕再初始化图表
  setTimeout(() => {
    candlestickInstance = echarts.init(candlestickChart.value, null, {
      renderer: "svg",
    });
    lineChartInstance = echarts.init(lineChart.value, null, {
      renderer: "svg",
    });

    echarts.connect([candlestickInstance, lineChartInstance]);
    candlestickInstance.group = "chartGroup";
    lineChartInstance.group = "chartGroup";

    let isSyncingDataZoom = false;

    candlestickInstance.on("dataZoom", function (params) {
      if (params.batch && !isSyncingDataZoom) {
        isSyncingDataZoom = true;
        try {
          lineChartInstance.dispatchAction({
            type: "dataZoom",
            start: params.batch[0].start,
            end: params.batch[0].end,
          });
          if (params.batch[0].start === 0 && !isLoading) {
            updateChartData(true);
          }
          updateFixedLabels();
          updateAxisLabelSpacing();
        } finally {
          setTimeout(() => {
            isSyncingDataZoom = false;
          }, 10);
        }
      }
    });

    lineChartInstance.on("dataZoom", function (params) {
      if (params.batch && !isSyncingDataZoom) {
        isSyncingDataZoom = true;
        try {
          candlestickInstance.dispatchAction({
            type: "dataZoom",
            start: params.batch[0].start,
            end: params.batch[0].end,
          });
          updateFixedLabels();
          updateAxisLabelSpacing();
        } finally {
          setTimeout(() => {
            isSyncingDataZoom = false;
          }, 10);
        }
      }
    });

    let isSyncingAxisPointer = false;

    const syncAxisPointer = (sourceChart, targetChart, xPixel, yPixel) => {
      if (isSyncingAxisPointer) return;

      try {
        isSyncingAxisPointer = true;
        const pointInGrid = sourceChart.convertFromPixel("grid", [xPixel, yPixel]);
        if (pointInGrid && pointInGrid[0] >= 0) {
          const dataIndex = Math.round(pointInGrid[0]);
          targetChart.dispatchAction({
            type: "showTip",
            seriesIndex: 0,
            dataIndex: dataIndex,
          });
        }
      } finally {
        isSyncingAxisPointer = false;
      }
    };

    candlestickInstance.getZr().on("mousemove", (e) => {
      syncAxisPointer(candlestickInstance, lineChartInstance, e.offsetX, e.offsetY);
    });

    lineChartInstance.getZr().on("mousemove", (e) => {
      syncAxisPointer(lineChartInstance, candlestickInstance, e.offsetX, e.offsetY);
    });

    let isHidingAxisPointers = false;
    const hideBothAxisPointers = () => {
      if (isHidingAxisPointers || !candlestickInstance || !lineChartInstance) {
        return;
      }

      isHidingAxisPointers = true;

      const wasSyncing = isSyncingAxisPointer;
      isSyncingAxisPointer = true;

      echarts.disconnect([candlestickInstance, lineChartInstance]);

      try {
        candlestickInstance.dispatchAction({
          type: "hideTip",
        });

        lineChartInstance.dispatchAction({
          type: "hideTip",
        });
      } catch (error) {
        console.warn("隐藏 axisPointer 时出错:", error);
      }

      setTimeout(() => {
        try {
          echarts.connect([candlestickInstance, lineChartInstance]);
        } catch (error) {
          console.warn("重新连接图表时出错:", error);
        }
        isSyncingAxisPointer = wasSyncing;
        isHidingAxisPointers = false;
      }, 10);
    };

    const showBothAxisPointers = () => {
      if (candlestickInstance && lineChartInstance) {
        candlestickInstance.setOption(
          {
            tooltip: {
              axisPointer: {
                show: true,
              },
            },
          },
          { notMerge: false }
        );

        lineChartInstance.setOption(
          {
            tooltip: {
              axisPointer: {
                show: true,
              },
            },
          },
          { notMerge: false }
        );
      }
    };

    let lastMouseX = 0;
    let lastMouseY = 0;

    documentMouseMoveHandler = (e) => {
      lastMouseX = e.clientX;
      lastMouseY = e.clientY;
    };
    document.addEventListener("mousemove", documentMouseMoveHandler);

    const isMouseInAnyChart = () => {
      if (!candlestickChart.value || !lineChart.value) return false;

      const candlestickRect = candlestickChart.value.getBoundingClientRect();
      const lineChartRect = lineChart.value.getBoundingClientRect();

      const inCandlestick =
        lastMouseX >= candlestickRect.left &&
        lastMouseX <= candlestickRect.right &&
        lastMouseY >= candlestickRect.top &&
        lastMouseY <= candlestickRect.bottom;

      const inLineChart =
        lastMouseX >= lineChartRect.left &&
        lastMouseX <= lineChartRect.right &&
        lastMouseY >= lineChartRect.top &&
        lastMouseY <= lineChartRect.bottom;

      return inCandlestick || inLineChart;
    };

    candlestickInstance.getZr().on("mouseout", () => {
      requestAnimationFrame(() => {
        if (!isMouseInAnyChart()) {
          hideBothAxisPointers();
        }
      });
    });

    lineChartInstance.getZr().on("mouseout", () => {
      requestAnimationFrame(() => {
        if (!isMouseInAnyChart()) {
          hideBothAxisPointers();
        }
      });
    });

    const handleMouseMove = (e) => {
      const rect = chartsContainer.value.getBoundingClientRect();
      const offsetX = e.clientX - rect.left;
      const offsetY = e.clientY - rect.top;

      const dataArr = chartRawData.value;
      if (!dataArr.length) {
        showTooltip.value = false;
        return;
      }

      const candlestickRect = candlestickChart.value.getBoundingClientRect();
      const lineChartRect = lineChart.value.getBoundingClientRect();
      const GRID_RIGHT_MARGIN = 0;
      const CANDLE_GRID_TOP = 40;
      const CANDLE_GRID_BOTTOM = 40;
      const LINE_GRID_TOP = 6;
      const LINE_GRID_BOTTOM = 6;

      const candleLocalY = e.clientY - candlestickRect.top;
      const candleLocalX = e.clientX - candlestickRect.left;
      const isInCandlestickChart =
        candleLocalY >= CANDLE_GRID_TOP &&
        candleLocalY <= candlestickRect.height - CANDLE_GRID_BOTTOM &&
        candleLocalX >= 0 &&
        candleLocalX <= candlestickRect.width - GRID_RIGHT_MARGIN;

      const lineLocalY = e.clientY - lineChartRect.top;
      const lineLocalX = e.clientX - lineChartRect.left;
      const isInLineChart =
        lineLocalY >= LINE_GRID_TOP &&
        lineLocalY <= lineChartRect.height - LINE_GRID_BOTTOM &&
        lineLocalX >= 0 &&
        lineLocalX <= lineChartRect.width - GRID_RIGHT_MARGIN;

      if (!isInCandlestickChart && !isInLineChart) {
        showTooltip.value = false;
        candlestickInstance.dispatchAction({
          type: "hideTip",
        });
        lineChartInstance.dispatchAction({
          type: "hideTip",
        });
        return;
      }

      let sourceChart = isInCandlestickChart
        ? candlestickInstance
        : isInLineChart
        ? lineChartInstance
        : candlestickInstance;
      let sourceRect = isInCandlestickChart
        ? candlestickRect
        : isInLineChart
        ? lineChartRect
        : candlestickRect;

      const chartOffsetX = e.clientX - sourceRect.left;
      const chartOffsetY = e.clientY - sourceRect.top;

      const candlestickOption = candlestickInstance.getOption();
      const dataZoom = candlestickOption.dataZoom[0];
      const totalLength = dataArr.length;
      const startIndex = Math.floor((totalLength * dataZoom.start) / 100);
      const endIndex = Math.floor((totalLength * dataZoom.end) / 100);

      const pointInPixel = [chartOffsetX, chartOffsetY];
      let pointInGrid = null;

      try {
        pointInGrid = sourceChart.convertFromPixel("grid", pointInPixel);
      } catch (e) {
        pointInGrid = null;
      }

      let dataIndex;
      if (pointInGrid && pointInGrid[0] >= 0) {
        dataIndex = Math.round(pointInGrid[0]);
      } else {
        const gridLeft = 0;
        const gridRight = sourceRect.width - 0;

        if (chartOffsetX < gridLeft) {
          dataIndex = startIndex;
        } else if (chartOffsetX > gridRight) {
          dataIndex = endIndex - 1;
        } else {
          const relativeX = (chartOffsetX - gridLeft) / (gridRight - gridLeft);
          dataIndex = Math.round(startIndex + (endIndex - startIndex) * relativeX);
        }
      }

      const actualIndex = Math.max(
        startIndex,
        Math.min(dataIndex, endIndex - 1)
      );

      if (actualIndex >= 0 && actualIndex < dataArr.length) {
        const item = dataArr[actualIndex];
        const d = new Date(item.dtStart);
        tooltipData.dtStart = d.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false });
        tooltipData.date = d.toISOString().split('T')[0];
        tooltipData.open = formatNumberSmart(item.openPrice, { decimals: 2 });
        tooltipData.close = formatNumberSmart(item.closePrice, { decimals: 2 });
        tooltipData.low = formatNumberSmart(item.lowPrice, { decimals: 2 });
        tooltipData.high = formatNumberSmart(item.highPrice, { decimals: 2 });
        const processedEmotional = (parseFloat(item.emotional) + 1) * 1000;
        tooltipData.predict = formatNumberSmart(processedEmotional, {
          decimals: 2,
        });

        // 移动端使用点击弹窗，不在鼠标移动时显示
        // showTooltip.value = true;
      } else {
        showTooltip.value = false;
      }
    };

    chartsContainer.value.addEventListener("mousemove", handleMouseMove);

    chartsContainer.value.addEventListener("mouseleave", () => {
      showTooltip.value = false;
      hideBothAxisPointers();
    });

    window.addEventListener("resize", resizeCharts);

    isChartReady.value = true;
    updateChartData(false);
    resizeCharts();
  }, 100);
});

watch(
  () => props.selectedPeriod,
  (newVal, oldVal) => {
    // 只有当 props.selectedPeriod 变化时才更新（避免与 setTimePeriod 重复调用）
    if (newVal && newVal !== oldVal && isChartReady.value) {
      updateChartData(false);
    }
  }
);

onUnmounted(() => {
  window.removeEventListener("resize", resizeCharts);
  if (chartsContainer.value) {
    chartsContainer.value.removeEventListener("mousemove", null);
    chartsContainer.value.removeEventListener("mouseleave", null);
  }
  if (candlestickInstance) candlestickInstance.dispose();
  if (lineChartInstance) lineChartInstance.dispose();
  if (documentMouseMoveHandler) {
    document.removeEventListener("mousemove", documentMouseMoveHandler);
    documentMouseMoveHandler = null;
  }
});
</script>

<style lang="scss" scoped>
.sentiment-chart-container {
  width: 100%;
  border-radius: 8px;
  color: #fff;
  position: relative;
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  margin-bottom: 30px;

  .chart-header {
    margin-bottom: 18px;

    .chart-title-box {
      display: flex;
      align-items: center;
      gap: 4px;
      margin-bottom: 9.5px;
    }

    .chart-title {
      font-size: 14px;
      font-weight: 600;
      margin: 0;
    }

    .info-icon {
      margin-right: auto;
      margin-left: 4px;
      cursor: pointer;
      opacity: 0.7;

      &:hover {
        opacity: 1;
      }
    }

    .time-filters {
      display: flex;
      justify-content: space-between;
      padding: 2px;
      background-color: #302D4A;
      border-radius: 8px;

      .time-filter-btn {
        background-color: #302D4A;
        border: none;
        border-radius: 8px;
        color: #9E9CB6;
        padding: 8px 15px;
        font-size: 12px;
        cursor: pointer;
        transition: background-color 0.2s;

        &:hover {
          background: #343348;
        }

        &.active {
          background: #17152A;
          color: #fff;
        }
      }
    }
  }

  .charts-wrapper {
    flex: 1;
    position: relative;
    width: 100%;
    overflow: hidden;

    .charts-inner {
      width: 100%;
      height: 100%;
      display: flex;
      flex-direction: column;
      gap: 0;

      .candlestick-chart {
        width: 100%;
        height: 260px;
        min-height: 260px;
        overscroll-behavior: auto;
      }

      .line-chart {
        width: 100%;
        height: 110px;
        min-height: 110px;
        margin-top: 0;
        overscroll-behavior: auto;
      }
    }
  }

  /* 底部弹窗样式，参考 GreedIndexChart.vue */
  .bottom-dialog-mask {
    position: fixed;
    left: 0;
    top: 0;
    width: 100vw;
    height: 100vh;
    background: rgba(28, 24, 51, 0.4);
    z-index: 2000;
    display: flex;
    align-items: flex-end;
    justify-content: center;
  }

  .bottom-dialog {
    width: 100%;
    background: #282544;
    border-radius: 12px 12px 0 0;
    box-shadow: 0 0 12px rgba(0, 0, 0, 0.18);
    padding: 16px 12px;
    margin-bottom: 0;
    animation: slideUp 0.25s cubic-bezier(0.4, 0, 0.2, 1);
  }

  @keyframes slideUp {
    from {
      transform: translateY(100%);
    }

    to {
      transform: translateY(0);
    }
  }

  .dialog-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 14px;
  }

  .dialog-title {
    font-size: 14px;
    font-weight: 600;
    color: #fff;
    display: flex;
    align-items: center;

    .qb-icon {
      width: 18px;
      height: 18px;
      margin-right: 6px;
    }
  }

  .dialog-date {
    font-size: 11px;
    color: #9E9CB6;
  }

  .panel-metrics {
    flex: 1;
    display: flex;
    flex-direction: column;
    gap: 6px;
  }

  .metrics-row {
    display: flex;
    justify-content: space-between;
    margin-bottom: 12px;
  }

  .metric {
    flex: 1;
    display: flex;
    gap: 6px;
    font-family: Tomato Grotesk;
    font-weight: 500;
    font-size: 14px;
    line-height: 14px;
    letter-spacing: 0%;
    vertical-align: middle;
    text-transform: capitalize;
color:#fff;
padding-left: 11px;
    position: relative;
    &::before{
      content: '';
      display: block;
      width: 5px;
      height: 5px;
      background: #fff;
      border-radius: 50%;
      position: absolute;
      left: 0;
      top: 50%;
      transform: translateY(-50%);
    }
  }


  .dialog-footer {
    display: flex;
    justify-content: center;
    margin-top: 21px;
  }

  .dialog-close-btn {
    margin-top: 6px;
    margin-bottom: 5px;
    width: 100%;
    height: 42px;
    border: none;
    border-radius: 6px;
    background: #39365A;
    color: #fff;
    font-size: 14px;
    font-weight: 600;
    cursor: pointer;
    transition: background 0.2s;
  }

  .dialog-close-btn:hover {
    background: #4B476B;
  }
}
</style>