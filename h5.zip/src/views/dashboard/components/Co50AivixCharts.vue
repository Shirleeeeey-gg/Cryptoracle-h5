<template>
  <div class="aivix-container">
    <div class="chart-header">
      <div class="title">
        <span>CO10 AIVIX</span>
        <Tooltip
          content="Cryptoracle aggregates cryptocurrency prices and trading volumes from multiple exchanges, automatically compiling the top 50 tokens by market capitalization to calculate the CO50 Composite Index using a weighted average methodology."
        />
      </div>
      <div class="header-right">
        <div class="view-list-btn" @click="viewCO50List">
          <span>View CO10 List</span>
          <img :src="arrowIcon" alt="arrow" class="arrow-icon" />
        </div>
      </div>
    </div>

    <div class="controls-row">
      <div class="chart-legend">
        <div class="legend-item">
          <span class="legend-dot white"></span>
          <span>CO50 AIVIX</span>
    </div>
        <div class="legend-item">
          <span class="legend-dot purple"></span>
          <span>CO50 Social Volume Index</span>
        </div>
        <div class="legend-item">
          <span class="legend-dot green"></span>
          <span>CO50 Index</span>
        </div>
      </div>
      <div class="time-filter">
        <div
          v-for="filter in timeFilters"
          :key="filter.value"
          class="time-filter-item"
          :class="{ active: currentTimeFilter === filter.value }"
          @click="changeTimeFilter(filter.value)"
        >
          {{ filter.label }}
            </div>
            </div>
          </div>

    <div class="charts-container" ref="chartsContainer">
      <!-- 上方图表 -->
      <div class="upper-chart" ref="upperChartRef" @click="handleChartClick"></div>

      <!-- 下方图表 -->
      <div class="lower-chart" ref="lowerChartRef" @click="handleChartClick"></div>
        </div>

    <!-- 底部弹窗 -->
    <div v-if="bottomDialogVisible" class="bottom-dialog-mask" @click.self="closeBottomDialog">
      <div class="bottom-dialog">
        <!-- 拖拽手柄 -->
        <div class="dialog-handle"></div>
        
        <div class="dialog-header">
          <span class="dialog-title">
            <div class="dialog-icon">
              <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                <circle cx="9" cy="9" r="9" fill="#16C784"/>
                <path d="M9 3L10.5 7.5L15 9L10.5 10.5L9 15L7.5 10.5L3 9L7.5 7.5L9 3Z" fill="white"/>
              </svg>
            </div>
            <span>CO50 AIVIX</span>
          </span>
          <span class="dialog-date">{{ bottomDialogData.dateTime }}</span>
        </div>

        <div class="dialog-data-section">
          <div class="data-row">
            <span class="data-indicator indicator-grey"></span>
            <span class="data-label">CO50 Social Volume:</span>
            <span class="data-value">{{ bottomDialogData.socialVolume }}</span>
        </div>
          <div class="data-row">
            <span class="data-indicator indicator-purple"></span>
            <span class="data-label">CO50 Index:</span>
            <span class="data-value">{{ bottomDialogData.index }}</span>
        </div>
          <div class="data-row">
            <span class="data-indicator indicator-green"></span>
            <span class="data-label">CO50 AIVIX:</span>
            <span class="data-value">{{ bottomDialogData.aivix }}</span>
            </div>
            </div>

        <div class="dialog-footer">
          <button class="dialog-close-btn" @click="closeBottomDialog">Close</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, onBeforeUnmount, nextTick, getCurrentInstance } from "vue";
import * as echarts from "echarts";
import arrowIcon from "@/assets/dashboard/icon-link-arrow-r.svg";
import Tooltip from "./Tooltip.vue";
import { getAivixChartDataApi } from "@/api/dashboard";
import { useRouter } from 'vue-router';
import { formatNumberSmart } from '@/utils/format';

// 图表实例
let upperChartInstance = null;
let lowerChartInstance = null;

// 时间筛选参数
const timeFilters = [
  { label: "15 Min", value: "15m" },
  { label: "30 Min", value: "30m" },
  { label: "1H", value: "1h" },
  { label: "4H", value: "4h" },
  { label: "1D", value: "1d" },
  { label: "7D", value: "1w" },
];
const currentTimeFilter = ref("1h");

// DOM引用
const upperChartRef = ref(null);
const lowerChartRef = ref(null);
const chartsContainer = ref(null);

// 跟踪当前高亮的数据点
let currentHighlightIndex = -1;

// 底部弹窗相关
const bottomDialogVisible = ref(false);
const bottomDialogData = ref({
  dateTime: '',
  socialVolume: '',
  index: '',
  aivix: ''
});

// 数字格式化
const decimalFormat = (n) => {
  const num = Number(n);
  if (Number.isFinite(num)) return formatNumberSmart(num, { decimals: 2, useUnit: false });
  return '-';
};

// 图表数据（统一结构）
// time: 时间戳(ms) - 取接口 dtStart
// aivix: CO50 AIVIX（映射 emotional）
// index: CO50 Index（映射 price）
// volume: CO50 Social Volume Index（映射 speakVolume）
const chartData = ref([]);

// 加载锁，防止重复请求
let isLoading = false;

// 时间粒度对应毫秒
const getIntervalMs = (timeType) => {
  switch (timeType) {
    case "15m": return 15 * 60 * 1000;
    case "30m": return 30 * 60 * 1000;
    case "1h": return 60 * 60 * 1000;
    case "4h": return 4 * 60 * 60 * 1000;
    case "1d": return 24 * 60 * 60 * 1000;
    case "1w": return 7 * 24 * 60 * 60 * 1000;
    default: return 60 * 60 * 1000;
  }
};

// 计算一屏大致需要的点位数量（根据不同时间粒度返回30个数据点，减少数据量以增加柱子间距）
const getPointsPerScreen = () => {
  return 30;
};

// 时间格式化：YYYY-MM-DD HH:mm:ss
const pad2 = (n) => String(n).padStart(2, '0');
const formatTimeStr = (ts) => {
  const d = new Date(ts);
  return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())} ${pad2(d.getHours())}:${pad2(d.getMinutes())}:${pad2(d.getSeconds())}`;
};

// 当前窗口配置
const currentEndTimeMs = ref(0);
const windowDurationMs = ref(0);

// 将接口数据转换成图表结构（并按时间升序）
const normalizeAivixData = (list = []) => {
  const mapped = list.map((item) => {
    const ts = new Date(item.dtStart.replace(/-/g, '/')).getTime();
    return {
      time: ts,
      aivix: item.emotional, // AIVIX
      index: item.price, // Index
      volume: item.speakVolume, // Social Volume
    };
  });
  mapped.sort((a, b) => a.time - b.time);
  return mapped;
};

// 获取图表数据（支持分页加载）
const fetchChartData = async (timeType, isAppend = false) => {
  if (isLoading) return;
  isLoading = true;
  
  try {
    let endTime;
    let oldStartValue = null;
    let oldEndValue = null;
    
    if (isAppend && chartData.value.length > 0) {
      endTime = chartData.value[0].time;
      
      if (upperChartInstance) {
        const option = upperChartInstance.getOption();
        if (option.dataZoom && option.dataZoom[0]) {
          oldStartValue = option.dataZoom[0].startValue;
          oldEndValue = option.dataZoom[0].endValue;
        }
      }
    } else {
      endTime = Date.now();
    }
    
    const params = {
      timeType,
      startTime: formatTimeStr(endTime - windowDurationMs.value),
      endTime: formatTimeStr(endTime),
    };
    
    const res = await getAivixChartDataApi(params);
    if (res && res.code === 200 && Array.isArray(res.data)) {
      const newData = normalizeAivixData(res.data);
      
      if (isAppend) {
        chartData.value = [...newData, ...chartData.value];
      } else {
        chartData.value = newData;
      }
      
      updateCharts();
      updateYAxisValueBox();
      updateLowerYAxisValueBox();
      
      if (isAppend && upperChartInstance && oldStartValue !== null && oldEndValue !== null) {
        upperChartInstance.dispatchAction({
          type: "dataZoom",
          startValue: oldStartValue,
          endValue: oldEndValue,
        });
        lowerChartInstance.dispatchAction({
          type: "dataZoom",
          startValue: oldStartValue,
          endValue: oldEndValue,
        });
      }
    }
  } catch (e) {
    console.error("图表数据获取失败", e);
  } finally {
    isLoading = false;
  }
};

// 初次加载数据（或切换时间粒度时）
const fetchInitialWindow = async () => {
  const interval = getIntervalMs(currentTimeFilter.value);
  const points = getPointsPerScreen();
  windowDurationMs.value = interval * points;
  await fetchChartData(currentTimeFilter.value);
};

// 时间筛选切换
const changeTimeFilter = async (value) => {
  currentTimeFilter.value = value;
  await fetchInitialWindow();
};

const router = useRouter();
// View CO50 List按钮点击
const viewCO50List = () => {
  // 移动端可能需要跳转到token列表页面，根据实际路由调整
  router.push({name:'token-list',query:{type:'co10'}})
};

// 初始化图表
const initCharts = () => {
  if (!upperChartRef.value || !lowerChartRef.value) return;

  upperChartInstance = echarts.init(upperChartRef.value);
  lowerChartInstance = echarts.init(lowerChartRef.value);

  setupChartInteraction();
  fetchInitialWindow();
};

// 更新图表数据
const updateCharts = () => {
  if (!upperChartInstance || !lowerChartInstance) return;

  const data = chartData.value;
  const times = data.map((item) => new Date(item.time));
  const volumes = data.map((item) => item.volume);
  const aivixValues = data.map((item) => (item.aivix + 1) * 1000);
  const indices = data.map((item) => item.index);

  // 计算上方图表右轴（AIVIX）的动态范围和均匀间隔
  let upperRightMin = null;
  let upperRightMax = null;
  let upperRightInterval = null;
  if (aivixValues.length > 0) {
    const minValue = Math.min(...aivixValues);
    const maxValue = Math.max(...aivixValues);
    const range = maxValue - minValue;
    const padding = range * 0.1;
    upperRightMin = minValue - padding;
    upperRightMax = maxValue + padding;
    
    const totalRange = upperRightMax - upperRightMin;
    const desiredSegments = 5;
    const rawInterval = totalRange / desiredSegments;
    
    const magnitude = Math.floor(Math.log10(Math.abs(rawInterval)));
    const normalized = rawInterval / Math.pow(10, magnitude);
    
    let niceInterval;
    if (normalized <= 1) niceInterval = 1;
    else if (normalized <= 2) niceInterval = 2;
    else if (normalized <= 5) niceInterval = 5;
    else niceInterval = 10;
    
    niceInterval = niceInterval * Math.pow(10, magnitude);
    
    const actualRange = niceInterval * desiredSegments;
    const center = (upperRightMin + upperRightMax) / 2;
    upperRightMin = center - actualRange / 2;
    upperRightMax = center + actualRange / 2;
    upperRightInterval = niceInterval;
  }

  // 获取 X 轴刻度配置（根据时间粒度）
  const getXAxisConfig = () => {
    const timeFilter = currentTimeFilter.value;
    let minInterval = null;
    let formatter = null;

    switch (timeFilter) {
      case "15m": {
        minInterval = 60 * 60 * 1000;
        let lastYear = null;
        let lastMonth = null;
        let lastDay = null;
        formatter = (value) => {
          const date = new Date(value);
          const year = date.getFullYear();
          const month = date.getMonth() + 1;
          const day = date.getDate();
          const hours = String(date.getHours()).padStart(2, '0');
          const minutes = String(date.getMinutes()).padStart(2, '0');

          const isCrossDay = lastDay !== null && (lastDay !== day || lastMonth !== month || lastYear !== year);
          const isCrossYear = lastYear !== null && lastYear !== year;

          lastYear = year;
          lastMonth = month;
          lastDay = day;

          if (isCrossYear) {
            return `${year} ${String(month).padStart(2, '0')}/${String(day).padStart(2, '0')}`;
          } else if (isCrossDay) {
            return `${String(month).padStart(2, '0')}/${String(day).padStart(2, '0')}`;
          } else {
            return `${hours}:${minutes}`;
          }
        };
        break;
      }
      case "30m": {
        minInterval = 2 * 60 * 60 * 1000;
        let lastYear = null;
        let lastMonth = null;
        let lastDay = null;
        formatter = (value) => {
          const date = new Date(value);
          const year = date.getFullYear();
          const month = date.getMonth() + 1;
          const day = date.getDate();
          const hours = String(date.getHours()).padStart(2, '0');
          const minutes = String(date.getMinutes()).padStart(2, '0');

          const isCrossDay = lastDay !== null && (lastDay !== day || lastMonth !== month || lastYear !== year);
          const isCrossYear = lastYear !== null && lastYear !== year;

          lastYear = year;
          lastMonth = month;
          lastDay = day;

          if (isCrossYear) {
            return `${year} ${String(month).padStart(2, '0')}/${String(day).padStart(2, '0')}`;
          } else if (isCrossDay) {
            return `${String(month).padStart(2, '0')}/${String(day).padStart(2, '0')}`;
          } else {
            return `${hours}:${minutes}`;
          }
        };
        break;
      }
      case "1h": {
        minInterval = 4 * 60 * 60 * 1000;
        let lastYear = null;
        let lastMonth = null;
        let lastDay = null;
        formatter = (value) => {
          const date = new Date(value);
          const year = date.getFullYear();
          const month = date.getMonth() + 1;
          const day = date.getDate();
          const hours = String(date.getHours()).padStart(2, '0');
          const minutes = String(date.getMinutes()).padStart(2, '0');

          const isCrossDay = lastDay !== null && (lastDay !== day || lastMonth !== month || lastYear !== year);
          const isCrossYear = lastYear !== null && lastYear !== year;

          lastYear = year;
          lastMonth = month;
          lastDay = day;

          if (isCrossYear) {
            return `${year} ${String(month).padStart(2, '0')}/${String(day).padStart(2, '0')}`;
          } else if (isCrossDay) {
            return `${String(month).padStart(2, '0')}/${String(day).padStart(2, '0')}`;
          } else {
            return `${hours}:${minutes}`;
          }
        };
        break;
      }
      case "4h": {
        minInterval = 24 * 60 * 60 * 1000;
        let lastYear = null;
        formatter = (value) => {
          const date = new Date(value);
          const year = date.getFullYear();
          const month = date.getMonth() + 1;
          const day = date.getDate();

          const isCrossYear = lastYear !== null && lastYear !== year;
          lastYear = year;

          if (isCrossYear) {
            return `${year} ${String(month).padStart(2, '0')}/${String(day).padStart(2, '0')}`;
  } else {
            return `${String(month).padStart(2, '0')}/${String(day).padStart(2, '0')}`;
          }
        };
        break;
      }
      case "1d": {
        minInterval = 4 * 24 * 60 * 60 * 1000;
        let lastYear = null;
        formatter = (value) => {
          const date = new Date(value);
          const year = date.getFullYear();
          const month = date.getMonth() + 1;
          const day = date.getDate();

          const isCrossYear = lastYear !== null && lastYear !== year;
          lastYear = year;

          if (isCrossYear) {
            return `${year} ${String(month).padStart(2, '0')}/${String(day).padStart(2, '0')}`;
          } else {
            return `${String(month).padStart(2, '0')}/${String(day).padStart(2, '0')}`;
          }
        };
        break;
      }
      case "1w": {
        minInterval = 28 * 24 * 60 * 60 * 1000;
        let lastYear = null;
        formatter = (value) => {
          const date = new Date(value);
          const year = date.getFullYear();
          const month = date.getMonth() + 1;
          const day = date.getDate();

          const isCrossYear = lastYear !== null && lastYear !== year;
          lastYear = year;

          if (isCrossYear) {
            return `${year} ${String(month).padStart(2, '0')}/${String(day).padStart(2, '0')}`;
          } else {
            return `${String(month).padStart(2, '0')}/${String(day).padStart(2, '0')}`;
          }
        };
        break;
      }
      default:
        minInterval = 60 * 60 * 1000;
        formatter = (value) => {
          const date = new Date(value);
          const hours = String(date.getHours()).padStart(2, '0');
          return hours;
        };
    }

    return { minInterval, formatter };
  };

  const xAxisConfig = getXAxisConfig();
  const upperOption = {
    backgroundColor: "transparent",
    grid: {
      left: 0,
      right: 0,
      bottom: 30,
      top: 8,
      containLabel: false,
      show: true,
      borderColor: "#322F47",
      borderWidth: 1,
    },
    xAxis: {
      type: "time",
      boundaryGap: false,
      minInterval: xAxisConfig.minInterval,
      axisLine: { show: false },
      axisTick: { show: false },
      axisLabel: {
        show: true,
        color: "#9E9CB6",
        fontSize: 10,
        margin: 10,
        formatter: xAxisConfig.formatter
      },
      splitLine: { show: false },
      axisPointer: {
        type: "line",
        lineStyle: {
          color: "#FFFFFF",
          type: "dashed",
          width: 1
        },
        label: {
          show: true,
          backgroundColor: "#302D4A",
          color: "#FFFFFF",
          borderColor: "#302D4A",
          borderWidth: 1,
          borderRadius: 4,
          padding: [4, 8],
          fontSize: 10,
          formatter: function(params) {
            const date = new Date(params.value);
            const year = date.getFullYear();
            const month = String(date.getMonth() + 1).padStart(2, '0');
            const day = String(date.getDate()).padStart(2, '0');
            const hours = String(date.getHours()).padStart(2, '0');
            const minutes = String(date.getMinutes()).padStart(2, '0');
            const seconds = String(date.getSeconds()).padStart(2, '0');
            return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
          }
        }
      },
    },
    yAxis: [
      {
        type: "value",
        position: "left",
        axisLine: { show: false },
        axisTick: { show: false },
      axisLabel: {
          show: false,
          color: "#9E9CB6",
          fontSize: 10,
      },
      splitLine: {
          show: true,
        lineStyle: {
            color: "#302D4A",
            type: "dashed",
          },
        },
      },
      {
        type: "value",
        position: "right",
        min: upperRightMin,
        max: upperRightMax,
        interval: upperRightInterval,
        minInterval: upperRightInterval,
        scale: false,
        z: 50,
        axisLine: { show: false },
        axisTick: { show: false },
        axisLabel: {
          show: true,
          inside: true,
          color: "#9E9CB6",
          fontSize: 10,
          margin: 4,
          formatter: (value) => {
            return Math.round(value).toLocaleString();
          },
        },
        splitLine: { show: false },
      },
    ],
    series: [
      {
        name: "CO50 Social Volume Index",
        type: "bar",
        yAxisIndex: 0,
        data: times.map((time, index) => [time, volumes[index]]),
        itemStyle: {
          color: "#5E36C9",
          borderRadius: [4, 4, 0, 0],
        },
        barWidth: "60%",
        barGap: "50%",
        barCategoryGap: "50%",
        z: 1,
      },
      {
        name: "CO50 AIVIX",
        type: "line",
        yAxisIndex: 1,
        data: times.map((time, index) => [time, aivixValues[index]]),
        lineStyle: {
          color: "#FFFFFF",
          width: 2,
        },
              itemStyle: {
          color: "#FFFFFF",
          borderColor: "#FFFFFF",
          borderWidth: 2,
        },
        symbol: "circle",
        symbolSize: 6,
        showSymbol: false,
        z: 2,
        emphasis: {
          focus: "series",
        itemStyle: {
            color: "#FFFFFF",
            borderColor: "#FFFFFF",
            borderWidth: 2,
            shadowColor: "rgba(255, 255, 255, 0.5)",
            shadowBlur: 8,
          },
          symbolSize: 6,
        },
      },
    ],
    tooltip: {
      show: false, // 禁用默认 tooltip，使用底部弹窗
    },
    dataZoom: [
      {
        type: "inside",
        xAxisIndex: 0,
        filterMode: "filter",
        zoomOnMouseWheel: false,
        moveOnMouseMove: true,
        moveOnMouseWheel: false,
        zoomLock: true,
        start: 20,
        end: 100,
      },
    ],
  };

  // 计算下方图表 Y 轴的动态范围和均匀间隔
  let lowerMin = null;
  let lowerMax = null;
  let lowerInterval = null;
  if (indices.length > 0) {
    const minValue = Math.min(...indices);
    const maxValue = Math.max(...indices);
    const range = maxValue - minValue;
    const padding = range * 0.1;
    lowerMin = minValue - padding;
    lowerMax = maxValue + padding;
    
    const totalRange = lowerMax - lowerMin;
    const desiredSegments = 5;
    const rawInterval = totalRange / desiredSegments;
    
    const magnitude = Math.floor(Math.log10(Math.abs(rawInterval)));
    const normalized = rawInterval / Math.pow(10, magnitude);
    
    let niceInterval;
    if (normalized <= 1) niceInterval = 1;
    else if (normalized <= 2) niceInterval = 2;
    else if (normalized <= 5) niceInterval = 5;
    else niceInterval = 10;
    
    niceInterval = niceInterval * Math.pow(10, magnitude);
    
    const actualRange = niceInterval * desiredSegments;
    const center = (lowerMin + lowerMax) / 2;
    lowerMin = center - actualRange / 2;
    lowerMax = center + actualRange / 2;
    
    if (lowerMin < 0 && minValue >= 0) {
      lowerMin = 0;
      const adjustedRange = lowerMax - lowerMin;
      if (adjustedRange < actualRange) {
        lowerMax = lowerMin + actualRange;
      }
    }
    
    lowerInterval = niceInterval;
  }

  const lowerOption = {
    backgroundColor: "transparent",
    grid: {
      left: 0,
      right: 0,
      bottom: "3%",
      top: 8,
      containLabel: false,
      show: true,
      borderColor: "#322F47",
      borderWidth: 1,
    },
    xAxis: {
      type: "time",
      boundaryGap: false,
      axisLine: { show: false },
      axisTick: { show: false },
      axisLabel: { show: false },
      splitLine: { show: false },
      axisPointer: {
        show: true,
        type: "line",
        label: { show: false },
        lineStyle: {
          color: "#9E9CB6",
          type: "dashed",
          width: 1,
        },
      },
    },
    yAxis: {
      type: "value",
      position: "right",
      min: lowerMin,
      max: lowerMax,
      interval: lowerInterval,
      minInterval: lowerInterval,
      scale: false,
      z: 50,
      axisLine: { show: false },
      axisTick: { show: false },
      axisLabel: {
        show: true,
        inside: true,
        color: "#9E9CB6",
        fontSize: 10,
        margin: 4,
        formatter: (value) => {
          return Math.round(value).toLocaleString();
        },
      },
      splitLine: {
        show: true,
        lineStyle: {
          color: "#302D4A",
          type: "dashed",
        },
      },
      axisPointer: {
        show: true,
        type: "line",
        lineStyle: {
          color: "#9E9CB6",
          type: "dashed",
          width: 1,
        },
        label: {
          show: true,
          backgroundColor: "#84809D",
          color: "#FFFFFF",
          borderColor: "transparent",
          borderWidth: 0,
          padding: [4, 8],
          formatter: (params) => {
            return Math.round(params.value).toLocaleString();
          },
        },
        z: 200,
      },
    },
    series: [
      {
        name: "CO50 Index",
        type: "line",
        data: times.map((time, index) => [time, indices[index]]),
        lineStyle: {
          color: "#00D4AA",
          width: 2,
        },
        itemStyle: {
          color: "#16C784",
          borderColor: "#FFFFFF",
          borderWidth: 2,
        },
        symbol: "circle",
        symbolSize: 6,
        showSymbol: false,
        z: 10,
        emphasis: {
          focus: "series",
      itemStyle: {
            color: "#16C784",
            borderColor: "#FFFFFF",
            borderWidth: 2,
      },
          symbolSize: 6,
      },
      areaStyle: {
          color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
            { offset: 0, color: "rgba(22, 199, 132, 0.4)" },
            { offset: 1, color: "rgba(22, 199, 132, 0)" },
          ]),
        },
      },
    ],
    tooltip: {
      show: false, // 禁用默认 tooltip，使用底部弹窗
      axisPointer: {
        type: "cross",
        crossStyle: {
          color: "#9E9CB6",
          type: "dashed",
          width: 1,
        },
        animation: false,
      },
    },
    dataZoom: [
      {
        type: "inside",
        xAxisIndex: 0,
        filterMode: "none",
        zoomOnMouseWheel: false,
        moveOnMouseMove: true,
        moveOnMouseWheel: false,
        zoomLock: true,
        start: 20,
        end: 100,
      },
    ],
  };

  upperChartInstance.setOption(upperOption);
  lowerChartInstance.setOption(lowerOption);

  updateYAxisValueBox();
  updateLowerYAxisValueBox();
};

// 计算并绘制Y轴右侧白色方块
const updateYAxisValueBox = () => {
  if (!upperChartInstance || !upperChartRef.value) return;
  const data = chartData.value;
  if (!data || data.length === 0) return;

  const option = upperChartInstance.getOption();
  let visibleEndIndex = data.length - 1;
  
  if (option.dataZoom && option.dataZoom[0] && option.dataZoom[0].end !== undefined) {
    const endPercent = option.dataZoom[0].end;
    visibleEndIndex = Math.floor((endPercent / 100) * (data.length - 1));
  }
  
  const lastPoint = data[visibleEndIndex];
  const lastValue = (lastPoint.aivix + 1) * 1000;

  const pt = upperChartInstance.convertToPixel({ seriesIndex: 1 }, [lastPoint.time, lastValue]);
  const yCenter = pt ? pt[1] : 20;
  const gridRect = upperChartInstance.getModel().getComponent('grid', 0).coordinateSystem.getRect();
  const boxWidth = 50;
  const boxHeight = 22;
  const xRight = gridRect.x + gridRect.width - boxWidth;
  const yTop = Math.round(yCenter - boxHeight / 2);

  upperChartInstance.setOption({
    graphic: [
      {
        id: 'y-axis-value-box',
        type: 'rect',
        shape: { x: xRight, y: yTop, width: boxWidth, height: boxHeight, r: 4 },
        style: { fill: '#FFFFFF', stroke: 'rgba(0,0,0,0)', lineWidth: 0 },
        z: 101,
      },
      {
        id: 'y-axis-value-text',
        type: 'text',
        position: [xRight + boxWidth / 2, yTop + boxHeight / 2],
        style: {
          text: Math.round(lastValue).toLocaleString(),
          fontSize: 10,
          fill: '#1C1833',
          textAlign: 'center',
          textVerticalAlign: 'middle',
        },
        z: 102,
      },
    ],
  }, false);
};

// 下方图表：在Y轴区域显示绿色方块
const updateLowerYAxisValueBox = () => {
  if (!lowerChartInstance || !lowerChartRef.value) return;
  const data = chartData.value;
  if (!data || data.length === 0) return;

  const option = lowerChartInstance.getOption();
  let visibleEndIndex = data.length - 1;
  
  if (option.dataZoom && option.dataZoom[0] && option.dataZoom[0].end !== undefined) {
    const endPercent = option.dataZoom[0].end;
    visibleEndIndex = Math.floor((endPercent / 100) * (data.length - 1));
  }
  
  const lastPoint = data[visibleEndIndex];
  const lastValue = lastPoint.index;
  const pt = lowerChartInstance.convertToPixel('grid', [lastPoint.time, lastValue]);
  const yCenter = pt ? pt[1] : 20;

  const gridRect = lowerChartInstance.getModel().getComponent('grid', 0).coordinateSystem.getRect();
  const boxWidth = 50;
  const boxHeight = 20;
  const xRight = gridRect.x + gridRect.width - boxWidth;
  const yTop = Math.round(yCenter - boxHeight / 2);

  lowerChartInstance.setOption({
    graphic: [
      {
        id: 'lower-y-axis-value-box',
        type: 'rect',
        shape: { x: xRight, y: yTop, width: boxWidth, height: boxHeight, r: 4 },
        style: { fill: '#16C784', stroke: 'rgba(0,0,0,0)', lineWidth: 0 },
        z: 101,
      },
      {
        id: 'lower-y-axis-value-text',
        type: 'text',
        position: [xRight + boxWidth / 2, yTop + boxHeight / 2],
        style: {
          text: Math.round(lastValue).toLocaleString(),
          fontSize: 10,
          fill: '#FFFFFF',
          textAlign: 'center',
          textVerticalAlign: 'middle',
        },
        z: 102,
      },
    ],
  }, false);
};

// 设置图表交互
const setupChartInteraction = () => {
  if (!upperChartInstance || !lowerChartInstance || !upperChartRef.value || !lowerChartRef.value)
    return;

  let updateTimeout = null;
  let isSyncing = false;
  
  upperChartInstance.on("dataZoom", function (params) {
    if (isSyncing) return;
    
    if (params.batch) {
      if (params.batch[0].start === 0 && !isLoading) {
        fetchChartData(currentTimeFilter.value, true);
      }
      
      isSyncing = true;
      try {
        lowerChartInstance.dispatchAction({
          type: "dataZoom",
        start: params.batch[0].start,
          end: params.batch[0].end,
          xAxisIndex: 0,
        });
      } finally {
        isSyncing = false;
      }
      
      if (updateTimeout) clearTimeout(updateTimeout);
      updateTimeout = setTimeout(() => {
        updateYAxisValueBox();
        updateLowerYAxisValueBox();
      }, 50);
    }
  });

  lowerChartInstance.on("dataZoom", function (params) {
    if (isSyncing) return;
    
    if (params.batch) {
      isSyncing = true;
      try {
        upperChartInstance.dispatchAction({
          type: "dataZoom",
        start: params.batch[0].start,
          end: params.batch[0].end,
          xAxisIndex: 0,
        });
      } finally {
        isSyncing = false;
      }
      
      if (updateTimeout) clearTimeout(updateTimeout);
      updateTimeout = setTimeout(() => {
        updateYAxisValueBox();
        updateLowerYAxisValueBox();
      }, 50);
    }
  });

  const handleChartMouseMove = (event, isUpperChart = false) => {
    const chartRef = isUpperChart ? upperChartRef.value : lowerChartRef.value;
    const chartInstance = isUpperChart ? upperChartInstance : lowerChartInstance;
    const rect = chartRef.getBoundingClientRect();
    const x = event.clientX - rect.left;

    const isInLeftYAxisArea = x < 60;
    const isInRightYAxisArea = x > (rect.width - 60);
    const isInYAxisArea = isInLeftYAxisArea || isInRightYAxisArea;
    
    const pointInPixel = [x, 0];
    const pointInGrid = chartInstance.convertFromPixel("grid", pointInPixel);

    if (pointInGrid && pointInGrid[0] !== null) {
      const xValue = pointInGrid[0];

      const data = chartData.value;
      let closestIndex = 0;
      let minDistance = Math.abs(data[0].time - xValue);

      for (let i = 1; i < data.length; i++) {
        const distance = Math.abs(data[i].time - xValue);
        if (distance < minDistance) {
          minDistance = distance;
          closestIndex = i;
        }
      }

      const closestData = data[closestIndex];

      if (currentHighlightIndex !== closestIndex) {
        if (currentHighlightIndex >= 0) {
          lowerChartInstance.dispatchAction({
            type: "downplay",
            seriesIndex: 0,
            dataIndex: currentHighlightIndex,
          });
          upperChartInstance.setOption({
            series: [
              { name: "CO50 Social Volume Index", markPoint: { data: [] } },
              { name: "CO50 AIVIX", markPoint: { data: [] } },
            ],
            graphic: [
              { id: "upper-hover-rect", invisible: true },
            ],
          }, false);
        }

        // 不再显示默认 tooltip
        // upperChartInstance.dispatchAction({
        //   type: "showTip",
        //   seriesIndex: 1,
        //   dataIndex: closestIndex,
        // });

        lowerChartInstance.dispatchAction({
          type: "highlight",
            seriesIndex: 0,
          dataIndex: closestIndex,
        });

        currentHighlightIndex = closestIndex;
      }

      const upperPixelPoint = upperChartInstance.convertToPixel("grid", [
        closestData.time,
        closestData.volume,
      ]);
      const lowerPixelPoint = lowerChartInstance.convertToPixel("grid", [
        closestData.time,
        closestData.index,
      ]);

      if (upperPixelPoint) {
        upperChartInstance.dispatchAction({
          type: "updateAxisPointer",
          currTrigger: "mousemove",
          x: upperPixelPoint[0],
          y: upperPixelPoint[1],
        });

        if (!isInYAxisArea) {
          const volumes = chartData.value.map((d) => d.volume);
          const aivixValues = chartData.value.map((d) => (d.aivix + 1) * 1000);
          const timeValue = closestData.time;
          const barValue = volumes[closestIndex] || 0;
          const lineValue = aivixValues[closestIndex] || 0;

          const chartHeight = upperChartRef.value.offsetHeight;
          const gridTopY = 8;
          const xAxisBottomPixel = upperChartInstance.convertToPixel("grid", [timeValue, 0]);
          const gridBottomY = Array.isArray(xAxisBottomPixel) ? xAxisBottomPixel[1] : chartHeight - 12;
          const rectHeight = Math.max(0, gridBottomY - gridTopY);

          const centerX = upperPixelPoint[0];
          const barWidthPx = 16;
          const rectX = centerX - barWidthPx / 2;

          upperChartInstance.setOption({
            graphic: [
              {
                id: "upper-hover-rect",
                type: "rect",
                invisible: false,
                shape: { 
                  x: rectX, 
                  y: gridTopY, 
                  width: barWidthPx, 
                  height: rectHeight,
                  r: [4, 4, 0, 0]
                },
                style: { 
                  fill: {
                    type: 'linear',
                    x: 0, y: 0, x2: 0, y2: 1,
                    colorStops: [
                      { offset: 0, color: 'rgba(161, 140, 255, 0.3)' },
                      { offset: 1, color: 'rgba(161, 140, 255, 0.1)' }
                    ]
                  },
                  stroke: {
                    type: 'linear',
                    x: 0, y: 0, x2: 0, y2: 1,
                    colorStops: [
                      { offset: 0, color: 'rgba(161, 140, 255, 0.3)' },
                      { offset: 1, color: 'rgba(161, 140, 255, 0.09)' }
                    ]
                  },
                  lineWidth: 1
                },
                z: 9,
              },
              { id: "y-axis-value-box" },
              { id: "y-axis-value-text" },
            ],
    series: [
      {
                name: "CO50 Social Volume Index",
        markPoint: {
                  symbol: "circle",
                  symbolSize: 6,
                  animation: false,
          data: [
                    { xAxis: timeValue, yAxis: barValue, symbolOffset: [0, 0] },
                  ],
                  itemStyle: { color: "#5E36C9", borderColor: "#fff", borderWidth: 2 },
                  label: { show: false },
                  z: 20,
                },
              },
              {
                name: "CO50 AIVIX",
                markPoint: {
                  symbol: "circle",
                  symbolSize: 6,
                  animation: false,
                  data: [
                    { xAxis: timeValue, yAxis: lineValue, symbolOffset: [0, 0] },
                  ],
                  itemStyle: { color: "#FFFFFF", borderColor: "#fff", borderWidth: 2 },
                  label: { show: false },
                  z: 20,
                },
              },
            ],
          }, false);
        } else {
          const volumes = chartData.value.map((d) => d.volume);
          const aivixValues = chartData.value.map((d) => (d.aivix + 1) * 1000);
          const timeValue = closestData.time;
          const barValue = volumes[closestIndex] || 0;
          const lineValue = aivixValues[closestIndex] || 0;

          upperChartInstance.setOption({
            series: [
              {
                name: "CO50 Social Volume Index",
                markPoint: {
                  symbol: "circle",
                  symbolSize: 6,
                  animation: false,
                  data: [
                    { xAxis: timeValue, yAxis: barValue, symbolOffset: [0, 0] },
                  ],
                  itemStyle: { color: "#5E36C9", borderColor: "#fff", borderWidth: 2 },
                  label: { show: false },
                  z: 20,
                },
              },
              {
                name: "CO50 AIVIX",
      markPoint: {
                  symbol: "circle",
                  symbolSize: 6,
                  animation: false,
        data: [
                    { xAxis: timeValue, yAxis: lineValue, symbolOffset: [0, 0] },
                  ],
                  itemStyle: { color: "#FFFFFF", borderColor: "#fff", borderWidth: 2 },
                  label: { show: false },
                  z: 20,
                },
              },
            ],
            graphic: [
              { id: "upper-hover-rect", invisible: true },
              { id: "y-axis-value-box" },
              { id: "y-axis-value-text" },
            ],
          }, false);
        }
      }

      if (lowerPixelPoint) {
        lowerChartInstance.dispatchAction({
          type: "updateAxisPointer",
          currTrigger: "mousemove",
          x: lowerPixelPoint[0],
          y: lowerPixelPoint[1],
          value: [closestData.time, closestData.index],
        });
      }
    }
  };

  const handleChartMouseLeave = () => {
    if (currentHighlightIndex >= 0) {
      // 不再隐藏默认 tooltip，因为已禁用
      // upperChartInstance.dispatchAction({
      //   type: "hideTip",
      // });
      
      lowerChartInstance.dispatchAction({
        type: "downplay",
        seriesIndex: 0,
        dataIndex: currentHighlightIndex,
      });
      
      upperChartInstance.setOption({
        series: [
          { name: "CO50 Social Volume Index", markPoint: { data: [] } },
          { name: "CO50 AIVIX", markPoint: { data: [] } },
        ],
        graphic: [
          { id: "upper-hover-rect", invisible: true },
        ],
      }, false);

      currentHighlightIndex = -1;
    }
  };

  upperChartRef.value.addEventListener("mousemove", (event) => handleChartMouseMove(event, true));
  upperChartRef.value.addEventListener("mouseleave", handleChartMouseLeave);
  
  lowerChartRef.value.addEventListener("mousemove", (event) => handleChartMouseMove(event, false));
  lowerChartRef.value.addEventListener("mouseleave", handleChartMouseLeave);
};

// 处理图表点击事件，显示底部弹窗
const handleChartClick = (event) => {
  if (!upperChartInstance || !lowerChartInstance || !chartData.value.length) return;
  
  // 判断点击的是上方图表还是下方图表
  const upperRect = upperChartRef.value?.getBoundingClientRect();
  const lowerRect = lowerChartRef.value?.getBoundingClientRect();
  
  let chartInstance = null;
  let chartRef = null;
  
  if (upperRect && event.clientY >= upperRect.top && event.clientY <= upperRect.bottom) {
    chartInstance = upperChartInstance;
    chartRef = upperChartRef.value;
  } else if (lowerRect && event.clientY >= lowerRect.top && event.clientY <= lowerRect.bottom) {
    chartInstance = lowerChartInstance;
    chartRef = lowerChartRef.value;
  } else {
    return;
  }
  
  const rect = chartRef.getBoundingClientRect();
  const chartOffsetX = event.clientX - rect.left;
  const chartOffsetY = event.clientY - rect.top;
  const pointInPixel = [chartOffsetX, chartOffsetY];
  const pointInGrid = chartInstance.convertFromPixel("grid", pointInPixel);
  
  if (pointInGrid && pointInGrid[0] !== null) {
    const xValue = pointInGrid[0];
    
    // 找到最接近的数据点
    const data = chartData.value;
    let closestIndex = 0;
    let minDistance = Math.abs(data[0].time - xValue);
    
    for (let i = 1; i < data.length; i++) {
      const distance = Math.abs(data[i].time - xValue);
      if (distance < minDistance) {
        minDistance = distance;
        closestIndex = i;
      }
    }
    
    const closestData = data[closestIndex];
    if (closestData) {
      const time = new Date(closestData.time);
      const pad = (v) => String(v).padStart(2, '0');
      const dateStr = `${time.getFullYear()}-${pad(time.getMonth()+1)}-${pad(time.getDate())}`;
      const timeStr = `${pad(time.getHours())}:${pad(time.getMinutes())}`;
      
      bottomDialogData.value = {
        dateTime: `${dateStr} ${timeStr}`,
        socialVolume: formatNumberSmart(closestData.volume, { decimals: 0, useUnit: false }),
        index: formatNumberSmart(closestData.index, { decimals: 0, useUnit: false }),
        aivix: formatNumberSmart((closestData.aivix + 1) * 1000, { decimals: 0, useUnit: false })
      };
      
      bottomDialogVisible.value = true;
    }
  }
};

// 关闭底部弹窗
const closeBottomDialog = () => {
  bottomDialogVisible.value = false;
};

let resizeTimeout = null;
const handleResize = () => {
  if (resizeTimeout) clearTimeout(resizeTimeout);
  resizeTimeout = setTimeout(() => {
    if (upperChartInstance) upperChartInstance.resize();
    if (lowerChartInstance) lowerChartInstance.resize();
    setTimeout(() => {
      updateYAxisValueBox();
      updateLowerYAxisValueBox();
    }, 100);
  }, 100);
};

onMounted(() => {
  nextTick(() => {
    initCharts();
    window.addEventListener("resize", handleResize);
  });
});

onBeforeUnmount(() => {
  if (upperChartInstance) {
    upperChartInstance.dispose();
    upperChartInstance = null;
  }
  if (lowerChartInstance) {
    lowerChartInstance.dispose();
    lowerChartInstance = null;
  }
  window.removeEventListener("resize", handleResize);
});
</script>

<style lang="scss" scoped>
.aivix-container {
  width: 100%;
  box-sizing: border-box;

  .chart-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 12px;

    .title {
      font-family: Tomato Grotesk;
      font-weight: 600;
      font-size: 14px;
      line-height: 15px;
      letter-spacing: 0%;
      vertical-align: middle;
      text-transform: capitalize;
      color: #ffffff;
      display: flex;
      align-items: center;
    }

    .header-right {
      .view-list-btn {
      display: flex;
      align-items: center;
        gap: 6px;
        cursor: pointer;
        border-radius: 6px;
        transition: all 0.3s;
        padding: 4px 8px;

        span {
        font-family: Tomato Grotesk;
        font-weight: 500;
        font-size: 12px;
          color: #9e9cb6;
          transition: color 0.3s;
        }

        .arrow-icon {
          width: 16px;
          height: 16px;
          transition: transform 0.3s;
        }

        &:hover {
          background-color: rgba(118, 68, 251, 0.15);

          span {
            color: #ffffff;
          }

          .arrow-icon {
            transform: translateX(2px);
          }
        }
      }
    }
  }

  .controls-row {
  display: flex;
    flex-direction: column;
    gap: 12px;
    margin-bottom: 16px;
  }

  .chart-legend {
  display: flex;
    flex-wrap: wrap;
    gap: 12px;
  align-items: center;
    .legend-item {
  font-family: Tomato Grotesk;
      font-weight: 500;
  font-size: 11px;
        letter-spacing: 0%;
        vertical-align: middle;
        text-transform: capitalize;
      color: rgba(255, 255, 255, 0.6);
  display: flex;
      gap: 6px;
  align-items: center;
      line-height: 16px;
      .legend-dot { 
        width: 18px; 
        height: 8px; 
        border-radius: 4px; 
  display: inline-block;
}
      .legend-dot.green { background: #16C784; }
      .legend-dot.white { background: #CFD6E4; }
      .legend-dot.purple { background: #5E36C9; }
    }
  }

  .time-filter {
    display: flex;
    align-items: center;
    justify-content: space-between;
    border-radius: 6px;
    padding: 2px;
    box-sizing: border-box;
    background-color: #302d4a;
    overflow-x: auto;

    .time-filter-item {
      padding: 0 16px;
      height: 40px;
      border-radius: 4px;
      color: #B2ADE2;
      cursor: pointer;
      transition: all 0.3s;
      font-family: Tomato Grotesk;
      font-weight: 500;
      font-size: 12px;
      letter-spacing: 0%;
  display: flex;
      justify-content: center;
  align-items: center;
      white-space: nowrap;
      &.active {
        background-color: #141325;
        color: #ffffff;
      }
    }
  }

  .charts-container {
    position: relative;
    width: 100%;
    height: 400px;

    .upper-chart {
      width: 100%;
      height: 60%;
    }

    .lower-chart {
      width: 100%;
      height: 40%;
    }
  }
}

/* 底部弹窗样式 */
.bottom-dialog-mask {
  position: fixed;
  left: 0;
  top: 0;
  width: 100vw;
  height: 100vh;
  background: rgba(28, 24, 51, 0.4);
  z-index: 2000;
  display: flex;
  align-items: flex-end;
  justify-content: center;
}

.bottom-dialog {
  width: 100%;
  background: #282544;
  border-radius: 12px 12px 0 0;
  box-shadow: 0 0 12px rgba(0, 0, 0, 0.18);
  padding: 12px 16px 16px;
  margin-bottom: 0;
  animation: slideUp 0.25s cubic-bezier(0.4, 0, 0.2, 1);
}

@keyframes slideUp {
  from {
    transform: translateY(100%);
  }
  to {
    transform: translateY(0);
  }
}

.dialog-handle {
  width: 40px;
  height: 4px;
  background: rgba(255, 255, 255, 0.2);
  border-radius: 2px;
  margin: 0 auto 16px;
}

.dialog-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 20px;
}

.dialog-title {
  font-family: Tomato Grotesk;
  font-size: 14px;
  font-weight: 600;
  color: #fff;
  display: flex;
  align-items: center;
  gap: 8px;
}

.dialog-icon {
  width: 18px;
  height: 18px;
  display: flex;
  align-items: center;
  justify-content: center;
  
  svg {
    width: 100%;
    height: 100%;
  }
}

.dialog-date {
  font-size: 12px;
  color: rgba(255, 255, 255, 0.6);
  font-family: Tomato Grotesk;
  font-weight: 500;
}

.dialog-data-section {
  display: flex;
  flex-direction: column;
  gap: 16px;
  margin-bottom: 24px;
}

.data-row {
  display: flex;
  align-items: center;
  gap: 8px;
}

.data-indicator {
  width: 16px;
  height: 4px;
  border-radius: 2px;
  flex-shrink: 0;
}

.indicator-grey {
  background: #9E9CB6;
}

.indicator-purple {
  background: #5E36C9;
}

.indicator-green {
  background: #16C784;
}

.data-label {
  font-family: Tomato Grotesk;
  font-weight: 500;
  font-size: 14px;
  color: #fff;
  flex-shrink: 0;
}

.data-value {
  font-family: Tomato Grotesk;
  font-weight: 600;
  font-size: 14px;
  color: #fff;
  margin-left: auto;
}

.dialog-footer {
  display: flex;
  justify-content: center;
}

.dialog-close-btn {
  width: 100%;
  height: 42px;
  border: none;
  border-radius: 6px;
  background: #39365A;
  color: #fff;
  font-size: 14px;
  font-family: Tomato Grotesk;
  font-weight: 600;
  cursor: pointer;
  transition: background 0.2s;
}

.dialog-close-btn:active {
  background: #4B476B;
}
</style>
