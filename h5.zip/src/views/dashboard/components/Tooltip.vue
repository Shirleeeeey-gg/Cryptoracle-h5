<template>
  <div class="tooltip-content">
    <img src="@/assets/dashboard/question-mark.svg" alt="" class="question-icon">
    <div class="tooltip-box" :class="{ left: position === 'left' }">
      <span v-html="content"></span>
      <img src="@/assets/dashboard/tooltip-sj.svg" alt="" class="tooltip-sj">
    </div>
  </div>
</template>

<script setup>
const props = defineProps({
  content: {
    type: String,
    default: 'No content'
  },
  position: {
    type: String,
    default: 'right'
  }
})
</script>

<style lang="scss" scoped>
.tooltip-content {
  width: 8px;
  height: 8px;
  margin-left: 3px;
  position: relative;
  font-size: 0;

  &:hover {
    .tooltip-box {
      display: block;
    }
  }

  .question-icon {
    width: 100%;
    height: 100%;
  }

  .tooltip-box {
    z-index: 1000;
    display: none;
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    left: 18px;
    padding: 8px;
    background: #2F2952;
    box-shadow: 2.5px 2px 7px 0px rgba(0, 0, 0, 0.15);
    border-radius: 6px;
    width: 125px;
    font-family: Tomato Grotesk;
    font-weight: 400;
    font-size: 6px;
    line-height: 9px;
    letter-spacing: 0%;
    vertical-align: middle;
    color: #D2CFF9;
    &.left {
      left:unset;
      right: 18px;
      .tooltip-sj {
        left: unset;
        right: -13px;
        transform: translateY(-50%) rotate(180deg);
      }
    }

    .tooltip-sj {
      width: 20px;
      height: 14px;
      position: absolute;
      left: -13px;
      top: 50%;
      transform: translateY(-50%);
    }
  }
}
</style>