<template>
  <div class="stats-cards">
    <div class="card-left">
      <div class="card-item">
        <div class="item-title">
          <span>Project Popularity(24h)</span>
          <!-- <img src="@/assets/dashboard/icon-tanhao.svg" alt="Info" class="icon-info"> -->
          <Tooltip content="Discussion Heat Variation of this Coin in 24 Hours" />
        </div>
        <div class="item-val-box">
          <div class="item-val">{{$filters.integer(pageData.mention24)}}</div>
          <div class="item-qs" :class="{'is-up': pageData.mention24Percent > 0, 'is-down': pageData.mention24Percent < 0}">
            <img src="@/assets/dashboard/arrow-top.svg" v-if="pageData.mention24Percent > 0" alt="">
            <img src="@/assets/dashboard/arrow-bottom.svg" v-if="pageData.mention24Percent < 0" alt="">
            <span>{{$filters.decimal(Math.abs(pageData.mention24Percent))}}%</span>
          </div>
        </div>
      </div>
      <div class="card-item">
        <div class="item-title">
          <span>Project Popularity(7D)</span>
          <!-- <img src="@/assets/dashboard/icon-tanhao.svg" alt="Info" class="icon-info"> -->
          <Tooltip content="Discussion Heat Variation of this Coin in 7 Days" />
        </div>
        <div class="item-val-box">
          <div class="item-val">{{$filters.integer(pageData.mention7day)}}</div>
          <div class="item-qs" :class="{'is-up': pageData.mention7dayPercent > 0, 'is-down': pageData.mention7dayPercent < 0}">
            <img src="@/assets/dashboard/arrow-top.svg" v-if="pageData.mention7dayPercent > 0" alt="">
            <img src="@/assets/dashboard/arrow-bottom.svg" v-if="pageData.mention7dayPercent < 0" alt="">
            <span>{{$filters.decimal(Math.abs(pageData.mention7dayPercent))}}%</span>
          </div>
        </div>
      </div>
    </div>
    <div class="card-right">
      <div class="card-item">
        <div class="item-title">
          <span>Community Growth(24h)</span>
          <!-- <img src="@/assets/dashboard/icon-tanhao.svg" alt="Info" class="icon-info"> -->
          <Tooltip content="Total Community Growth Rate of this Coin in 24 Hours" />
        </div>
        <div class="item-val-box">
          <div class="item-val">{{$filters.integer(pageData.community24)}}</div>
          <div class="item-qs" :class="{'is-up': pageData.community24Percent > 0, 'is-down': pageData.community24Percent < 0}">
            <img src="@/assets/dashboard/arrow-top.svg" v-if="pageData.community24Percent > 0" alt="">
            <img src="@/assets/dashboard/arrow-bottom.svg" v-if="pageData.community24Percent < 0" alt="">
            <span>{{$filters.decimal(Math.abs(pageData.community24Percent))}}%</span>
          </div>
        </div>
      </div>
      <div class="card-item">
        <div class="item-title">
          <span>Community Growth(7D)</span>
          <!-- <img src="@/assets/dashboard/icon-tanhao.svg" alt="Info" class="icon-info"> -->
          <Tooltip content="Total Community Growth Rate of this Coin in 7 Days" />
        </div>
        <div class="item-val-box">
          <div class="item-val">{{$filters.integer(pageData.community7day)}}</div>
          <div class="item-qs" :class="{'is-up': pageData.community7dayPercent > 0, 'is-down': pageData.community7dayPercent < 0}">
            <img src="@/assets/dashboard/arrow-top.svg" v-if="pageData.community7dayPercent > 0" alt="">
            <img src="@/assets/dashboard/arrow-bottom.svg" v-if="pageData.community7dayPercent < 0" alt="">
            <span>{{$filters.decimal(Math.abs(pageData.community7dayPercent))}}%</span>
          </div>
        </div>
      </div>
      <div class="card-item">
        <div class="item-title">
          <span>Follower Growth(24h)</span>
          <!-- <img src="@/assets/dashboard/icon-tanhao.svg" alt="Info" class="icon-info"> -->
          <Tooltip content="Follower Growth Rate of this Coin in 24 Hours" />
        </div>
        <div class="item-val-box">
          <div class="item-val">{{$filters.integer(pageData.fan24)}}</div>
          <div class="item-qs" :class="{'is-up': pageData.fan24Percent > 0, 'is-down': pageData.fan24Percent < 0}">
            <img src="@/assets/dashboard/arrow-top.svg" v-if="pageData.fan24Percent > 0" alt="">
            <img src="@/assets/dashboard/arrow-bottom.svg" v-if="pageData.fan24Percent < 0" alt="">
            <span>{{$filters.decimal(Math.abs(pageData.fan24Percent))}}%</span>
          </div>
        </div>
      </div>
      <div class="card-item">
        <div class="item-title">
          <span>Follower Growth(7D)</span>
          <!-- <img src="@/assets/dashboard/icon-tanhao.svg" alt="Info" class="icon-info"> -->
          <Tooltip position="left" content="Follower Growth Rate of this Coin in 7 Days" />
        </div>
        <div class="item-val-box">
          <div class="item-val">{{$filters.integer(pageData.fan7day)}}</div>
          <div class="item-qs" :class="{'is-up': pageData.fan7dayPercent > 0, 'is-down': pageData.fan7dayPercent < 0}">
            <img src="@/assets/dashboard/arrow-top.svg" v-if="pageData.fan7dayPercent > 0" alt="">
            <img src="@/assets/dashboard/arrow-bottom.svg" v-if="pageData.fan7dayPercent < 0" alt="">
            <span>{{$filters.decimal(Math.abs(pageData.fan7dayPercent))}}%</span>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import Tooltip from '@/views/dashboard/components/Tooltip.vue'
const props = defineProps({
  pageData: {
    type: Object,
    default: () => ({})
  }
})
</script>
<style lang="scss" scoped>
.stats-cards {

  .card-left {
    height:65px;
    box-sizing: border-box;
    border-radius: 8px;
    display: flex;
    justify-content: space-between;
    margin-bottom: 6px;
    .card-item {
      width:172.5px;
      height: 100%;
      background: #1C1833;
      border-radius: 8px;
      padding: 12px;
      box-sizing: border-box;
      display: flex;
      justify-content: space-between;
      flex-direction: column;
      .item-title {
        font-family: Tomato Grotesk;
        font-weight: 500;
        font-size: 9px;
        line-height: 11px;
        letter-spacing: 0%;
        color: #9E9CB6;
        display: flex;
        align-items: center;
        margin-bottom: 10px;

        .icon-info {
          margin-left: 2px;
          width: 6px;
          height: 6px;
        }
      }

      .item-val-box {
        display: flex;
        align-items:flex-end;
        .item-val {
          font-family: Tomato Grotesk;
          font-weight: 500;
          font-size: 20px;
          line-height: 20px;
        }

        .item-qs {
          margin-left: 4px;
          font-family: Tomato Grotesk;
          font-weight: 600;
          font-size: 10px;
          display: flex;
          align-items: center;
          color:rgba(217, 217, 217, 0.5);
          &.is-up {
            color: #16C784;
          }
          &.is-down {
            color: #EA3943;
          }
          img{
            width:6px;
            height:6px;
          }
        }
      }
    }
  }

  .card-right {
    display: flex;
    justify-content: space-between;
    flex-wrap: wrap;
    .card-item {
      width:172.5px;
      height: 65px;
      box-sizing: border-box;
      padding: 12px;
      background: #1C1833;
      border-radius: 8px;
      margin-bottom: 6px;
      &:nth-child(3),&:nth-child(4){
        margin-bottom: 0;
      }
      .item-title {
        font-family: Tomato Grotesk;
        font-weight: 500;
        font-size: 9px;
        line-height: 11px;
        letter-spacing: 0%;
        color: #9E9CB6;
        display: flex;
        align-items: center;
        margin-bottom: 10px;

        .icon-info {
          margin-left: 2px;
          width: 6px;
          height: 6px;
        }
      }

      .item-val-box {
        display: flex;
        align-items:flex-end;
        .item-val {
          font-family: Tomato Grotesk;
          font-weight: 500;
          font-size: 20px;
          line-height: 20px;
        }

        .item-qs {
          margin-left: 4px;
          font-family: Tomato Grotesk;
          font-weight: 600;
          font-size: 10px;
          display: flex;
          align-items: center;
          color:rgba(217, 217, 217, 0.5);
          &.is-up {
            color: #16C784;
          }
          &.is-down {
            color: #EA3943;
          }
          img{
            width:6px;
            height:6px;
          }
        }
      }
    }
  }
}
</style>