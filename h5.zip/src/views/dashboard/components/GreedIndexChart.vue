<template>
  <div class="greed-index-chart">
    <div class="chart-header">
      Fear & Greed Index
    </div>

    <div class="chart-container">
      <div class="chart-content">
        <div class="chart-labels">
          <div class="label-item extreme-greed">Extreme Greed</div>
          <div class="label-item moderate-greed">Moderate Greed</div>
          <div class="label-item neutral">Neutral</div>
          <div class="label-item moderate-fear">Moderate Fear</div>
          <div class="label-item extreme-fear">Extreme Fear</div>
        </div>
        <div class="chart-wrapper">
          <div class="bg-bands">
            <div v-for="(band, idx) in bands" :key="'band-' + idx" class="band"
              :style="{ background: band.background }">
            </div>
          </div>
          <div ref="chartContainer" class="chart-main" @click="handleChartContainerClick"></div>

          <!-- 加载状态 -->
          <div v-if="isLoading" class="loading-overlay">
            <div class="loading-text">Loading Data...</div>
          </div>

          <!-- 无数据状态 -->
          <div v-else-if="!isLoading && dataPoints.length === 0" class="no-data-overlay">
            <div class="no-data-text">No Data</div>
          </div>
        </div>
      </div>

      <!-- X轴区域 -->
      <div class="x-axis-area" ref="xAxisContainer"></div>

      <!-- 悬浮弹框 改为底部弹框 -->
      <div v-if="bottomDialogVisible" class="bottom-dialog-mask" @click.self="closeBottomDialog">
        <div class="bottom-dialog">
          <div class="dialog-header">
            <span class="dialog-title">
              <img src="@/assets/images/dashboard/layer-icon-qb.svg" alt="" class="qb-icon">
              <span>Fear & Greed Index</span>
              <span class="current-sentiment" :class="bottomDialogData.sentimentClass">{{ bottomDialogData.sentiment
                }}</span>
            </span>
            <span class="dialog-date">{{ bottomDialogData.date }} {{ bottomDialogData.dtStart }}</span>
          </div>
          <div class="panel-metrics">
            <div class="sentiments-section">
              <div class="sentiment-col">
                <div class="sentiment-title">KOL Sentiment</div>
                <div class="sentiment-bars">
                  <div class="sentiment-bar">
                    <div class="bar-container">
                      <div class="bar rise-bar" :style="{ width: bottomDialogData.kolRise + '%' }"></div>
                      <div class="bar-value rise-bar">Rise {{ $filters.percentage(bottomDialogData.kolRise) }}</div>
                    </div>
                  </div>
                  <div class="sentiment-bar">
                    <div class="bar-container">
                      <div class="bar neutral-bar" :style="{ width: bottomDialogData.kolNeutral + '%' }"></div>
                      <div class="bar-value neutral-bar">Neutral {{ $filters.percentage(bottomDialogData.kolNeutral) }}
                      </div>
                    </div>
                  </div>
                  <div class="sentiment-bar">
                    <div class="bar-container">
                      <div class="bar fall-bar" :style="{ width: bottomDialogData.kolFall + '%' }"></div>
                      <div class="bar-value fall-bar">Fall {{ $filters.percentage(bottomDialogData.kolFall) }}</div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="sentiment-col">
                <div class="sentiment-title">Community Sentiment</div>
                <div class="sentiment-bars">
                  <div class="sentiment-bar">
                    <div class="bar-container">
                      <div class="bar rise-bar" :style="{ width: bottomDialogData.communityRise + '%' }"></div>
                      <div class="bar-value rise-bar">Rise {{ $filters.percentage(bottomDialogData.communityRise) }}
                      </div>
                    </div>
                  </div>
                  <div class="sentiment-bar">
                    <div class="bar-container">
                      <div class="bar neutral-bar" :style="{ width: bottomDialogData.communityNeutral + '%' }"></div>
                      <div class="bar-value neutral-bar">Neutral {{
                        $filters.percentage(bottomDialogData.communityNeutral) }}</div>
                    </div>
                  </div>
                  <div class="sentiment-bar">
                    <div class="bar-container">
                      <div class="bar fall-bar" :style="{ width: bottomDialogData.communityFall + '%' }"></div>
                      <div class="bar-value fall-bar">Fall {{ $filters.percentage(bottomDialogData.communityFall) }}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="dialog-footer">
            <button class="dialog-close-btn" @click="closeBottomDialog">Close</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, onUnmounted } from 'vue'
import { getLineChartDataApi } from '@/api/dashboard'
import Tooltip from '@/views/dashboard/components/Tooltip.vue'

// 图表容器
const chartContainer = ref(null)
const xAxisContainer = ref(null)

// API数据状态
const apiData = ref([])
const isLoading = ref(false)

// 新增底部弹框相关逻辑
const bottomDialogVisible = ref(false)
const bottomDialogData = ref({})

// 定义不同区间及其颜色
const bands = [
  {
    label: 'Extreme Greed',
    background: 'rgba(15, 122, 82, 0.3)',
    color: '#17B179',
    range: [0.6, 1]
  },
  {
    label: 'Moderate Greed',
    background: 'rgba(90, 133, 0, 0.3)',
    color: '#93D900',
    range: [0.2, 0.6]
  },
  {
    label: 'Neutral',
    background: 'rgba(184, 152, 31, 0.3)',
    color: '#F3D42F',
    range: [-0.2, 0.2]
  },
  {
    label: 'Moderate Fear',
    background: 'rgba(168, 92, 0, 0.3)',
    color: '#EA8C00',
    range: [-0.6, -0.2]
  },
  {
    label: 'Extreme Fear',
    background: 'rgba(168, 37, 48, 0.3)',
    color: '#EA3943',
    range: [-1, -0.6]
  }
]

// 生成时间标签 - 现在从API数据动态生成
const timeLabels = computed(() => {
  if (apiData.value.length === 0) return []
  return apiData.value.map(item => {
    const timeStr = item.dtStart
    const timePart = timeStr.split(' ')[1]
    return timePart ? timePart.slice(0, 5) : ''
  })
})

// 处理API数据，转换为图表需要的格式
const processApiData = (data) => {
  return data.map(item => ({
    dtStart: item.dtStart.split(' ')[1],
    fullTime: item.dtStart,
    value: item.emotional,
    kolRise: item.kolRise,
    kolNeutral: item.kolNeutral,
    kolFall: item.kolFall,
    communityRise: item.communityRise,
    communityNeutral: item.communityNeutral,
    communityFall: item.communityFall
  }))
}

// 数据点数组 - 现在从API数据生成
const dataPoints = computed(() => {
  if (apiData.value.length === 0) return []
  return processApiData(apiData.value)
})

// 获取数据点所在区间的颜色
const getColorForValue = (value) => {
  for (const band of bands) {
    if (value >= band.range[0] && value <= band.range[1]) {
      return band.color
    }
  }
  return '#93D900'
}

// 获取数据点所在的区间标签
const getSentimentForValue = (value) => {
  for (const band of bands) {
    if (value >= band.range[0] && value <= band.range[1]) {
      return band.label
    }
  }
  return 'Unknown'
}

// 获取情绪样式类
const getSentimentClass = (sentiment) => {
  return sentiment.toLowerCase().replace(' ', '-')
}

// 当前情绪
const currentSentiment = computed(() => {
  if (dataPoints.value.length === 0) return 'Unknown'
  const lastValue = dataPoints.value[dataPoints.value.length - 1].value
  return getSentimentForValue(lastValue)
})

const currentSentimentClass = computed(() => {
  return currentSentiment.value.toLowerCase().replace(' ', '-')
})

// 获取数据
const getLineChartData = async () => {
  try {
    isLoading.value = true
    const res = await getLineChartDataApi({ timeType: '15m' })
    if (res && res.data && Array.isArray(res.data)) {
      apiData.value = res.data
      setTimeout(() => {
        if (chartContainer.value && xAxisContainer.value) {
          initializeCanvas()
          drawChart()
          setupInteraction()
        }
      }, 50)
    }
  } catch (error) {
    console.error('获取图表数据失败:', error)
  } finally {
    isLoading.value = false
  }
}

// Canvas绘制相关变量
let mainCanvas, xAxisCanvas, mainCtx, xAxisCtx
let chartWidth, chartHeight, margin

// 获取是否为移动端
const isMobile = () => window.innerWidth <= 750

// 初始化Canvas
const initializeCanvas = () => {
  const container = chartContainer.value
  const xAxisContainerElement = xAxisContainer.value

  if (!container || !xAxisContainerElement) return

  // 清除容器内容
  container.innerHTML = ''
  xAxisContainerElement.innerHTML = ''

  // 获取容器尺寸
  const containerRect = container.getBoundingClientRect()
  const dpr = window.devicePixelRatio || 1

  // 根据设备类型设置边距
  const mobile = isMobile()
  margin = mobile
    ? { top: 10, right: 15, bottom: 8, left: 15 }
    : { top: 20, right: 20, bottom: 10, left: 20 }
  chartWidth = containerRect.width - margin.left - margin.right
  chartHeight = containerRect.height - margin.top - margin.bottom

  // 创建主图表Canvas
  mainCanvas = document.createElement('canvas')
  mainCanvas.style.width = containerRect.width + 'px'
  mainCanvas.style.height = containerRect.height + 'px'
  mainCanvas.width = containerRect.width * dpr
  mainCanvas.height = containerRect.height * dpr
  container.appendChild(mainCanvas)

  mainCtx = mainCanvas.getContext('2d')
  mainCtx.scale(dpr, dpr)

  // 创建X轴Canvas
  const xAxisHeight = 40
  xAxisCanvas = document.createElement('canvas')
  xAxisCanvas.style.width = containerRect.width + 'px'
  xAxisCanvas.style.height = xAxisHeight + 'px'
  xAxisCanvas.width = containerRect.width * dpr
  xAxisCanvas.height = xAxisHeight * dpr
  xAxisContainerElement.appendChild(xAxisCanvas)

  xAxisCtx = xAxisCanvas.getContext('2d')
  xAxisCtx.scale(dpr, dpr)
}

// 坐标转换函数
const xScale = (index) => {
  if (dataPoints.value.length <= 1) return margin.left
  return (index / (dataPoints.value.length - 1)) * chartWidth + margin.left
}
const yScale = (value) => ((1 - value) / 2) * chartHeight + margin.top
const getDataIndexFromX = (x) => {
  if (dataPoints.value.length <= 1) return 0
  return Math.round(((x - margin.left) / chartWidth) * (dataPoints.value.length - 1))
}

// 绘制图表
const drawChart = () => {
  if (!mainCtx || dataPoints.value.length === 0) return

  // 清除画布
  mainCtx.clearRect(0, 0, mainCanvas.offsetWidth, mainCanvas.offsetHeight)

  // 根据设备类型调整线条粗细
  const mobile = isMobile()
  const lineWidth = mobile ? 3 : 6

  // 绘制折线
  mainCtx.lineWidth = lineWidth
  mainCtx.lineCap = 'round'
  mainCtx.lineJoin = 'round'

  for (let i = 0; i < dataPoints.value.length - 1; i++) {
    const currentPoint = dataPoints.value[i]
    const nextPoint = dataPoints.value[i + 1]

    const x1 = xScale(i)
    const y1 = yScale(currentPoint.value)
    const x2 = xScale(i + 1)
    const y2 = yScale(nextPoint.value)

    // 设置当前段的颜色
    mainCtx.strokeStyle = getColorForValue(currentPoint.value)

    // 绘制线段
    mainCtx.beginPath()
    mainCtx.moveTo(x1, y1)
    mainCtx.lineTo(x2, y2)
    mainCtx.stroke()
  }

  // 绘制X轴
  drawXAxis()
}

// 绘制X轴
const drawXAxis = () => {
  if (!xAxisCtx || timeLabels.value.length === 0) return

  xAxisCtx.clearRect(0, 0, xAxisCanvas.offsetWidth, xAxisCanvas.offsetHeight)

  // 根据设备类型调整字体大小
  const mobile = isMobile()
  const fontSize = mobile ? 12 : 24

  xAxisCtx.fillStyle = '#ffffff'
  xAxisCtx.font = `${fontSize}px Arial`
  xAxisCtx.textAlign = 'center'

  timeLabels.value.forEach((label, index) => {
    // 根据数据点数量和设备类型调整显示频率
    const mobile = isMobile()
    const maxLabels = mobile ? 4 : 6
    const showInterval = Math.max(1, Math.floor(timeLabels.value.length / maxLabels))
    if (index % showInterval === 0) {
      const x = xScale(index)
      const yPosition = mobile ? 18 : 28
      xAxisCtx.fillText(label, x, yPosition)
    }
  })
}

// 设置鼠标交互
const setupInteraction = () => {
  if (!mainCanvas) return

  let isHovering = false

  mainCanvas.addEventListener('mousemove', (event) => {
    const rect = mainCanvas.getBoundingClientRect()
    const mouseX = event.clientX - rect.left
    const mouseY = event.clientY - rect.top

    // 检查是否在图表区域内
    if (mouseX >= margin.left && mouseX <= margin.left + chartWidth &&
      mouseY >= margin.top && mouseY <= margin.top + chartHeight) {

      const dataIndex = getDataIndexFromX(mouseX)

      if (dataIndex >= 0 && dataIndex < dataPoints.value.length) {
        const dataPoint = dataPoints.value[dataIndex]
        const sentiment = getSentimentForValue(dataPoint.value)
        const sentimentClass = getSentimentClass(sentiment)
        const color = getColorForValue(dataPoint.value)

        // 从完整时间中提取日期和时间
        const fullTime = dataPoint.fullTime
        const [datePart, timePart] = fullTime.split(' ')

        // 更新悬浮数据（不再控制弹窗显示）
        bottomDialogData.value = {
          date: datePart,
          dtStart: timePart,
          sentiment: sentiment,
          sentimentClass: sentimentClass,
          value: dataPoint.value,
          kolRise: dataPoint.kolRise * 100,
          kolNeutral: dataPoint.kolNeutral * 100,
          kolFall: dataPoint.kolFall * 100,
          communityRise: dataPoint.communityRise * 100,
          communityNeutral: dataPoint.communityNeutral * 100,
          communityFall: dataPoint.communityFall * 100
        }

        isHovering = true

        // 设置悬浮面板位置
        setTimeout(() => {
          if (mainCanvas) {
            const mobile = isMobile()
            const panelWidth = mobile ? 250 : 300
            const panelHeight = mobile ? 100 : 120

            let left = event.clientX - rect.left + 20
            let top = event.clientY - rect.top - panelHeight / 2

            // 防止面板超出容器边界
            if (left + panelWidth > rect.width) {
              left = event.clientX - rect.left - panelWidth - 20
            }
            if (top < 0) top = 10
            if (top + panelHeight > rect.height) {
              top = rect.height - panelHeight - 10
            }

            mainCanvas.style.left = `${left}px`
            mainCanvas.style.top = `${top}px`
          }
        }, 0)

        // 重绘图表，添加悬浮效果
        drawChart()
        drawHoverEffects(dataIndex, dataPoint, color)
      }
    } else if (isHovering) {
      // 鼠标移出图表区域
      isHovering = false
      drawChart() // 重绘移除悬浮效果
    }
  })

  mainCanvas.addEventListener('mouseleave', () => {
    isHovering = false
    drawChart() // 重绘移除悬浮效果
  })
}

// 绘制悬浮效果
const drawHoverEffects = (dataIndex, dataPoint, color) => {
  const x = xScale(dataIndex)
  const y = yScale(dataPoint.value)
  const mobile = isMobile()

  // 绘制垂直虚线
  mainCtx.setLineDash([5, 5])
  mainCtx.strokeStyle = '#fff'
  mainCtx.lineWidth = 1
  mainCtx.globalAlpha = 0.8

  mainCtx.beginPath()
  mainCtx.moveTo(x, margin.top)
  mainCtx.lineTo(x, margin.top + chartHeight)
  mainCtx.stroke()

  // 重置线条样式
  mainCtx.setLineDash([])
  mainCtx.globalAlpha = 1

  // 绘制高亮圆点 - 移动端使用更小的圆点
  const circleRadius = mobile ? 3 : 5
  const strokeWidth = mobile ? 1.5 : 2

  mainCtx.fillStyle = color
  mainCtx.strokeStyle = '#fff'
  mainCtx.lineWidth = strokeWidth

  mainCtx.beginPath()
  mainCtx.arc(x, y, circleRadius, 0, 2 * Math.PI)
  mainCtx.fill()
  mainCtx.stroke()
}

// 响应式调整
const handleResize = () => {
  if (chartContainer.value && xAxisContainer.value) {
    initializeCanvas()
    drawChart()
    setupInteraction()
  }
}

// 新增chartContainer的点击事件处理
const handleChartContainerClick = (event) => {
  if (!mainCanvas || dataPoints.value.length === 0) return;
  const rect = mainCanvas.getBoundingClientRect();
  const mouseX = event.clientX - rect.left;
  const mouseY = event.clientY - rect.top;
  if (mouseX >= margin.left && mouseX <= margin.left + chartWidth &&
    mouseY >= margin.top && mouseY <= margin.top + chartHeight) {
    const dataIndex = getDataIndexFromX(mouseX);
    if (dataIndex >= 0 && dataIndex < dataPoints.value.length) {
      const dataPoint = dataPoints.value[dataIndex];
      const sentiment = getSentimentForValue(dataPoint.value);
      const sentimentClass = getSentimentClass(sentiment);
      const fullTime = dataPoint.fullTime;
      const [datePart, timePart] = fullTime.split(' ');
      bottomDialogData.value = {
        date: datePart,
        dtStart: timePart,
        sentiment: sentiment,
        sentimentClass: sentimentClass,
        value: dataPoint.value,
        kolRise: dataPoint.kolRise * 100,
        kolNeutral: dataPoint.kolNeutral * 100,
        kolFall: dataPoint.kolFall * 100,
        communityRise: dataPoint.communityRise * 100,
        communityNeutral: dataPoint.communityNeutral * 100,
        communityFall: dataPoint.communityFall * 100
      };
      bottomDialogVisible.value = true;
    }
  }
};

const closeBottomDialog = () => {
  bottomDialogVisible.value = false
}

onMounted(() => {
  setTimeout(() => {
    if (!chartContainer.value || !xAxisContainer.value) {
      return;
    }
    getLineChartData()
    initializeCanvas()
    drawChart()
    setupInteraction()
  }, 100);

  window.addEventListener('resize', handleResize)
})

onUnmounted(() => {
  bottomDialogVisible.value = false
  window.removeEventListener('resize', handleResize)
})
</script>

<style lang="scss" scoped>
.greed-index-chart {
  width: 100%;
}

.chart-header {
  margin-bottom: 10px;
  line-height: 12px;
  font-family: Tomato Grotesk;
  font-weight: 600;
  font-size: 14px;
  letter-spacing: 0%;
  vertical-align: middle;
  text-transform: capitalize;
  color: #ffffff;
}

.chart-container {
  position: relative;
  height: 200px;
  width: 100%;
}

.chart-content {
  height: calc(100% - 20px);
  width: 100%;
  position: relative;
}

.chart-labels {
  display: flex;
  flex-direction: column;
  height: 100%;
  width: 100%;
}

.label-item {
  flex: 1;
  display: flex;
  align-items: center;
  padding-left: 8px;
  color: #9092A8;
  font-family: Tomato Grotesk;
  font-weight: 500;
  font-size: 7px;
  line-height: 12px;
  letter-spacing: 0%;
  vertical-align: middle;
  text-transform: capitalize;

  &.extreme-greed {
    background-color: rgba(15, 122, 82, 0.3);
  }

  &.moderate-greed {
    background-color: rgba(90, 133, 0, 0.3);
  }

  &.neutral {
    background-color: rgba(184, 152, 31, 0.3);
  }

  &.moderate-fear {
    background-color: rgba(168, 92, 0, 0.3);
  }

  &.extreme-fear {
    background-color: rgba(168, 37, 48, 0.3);
  }
}

.chart-wrapper {
  width: 100%;
  height: 100%;
  position: absolute;
  top: 0;
  left: 0;
}

.bg-bands {
  position: absolute;
  left: 0;
  right: 0;
  top: 0;
  bottom: 0;
  display: flex;
  flex-direction: column;
  z-index: 1;
}

.band {
  flex: 1;
  width: 100%;
  position: relative;
}

.chart-main {
  position: relative;
  z-index: 5;
  width: 100%;
  height: 100%;
}

.x-axis-area {
  height: 15px;
  margin-top: 2.5px;
}

/* 悬浮面板样式 */
.hover-panel {
  position: absolute;
  width: 125px;
  box-sizing: border-box;
  background-color: #0A061D;
  border-radius: 4px;
  padding: 6px;
  box-shadow: 0px 2px 10px rgba(0, 0, 0, 0.4);
  border: 0.5px solid rgba(255, 255, 255, 0.1);
  display: flex;
  flex-direction: column;
  z-index: 1000;
  pointer-events: none;
}

.panel-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 4px;
}

.date-time {
  font-family: Tomato Grotesk;
  font-weight: 500;
  font-size: 6px;
  line-height: 10px;
  vertical-align: middle;
  color: rgba(255, 255, 255, 0.6);
}

.date {
  margin-right: 4px;
  color: #fff;
}

.current-sentiment {
  font-size: 6px;
  font-weight: 500;
  padding: 1.5px 4px;
  border-radius: 2px;
}

.extreme-greed {
  background-color: rgba(23, 177, 121, 0.1);
  // color: #17B179;
  color:#9092A8;
}

.moderate-greed {
  background-color: rgba(147, 217, 0, 0.1);
  // color: #93D900;
  color:#9092A8;
}

.neutral {
  background-color: rgba(243, 212, 47, 0.1);
  // color: #F3D42F;
  color:#9092A8;
}

.moderate-fear {
  background-color: rgba(234, 140, 0, 0.1);
  // color: #EA8C00;
  color:#9092A8;
}

.extreme-fear {
  background-color: rgba(234, 57, 67, 0.1);
  // color: #EA3943;
  color:#9092A8;
}

.panel-metrics {
  flex: 1;
  display: flex;
  flex-direction: column;
}

.metrics-row {
  display: flex;
  justify-content: space-between;
  margin-bottom: 10px;
  background-color: #2F2B51;
  border-radius: 6px;
  padding: 5px 0;
}

.metric {
  flex: 1;
  text-align: center;
}

.metric:not(:last-child) {
  border-right: 0.5px solid rgba(255, 255, 255, 0.1);
}

.metric-title {
  font-size: 6px;
  color: rgba(255, 255, 255, 0.6);
  margin-bottom: 4px;
}

.metric-value {
  font-size: 7px;
  font-weight: 500;
  color: #fff;
}

.up-arrow {
  color: #16C784;
  margin-right: 1px;
}

.sentiments-section {
  display: flex;
  justify-content: space-between;
  gap: 8px;
}

.sentiment-col {
  flex: 1;
}

.sentiment-title {
  margin-bottom: 8px;
  font-family: Tomato Grotesk;
  font-weight: 500;
  font-size: 14px;
  line-height: 15px;
  letter-spacing: 0%;
  vertical-align: middle;
  text-transform: capitalize;
  color: #fff;
}

.sentiment-bars {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.sentiment-bar {
  display: flex;
  align-items: center;
}

.bar-container {
  flex: 1;
  height: 15px;
  display: flex;
  align-items: center;
}

.bar {
  height: 8px;
  border-radius: 4px;
  position: relative;
}

.bar.rise-bar {
  background-color: #16C784;
}

.bar.neutral-bar {
  background-color: #FFC107;
}

.bar.fall-bar {
  background-color: #FF6F91;
}

.bar-value {
  white-space: nowrap;
  margin-left: 2px;
  font-family: Tomato Grotesk;
  font-weight: 500;
  font-size: 12px;
  line-height: 15px;
  letter-spacing: 0%;
  vertical-align: middle;
  text-transform: capitalize;

}

.bar-value.rise-bar {
  color: #16C784;
}

.bar-value.neutral-bar {
  color: #FFC107;
}

.bar-value.fall-bar {
  color: #FF6F91;
}

/* 加载状态样式 */
.loading-overlay {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1001;
}

.loading-text {
  font-family: Tomato Grotesk;
  font-weight: 600;
  font-size: 10px;
  color: #fff;
}

/* 无数据状态样式 */
.no-data-overlay {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1001;
}

.no-data-text {
  font-family: Tomato Grotesk;
  font-weight: 600;
  font-size: 10px;
  color: #fff;
}

/* 引入bottom-dialog样式 */
.bottom-dialog-mask {
  position: fixed;
  left: 0;
  top: 0;
  width: 100vw;
  height: 100vh;
  background: rgba(28, 24, 51, 0.4);
  z-index: 2000;
  display: flex;
  align-items: flex-end;
  justify-content: center;
}

.bottom-dialog {
  width: 100%;
  background: #282544;
  border-radius: 12px 12px 0 0;
  box-shadow: 0 0 12px rgba(0, 0, 0, 0.18);
  padding: 16px 12px;
  margin-bottom: 0;
  animation: slideUp 0.25s cubic-bezier(0.4, 0, 0.2, 1);
}

@keyframes slideUp {
  from {
    transform: translateY(100%);
  }

  to {
    transform: translateY(0);
  }
}

.dialog-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 14px;
}

.dialog-title {
  font-family: Tomato Grotesk;
  font-size: 14px;
  font-weight: 600;
  color: #fff;
  display: flex;
  align-items: center;

  .qb-icon {
    width: 18px;
    height: 18px;
    margin-right: 6px;
  }
}

.dialog-date {
  font-size: 11px;
  color: #9E9CB6;
  font-family: Tomato Grotesk;
}

.current-sentiment {
  padding: 6px 8px;
  background-color: #1C1930;
  border-radius: 4px;
  color: #93D900;
  font-family: Tomato Grotesk;
  font-weight: 500;
  font-size: 9px;
  margin-left: 6px;
}

.dialog-footer {
  display: flex;
  justify-content: center;
  margin-top: 12px;
}

.dialog-close-btn {
  margin-top: 21px;
  margin-bottom: 5px;
  width: 100%;
  height: 42px;
  border: none;
  border-radius: 6px;
  background: #39365A;
  color: #fff;
  font-size: 14px;
  font-family: Tomato Grotesk;
  font-weight: 600;
  cursor: pointer;
  transition: background 0.2s;
}

.dialog-close-btn:hover {
  background: #4B476B;
}
</style>
