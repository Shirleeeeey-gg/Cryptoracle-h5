<template>
  <div class="dashboard">

    <!-- 主要内容 -->
    <main class="main-content">
      <!-- 标题部分 -->
      <div class="title-section">
        <div class="main-title">Dashboard</div>
        <div class="subtitle">Your Crypto Markets Dashboard, Optimized For Value</div>
      </div>

      <!-- 统计卡片网格 -->
      <div class="stats-grid">
        <!-- 总数据量 - 突出显示 -->
        <div class="stat-card featured">
          <div class="stat-label">Total Data</div>
          <div class="stat-value featured-value">
            <div class="digit-scroll-container">
              <div v-for="(digit, index) in formatNumber(dataQuantity)" :key="`digit-${index}`" class="digit-column"
                :class="{ 'comma-column': digit === ',' }">
                <template v-if="digit === ','">
                  <div class="comma">,</div>
                </template>
                <template v-else>
                  <div class="digit-wrapper" :style="{ transform: `translateY(-${digit * 10}%)` }">
                    <div v-for="n in 10" :key="n" class="digit">{{ n - 1 }}</div>
                  </div>
                </template>
              </div>
            </div>
          </div>
        </div>

        <!-- 今日数据量 -->
        <div class="stat-card">
          <div class="stat-label">Today's Data</div>
          <div class="stat-value green">
            <div class="digit-scroll-container small">
              <div v-for="(digit, index) in formatNumber(todayData)" :key="`today-digit-${index}`" class="digit-column"
                :class="{ 'comma-column': digit === ',' }">
                <template v-if="digit === ','">
                  <div class="comma">,</div>
                </template>
                <template v-else>
                  <div class="digit-wrapper" :style="{ transform: `translateY(-${digit * 10}%)` }">
                    <div v-for="n in 10" :key="n" class="digit">{{ n - 1 }}</div>
                  </div>
                </template>
              </div>
            </div>
          </div>
        </div>

        <!-- 昨日数据量 -->
        <div class="stat-card">
          <div class="stat-label">Yesterday's Data</div>
          <div class="stat-value">{{ firstScreenData.yesterdayData.toLocaleString() }}</div>
        </div>

        <!-- 昨日分析数据量 -->
        <div class="stat-card">
          <div class="stat-label">Analyzed Yesterday</div>
          <div class="stat-value">{{ firstScreenData.yesterdayAnalysis.toLocaleString() }}</div>
        </div>

        <!-- 私有群组 -->
        <div class="stat-card" @click="jumpPage('groups')">
          <div class="stat-label">Groups</div>
          <div class="stat-value">{{ firstScreenData.privateGroup.toLocaleString() }}</div>
          <img src="@/assets/dashboard/right-arrow-w.svg" alt="" class="btn-arrow">
        </div>

        <!-- 私有KOL -->
        <div class="stat-card">
          <div class="stat-label">KOLs</div>
          <div class="stat-value">{{ firstScreenData.privateKOL.toLocaleString() }}</div>
        </div>

        <!-- 私有社区规模 -->
        <div class="stat-card">
          <div class="stat-label">Total Followers</div>
          <div class="stat-value">{{ firstScreenData.privateCommunity.toLocaleString() }}</div>
        </div>

        <!-- 支持的加密货币 -->
        <div class="stat-card">
          <div class="stat-label">Coins</div>
          <div class="stat-value-with-icons">
            <span class="stat-value">{{ firstScreenData.coverCurrency.toLocaleString() }}</span>
            <div class="icon-box">
              <transition-group name="icon-move" tag="div" class="icon-move-group">
                <img v-for="icon in icons" :key="icon.id" :src="icon.src" alt="" />
              </transition-group>
            </div>
          </div>
        </div>
      </div>

      <!-- AI代理部分 -->
      <div class="ai-agent-section">
        <div class="ai-agent-content">
          <div class="ai-agent-text">
            <div class="ai-agent-title">AI AGENT</div>
            <div class="ai-agent-desc">AI agents transform raw market data into self-optimizing trading signals.</div>
          </div>
          <div class="coming-soon-badge">
            <span>Coming Soon</span>
          </div>
        </div>
      </div>
    </main>
    <div class="aivix-box">
      <Co50AivixCharts />
    </div>
    <!-- 三个排行 -->
    <div class="rank-lists-section">
      <RankList
        type="callout"
        title="Callout Highlights"
        tooltip-content="This shows the top performing tokens based on callout highlights from the community."
        :items="calloutData"
      />
      <RankList
        type="sentiment"
        title="Sentiment Surge"
        tooltip-content="This displays tokens with the highest Sentiment Momentum in the community."
        :items="sentimentData"
      />
      <RankList
        type="dat"
        title="Unusual Market Movers"
        tooltip-content="View tokens from the perspective of digital asset treasury"
        :items="datData"
      />
    </div>
    <!-- KOL List -->
    <div class="kol-section">
      <KolDiscussionHub />
    </div>
    <Footer />
    <BottomNav @login="handleLogin" />
    <Login v-model:visible="loginVisible" @register="handleRegister" />
    <Register v-model:visible="registerVisible" />
  </div>
</template>

<script setup>
import Co50AivixCharts from '@/views/dashboard/components/Co50AivixCharts.vue';
import GreedIndexChart from '@/views/dashboard/components/GreedIndexChart.vue';
import CO50TokenList from '@/components/CO50TokenList.vue';
import HeatStation from '@/components/HeatStation.vue';
import Footer from '@/components/Footer.vue';
import RankList from '@/components/RankList.vue';
import KolDiscussionHub from '@/components/KolDiscussionHub.vue';
import BottomNav from '@/components/BottomNav.vue';
import Login from '@/components/Login/Login.vue';
import Register from '@/components/Login/Register.vue';
import { ref, onMounted, onUnmounted } from 'vue'
import { getDashboardDataApi, getDashboardChangeDataApi } from '@/api/dashboard'
import { getCORankingCalloutHighlightsApi, getCORankingSentimentSurgeApi, getCORankingDATApi } from '@/api/tokenlist'
import { useRouter } from 'vue-router'

const router = useRouter()
const co50TokenListRef = ref(null)
const loginVisible = ref(false)
const registerVisible = ref(false)

const jumpPage = (name) => {
  router.push({
    name
  })
}

// 处理登录按钮点击
const handleLogin = () => {
  loginVisible.value = true
}

// 处理注册按钮点击（从登录弹窗触发）
const handleRegister = () => {
  loginVisible.value = false
  registerVisible.value = true
}

// Callout Highlights 数据
const calloutData = ref([])

// Sentiment Surge 数据
const sentimentData = ref([])

// DAT 数据
const datData = ref([])

// 数字滚动效果相关变量
const dataQuantity = ref(0)
const todayData = ref(0)

// 格式化数字为千分位格式，并处理滚动效果数据
const formatNumber = (num) => {
  if (!num && num !== 0) return [0];
  const numStr = num.toString();
  const result = [];
  let count = 0;
  for (let i = numStr.length - 1; i >= 0; i--) {
    result.unshift(numStr[i]);
    count++;
    if (count % 3 === 0 && i !== 0) {
      result.unshift(',');
    }
  }
  return result.map(char => char === ',' ? ',' : parseInt(char));
};

// 八个核心数据
const firstScreenData = ref({
  totalData: 0, // 总数据量
  todayData: 0, // 今日数据量
  yesterdayData: 0, // 昨日数据量
  yesterdayAnalysis: 0, // 昨日分析数据量
  privateGroup: 0, // 私有群组
  privateKOL: 0, // 私有KOL
  privateCommunity: 0, // 私有社区规模
  coverCurrency: 0 // 支持的加密货币
})

let dataTimer = null

// 获取仪表盘数据
const getDashboardData = async () => {
  const res = await getDashboardDataApi()
  if(res && res.code === 200 && res.data) {
    firstScreenData.value = {
      ...firstScreenData.value,
      ...res.data
    }
    // 初始化滚动数字变量
    dataQuantity.value = res.data.totalData || 0
    todayData.value = res.data.todayData || 0
  }
}
// 获取变动数据（总数据量、今日数据量）
const getDashboardChangeData = async () => {
  const res = await getDashboardChangeDataApi()
  if(res && res.code === 200 && res.data) {
    firstScreenData.value.totalData = res.data.totalData
    firstScreenData.value.todayData = res.data.todayData
    // 更新滚动数字变量
    dataQuantity.value = res.data.totalData
    todayData.value = res.data.todayData
  }
}

onMounted(() => {
  // 获取三个排行数据
  getCORankingCalloutHighlightsApi().then(res => { 
    if (res && res.code === 200 && res.data) {
      calloutData.value = res.data.slice(0, 5)
    }
  })
  getCORankingSentimentSurgeApi().then(res => { 
    if (res && res.code === 200 && res.data) {
      sentimentData.value = res.data.slice(0, 5)
    }
  })
  getCORankingDATApi().then(res => { 
    if (res && res.code === 200 && res.data) {
      datData.value = res.data.slice(0, 5)
    }
  })

  getDashboardData()
  getDashboardChangeData()
  dataTimer = setInterval(() => {
    getDashboardChangeData()
  }, 5000)
})

// 滚动处理函数
const handleScroll = () => {
  if (!co50TokenListRef.value) return;
  // 取出 loading 和 noMoreData，避免重复加载
  if (co50TokenListRef.value.loading.value || co50TokenListRef.value.noMoreData.value) return;

  const { scrollTop, scrollHeight, clientHeight } = document.documentElement;
  // 当滚动到距离底部50px时开始加载下一页
  if (scrollTop + clientHeight >= scrollHeight - 100) {
    co50TokenListRef.value.loadNextPage();
  }
};

onMounted(() => {
  // window.addEventListener('scroll', handleScroll)
})
onUnmounted(() => {
  // window.removeEventListener('scroll', handleScroll)
  if (dataTimer) {
    clearInterval(dataTimer)
    dataTimer = null
  }
})

const iconImgs = [
  new URL('@/assets/icon50/havven.png', import.meta.url).href,
  new URL('@/assets/icon50/bitgettoken.png', import.meta.url).href,
  new URL('@/assets/icon50/decentraland.png', import.meta.url).href,
  new URL('@/assets/icon50/elrond.png', import.meta.url).href,
  new URL('@/assets/icon50/flow.png', import.meta.url).href,
  new URL('@/assets/icon50/kava_72.png', import.meta.url).href,
  new URL('@/assets/icon50/leotoken.png', import.meta.url).href,
  new URL('@/assets/icon50/lidofi.png', import.meta.url).href,
  new URL('@/assets/icon50/pi-network-11.png', import.meta.url).href,
  new URL('@/assets/icon50/tezos.png', import.meta.url).href,
  new URL('@/assets/icon50/thesandbox.png', import.meta.url).href,
  new URL('@/assets/icon50/aave-new.png', import.meta.url).href,
  new URL('@/assets/icon50/algorand.png', import.meta.url).href,
  new URL('@/assets/icon50/aptos.png', import.meta.url).href,
  new URL('@/assets/icon50/arbitrum.png', import.meta.url).href,
  new URL('@/assets/icon50/avalanche.png', import.meta.url).href,
  new URL('@/assets/icon50/binance-coin.png', import.meta.url).href,
  new URL('@/assets/icon50/bitcoin-cash.png', import.meta.url).href,
  new URL('@/assets/icon50/blockstack.png', import.meta.url).href,
  new URL('@/assets/icon50/cardano.png', import.meta.url).href,
  new URL('@/assets/icon50/chainlink.png', import.meta.url).href,
  new URL('@/assets/icon50/cosmos.png', import.meta.url).href,
  new URL('@/assets/icon50/dfinity.png', import.meta.url).href,
  new URL('@/assets/icon50/dogecoin.png', import.meta.url).href,
  new URL('@/assets/icon50/ethena.png', import.meta.url).href,
  new URL('@/assets/icon50/ethereum-classic.png', import.meta.url).href,
  new URL('@/assets/icon50/fetchai2.png', import.meta.url).href,
  new URL('@/assets/icon50/filecoinnew.png', import.meta.url).href,
  new URL('@/assets/icon50/graph.png', import.meta.url).href,
  new URL('@/assets/icon50/hederahashgraph.png', import.meta.url).href,
  new URL('@/assets/icon50/htx.png', import.meta.url).href,
  new URL('@/assets/icon50/immutablex.png', import.meta.url).href,
  new URL('@/assets/icon50/litecoin.png', import.meta.url).href,
  new URL('@/assets/icon50/monero.png', import.meta.url).href,
  new URL('@/assets/icon50/nearprotocol.png', import.meta.url).href,
  new URL('@/assets/icon50/official-trump.png', import.meta.url).href,
  new URL('@/assets/icon50/polkadot100.png', import.meta.url).href,
  new URL('@/assets/icon50/quant.png', import.meta.url).href,
  new URL('@/assets/icon50/shibainu.png', import.meta.url).href,
  new URL('@/assets/icon50/solana.png', import.meta.url).href,
  new URL('@/assets/icon50/stellar.png', import.meta.url).href,
  new URL('@/assets/icon50/thetatoken.png', import.meta.url).href,
  new URL('@/assets/icon50/toncoin.png', import.meta.url).href,
  new URL('@/assets/icon50/tron.png', import.meta.url).href,
  new URL('@/assets/icon50/uniswap.png', import.meta.url).href,
  new URL('@/assets/icon50/usdc.png', import.meta.url).href,
  new URL('@/assets/icon50/vechaincom.png', import.meta.url).href,
  new URL('@/assets/icon50/bitcoin.png', import.meta.url).href,
  new URL('@/assets/icon50/ethereum.png', import.meta.url).href,
  new URL('@/assets/icon50/ripple.png', import.meta.url).href,
]
let currentIconIndex = 0
function getNextIcon() {
  const icon = iconImgs[currentIconIndex]
  currentIconIndex = (currentIconIndex + 1) % iconImgs.length
  return icon
}
// 初始化10个icon
const icons = ref(Array.from({ length: 10 }, (_, i) => ({
  id: Date.now() + '-' + i + '-' + Math.random(),
  src: iconImgs[i]
})))
currentIconIndex = 0
function shiftIcons() {
  icons.value.shift()
  icons.value.push({
    id: Date.now() + '-' + Math.random(),
    src: getNextIcon()
  })
}
let iconTimer = null
onMounted(() => {
  iconTimer = setInterval(() => {
    shiftIcons()
  }, 2000)
})
onUnmounted(() => {
  if (iconTimer) {
    clearInterval(iconTimer)
    iconTimer = null
  }
})

</script>

<style lang="scss" scoped>
.dashboard {
  min-height: 100vh;
  padding: 0;
  position: relative;
  background: url('@/assets/images/dashboard/bg-top.svg') no-repeat top center;
  background-size: 375px 240px;
  padding-top: 91px;
  padding-bottom: 84px; /* BottomNav高度：60px min-height + 24px padding */
}
.aivix-box{
  padding: 0 12px;
  margin-top: 30px;
}
.greed-index{
  padding: 0 12px;
  margin-top: 30px;
}

.rank-lists-section {
  padding: 0 12px;
  margin-top: 30px;
}

.kol-section {
  padding: 0 12px;
  margin-top: 30px;
}

.main-content {
  position: relative;
  padding: 0 12px;
  z-index: 1;
}

.title-section {
  text-align: center;
  margin-bottom: 30px;

  .main-title {
    font-family: Tomato Grotesk;
    font-weight: 400;
    font-size: 30px;
    line-height: 36px;
    letter-spacing: 0%;
    text-align: center;
    margin-bottom: 8px;
  }

  .subtitle {
    font-family: Tomato Grotesk;
    font-weight: 500;
    font-size: 12px;
    text-align: center;
    color: #9E9CB6;
  }
}

.stats-grid {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
}

.stat-card {
  width: 172.5px;
  height: 65px;
  box-sizing: border-box;
  background: #1C1833;
  border-radius: 12px;
  padding: 12px;
  position: relative;
  overflow: hidden;
  margin-bottom: 6px;
  .btn-arrow{
    position: absolute;
    right: 12px;
    top: 12px;
    width: 12px;
    height: 12px;
  }
  &.featured {
    background: #7644FB;

    .stat-label {
      color: #fff;
    }
  }
}

.stat-label {

  font-family: Tomato Grotesk;
  font-weight: 500;
  font-size: 9px;
  line-height: 9px;
  letter-spacing: 0%;
  margin-bottom: 8px;
  color: #9E9CB6;

}

.stat-value {
  font-family: Tomato Grotesk;
  font-weight: 500;
  font-size: 20px;
  line-height: 20px;
  letter-spacing: 0%;
  vertical-align: middle;
  color: #fff;

  &.featured-value {
    font-size: 20px;
    color: #fff;
  }

  &.green {
    color: #4ADE80;
  }
}

.stat-value-with-icons {
  display: flex;
  align-items: center;
  justify-content: space-between;

  .stat-value {
    font-size: 16px;
  }
}

.icon-box {
  display: flex;
  align-items: center;
  justify-content: space-between;
  .icon-move-group {
    display: flex;
    align-items: center;
    position: relative;
  }
  img {
    width: 19px;
    height: 19px;
    border-radius: 50%;
    &:not(:nth-child(10)) {
      margin-left: -11.5px;
    }
    &:nth-child(10) {
      margin-left: 2px;
    }
    // 可选：亮度滤镜
  }
}

.icon-move-enter-active,
.icon-move-leave-active {
  transition: all 0.8s cubic-bezier(0.25, 0.46, 0.45, 0.94);
  will-change: transform, opacity;
}
.icon-move-leave-active {
  position: absolute;
  right: 0;
}
.icon-move-enter-from {
  transform: translateX(40px) scale(0.8);
  opacity: 0;
}
.icon-move-leave-to {
  transform: translateX(-40px) scale(0.8);
  opacity: 0;
}
.icon-move-move {
  transition: transform 0.8s cubic-bezier(0.25, 0.46, 0.45, 0.94);
  will-change: transform;
}

.ai-agent-section {
  background: url('@/assets/images/dashboard/ai-agent-bg.svg') no-repeat center center;
  background-size: cover;
  overflow: hidden;
  height: 73px;
  padding: 12px 9px 10px 12px;
  box-sizing: border-box;
  border: 0.5px solid #474358;
  border-radius: 9px;
}

.ai-agent-content {
  display: flex;
  justify-content: space-between;
  align-items: center;
  position: relative;
  z-index: 2;
  height: 100%;
}

.ai-agent-text {
  width: 186px;

  .ai-agent-title {
    font-family: Tomato Grotesk;
    font-weight: 500;
    font-size: 15px;
    line-height: 15px;
    letter-spacing: 0%;
    vertical-align: middle;
    text-transform: uppercase;
    color: #fff;
    margin-bottom: 8px;
  }

  .ai-agent-desc {
    font-family: Tomato Grotesk;
    font-weight: 400;
    font-size: 10px;
    line-height: 14px;
    letter-spacing: 0%;

    color: rgba(255, 255, 255, 0.8);
  }
}

.coming-soon-badge {
  background: rgba(20, 7, 55, 0.7);
  border: 0.5px solid rgba(136, 117, 217, 1);
  border-radius: 20px;
  // 背景模糊 10
  backdrop-filter: blur(5px);
  width: 105px;
  height: 34px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-family: Tomato Grotesk;
  font-weight: 500;
  font-size: 12px;
  line-height: 12px;
  letter-spacing: 0%;
  text-align: center;
  vertical-align: middle;
  color: #C1AFFF;
}

@keyframes twinkle {
  0% {
    opacity: 0.3;
    transform: scale(1);
  }

  100% {
    opacity: 1;
    transform: scale(1.2);
  }
}

// 数字滚动相关样式
.digit-scroll-container {
  display: flex;
  height: 20px;
  overflow: hidden;
  
  // 为较小的数字容器添加样式
  &.small {
    height: 16px;
    
    .digit-column {
      width: 10px;
      height: 16px;
      
      &.comma-column {
        width: 5px;
      }
      
      .comma {
        font-size: 16px;
        line-height: 16px;
      }
      
      .digit {
        height: 16px;
        line-height: 16px;
        font-size: 16px;
      }
    }
  }
}

.digit-column {
  position: relative;
  width: 12px;
  height: 20px;
  overflow: hidden;
  display: inline-block;

  &.comma-column {
    width: 6px;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .comma {
    font-size: 20px;
    line-height: 20px;
  }

  .digit-wrapper {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    transition: transform 1s ease-in-out;
  }

  .digit {
    height: 20px;
    line-height: 20px;
    text-align: center;
    font-family: Tomato Grotesk;
    font-weight: 500;
    font-size: 20px;
  }
}
</style>