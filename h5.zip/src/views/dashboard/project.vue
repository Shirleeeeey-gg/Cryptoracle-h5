<template>
  <div class="project-container">
    <div class="project-content">
      <section class="top">
        <section class="top-left">
          <div class="token-box">
            <div class="token-card">
              <!-- 头部信息 -->
              <div class="token-header">
                <div class="token-title">
                  <img :src="pageData.coinData?.imageUrl" alt="Bitcoin" class="icon-bit">
                  <span class="token-name">{{ pageData.coinData?.name }}</span>
                  <span class="token-symbol">{{ pageData.coinData?.symbol }}</span>
                  <span class="token-rank">#{{ rank }}</span>
                </div>
                <div class="token-favorite-box">
                  <div class="token-fire">
                    <img src="@/assets/dashboard/icon-fire.svg" alt="Fire" class="icon-fire">
                    <span>{{ $filters.numberSmart(pageData.coinData?.heat * 100) }}%</span>
                  </div>
                  <img 
                    :src="favIconSrc" 
                    alt="Favorite" 
                    class="btn-fav"
                    @click="toggleFavorite"
                    @mouseenter="isHovered = true"
                    @mouseleave="isHovered = false"
                  >
                </div>
              </div>

              <!-- 价格信息 -->
              <div class="token-price-section">
                <div class="price-change-box">
                  <div class="token-price">{{ $filters.price(pageData.coinData?.price) }}</div>
                  <!-- <div class="token-change">
                    <img src="@/assets/dashboard/sg-top-green.svg" alt="Up" class="icon-up">
                    <span class="change-percent">1.34%(1d)</span>
                  </div> -->
                </div>
                <!-- <div class="price-label">Price</div> -->
              </div>

              <section class="top-right">
                <SentimentChart :coin="coin" :id="id" />
              </section>

              <section class="bottom">
                <!-- <section class="bottom-left">
                  <HeatStation />
                </section> -->
                <section class="bottom-right">
                  <div class="bottom-right-top">
                    <StatsCards :pageData="pageData" />
                  </div>
                  <div class="bottom-right-bottom">
                    <HeatTrendChart :coin="coin" :id="id" />
                  </div>
                </section>
              </section>


              <!-- 统计信息区域 -->
              <!-- <div class="token-stat-title">Bitcoin Statistics</div>
              <div class="token-stats">
                <div class="stat-item">
                  <div class="stat-label">
                    <span>Communities(24h)</span>
                    <Tooltip content="Number of Private Communities for this Coin" />
                  </div>
                  <div class="stat-value">{{ $filters.integer(pageData.coinData?.privateCommunity) }}</div>
                </div>

                <div class="stat-item">
                  <div class="stat-label">
                    <span>Followes(24h)</span>
                    <Tooltip content="Total Followers in Private Communities for this Coin" />
                  </div>
                  <div class="stat-value">{{ $filters.integer(pageData.coinData?.privateCommunityScale) }}</div>
                </div>

                <div class="stat-item">
                  <div class="stat-label">
                    <span>Mentions(24h)</span>
                    <Tooltip content="Total Mentions of this Coin Across All Chats" />
                  </div>
                  <div class="stat-value">{{ $filters.integer(pageData.coinData?.mention) }}</div>
                </div>

                <div class="stat-item">
                  <div class="stat-label">
                    <span>KOLs(24h)</span>
                    <Tooltip content="Number of Private KOLs for this Coin" />
                  </div>
                  <div class="stat-value">{{ $filters.integer(pageData.coinData?.kol) }}</div>
                </div>

                <div class="stat-item">
                  <div class="stat-label">
                    <span>Volume(24h)</span>
                  </div>
                  <div class="stat-value">{{ $filters.price(pageData.coinData?.volume) }}</div>
                </div>
              </div> -->
            </div>
          </div>
          <!-- <div class="sentiment-index">
            <div class="sentiment-card">
              <div class="card-left">
                <div class="sentiment-header">
                  <span class="sentiment-title">Fear & Greed Index</span>
                </div>
                <div class="status">{{ sentimentStatus }}</div>
              </div>


              <div class="gauge-container">
                <div class="gauge">
                  <div class="gauge-image-container">
                    <img src="@/assets/dashboard/yuanhu-bg.png" alt="仪表盘背景" class="gauge-bg-image">
                    <div class="indicator" :style="indicatorStyle"></div>
                  </div>
                </div>

                <div class="gauge-value">
                  <div class="value" :style="{ color: valueColor }">{{
                    $filters.numberSmart(pageData.coinData?.emotional) }}</div>
                </div>
              </div>
            </div>
          </div> -->
        </section>

      </section>
    </div>
    <Footer />

  </div>
</template>

<script setup>
import Footer from '@/components/Footer.vue'
import SentimentChart from './components/SentimentChart.vue'
import HeatStation from './components/HeatStation.vue'
import StatsCards from './components/StatsCards.vue'
import HeatTrendChart from '../../components/HeatTrendChart.vue'
import { computed, ref, watch } from 'vue'
import { getProjectLineChartDataApi } from '@/api/dashboard'
import { useRoute } from 'vue-router'
import Tooltip from '@/views/dashboard/components/Tooltip.vue'
// 导入收藏图标
import iconFav from '@/assets/login/icon-fav.svg'
import iconFaved from '@/assets/login/icon-faved.svg'
// 导入收藏接口和用户store
import { getCollectApi, getCancelCollectApi } from '@/api/login'
import { useUserStore } from '@/store/user'
import { ElMessage } from 'element-plus'

const route = useRoute()
const id = computed(() => route.query.id)
const coin = computed(() => route.query.coin)
const rank = computed(() => route.query.rank)

const pageData = ref({})

// 用户store实例
const userStore = useUserStore()

// 收藏状态管理
const isFavorited = ref(0) // 是否已收藏  0 未收藏，1 已收藏
const isHovered = ref(false) // 是否鼠标悬停

// 根据收藏状态和hover状态动态计算图标
const favIconSrc = computed(() => {
  if (isFavorited.value == 1) {
    // 已收藏状态
    return iconFaved
  } else {
    // 未收藏状态
    return iconFav
  }
})

// 切换收藏状态
const toggleFavorite = async () => {
  // 如果当前是未收藏状态（0），调用接口进行收藏
  if (isFavorited.value == 0) {
    try {
      // 调用收藏接口，传入userId和coin
      await getCollectApi({
        userId: userStore.userId,
        coin: coin.value
      })
      // 接口调用成功后，更新收藏状态为已收藏（1）
      isFavorited.value = 1
      ElMessage.success('Added to watchlist')
    } catch (error) {
      // 接口调用失败时，保持未收藏状态，并提示错误
      console.error('收藏失败:', error)
    }
  } else {
    // 如果当前是已收藏状态（1），调用取消收藏接口
    try {
      // 调用取消收藏接口，传入userId和coin
      await getCancelCollectApi({
        userId: userStore.userId,
        coin: coin.value
      })
      // 接口调用成功后，更新收藏状态为未收藏（0）
      isFavorited.value = 0
      ElMessage.success('Removed from watchlist')
    } catch (error) {
      // 接口调用失败时，保持已收藏状态，并提示错误
      console.error('取消收藏失败:', error)
    }
  }
}

const loadData = async () => {
  const res = await getProjectLineChartDataApi({
    userId: userStore.userId,
    coin: route.query.coin,
    id: route.query.id,
  })
  pageData.value = res.data
  isFavorited.value = res.data.isFavorited || 0
}

watch(
  () => [route.query.coin, route.query.id],
  () => {
    loadData()
  },
  { immediate: true }
)

// 计算指示点位置
const indicatorStyle = computed(() => {
  let leftPercent = 2
  let bottomPercent = 8

  const emotionalValue = pageData.value.coinData?.emotional
  if (emotionalValue === undefined || emotionalValue === null) {
    return {
      left: `${leftPercent}%`,
      bottom: `${bottomPercent}%`,
    }
  }

  // 将-1到1的范围映射到仪表盘位置
  // -1对应最左边，1对应最右边
  if (emotionalValue <= -0.8) {
    leftPercent = 4
    bottomPercent = 26
  } else if (emotionalValue <= -0.6) {
    leftPercent = 7
    bottomPercent = 44
  } else if (emotionalValue <= -0.4) {
    leftPercent = 13
    bottomPercent = 62
  } else if (emotionalValue <= -0.2) {
    leftPercent = 27
    bottomPercent = 84
  } else if (emotionalValue <= 0) {
    leftPercent = 39
    bottomPercent = 93
  } else if (emotionalValue <= 0.2) {
    leftPercent = 58
    bottomPercent = 94
  } else if (emotionalValue <= 0.4) {
    leftPercent = 70
    bottomPercent = 86
  } else if (emotionalValue <= 0.6) {
    leftPercent = 85
    bottomPercent = 66
  } else if (emotionalValue <= 0.8) {
    leftPercent = 91
    bottomPercent = 49
  } else {
    leftPercent = 97
    bottomPercent = 11
  }

  return {
    left: `${leftPercent}%`,
    bottom: `${bottomPercent}%`,
  }
})

// 根据情感值确定状态
const sentimentStatus = computed(() => {
  const value = pageData.value.coinData?.emotional
  if (value === undefined || value === null) return 'Neutral'

  if (value >= 0.6) return 'Extreme Rise'
  if (value >= 0.2) return 'Strong Rise'
  if (value >= -0.2) return 'Neutral'
  if (value >= -0.6) return 'Decline'
  return 'Sharp Decline'
})

// 根据情感值确定颜色
const valueColor = computed(() => {
  const value = pageData.value.coinData?.emotional
  if (value === undefined || value === null) return '#FFCE20'

  if (value >= 0.6) return '#00D1B2'      // 青色
  if (value >= 0.2) return '#85D855'      // 绿色
  if (value >= -0.2) return '#FFCE20'     // 黄色
  if (value >= -0.6) return '#FF8E29'     // 橙色
  return '#FF4D5E'                        // 红色
})
</script>

<style lang="scss" scoped>
.project-container {
  background-color: #030219;
  padding-top: 84px;

  .project-content {
    padding: 0 12px;

    .bottom {
      .bottom-right {

        .bottom-right-top {
          margin-bottom: 10px;
        }
      }
    }
  }
}

.token-box {
  .token-card {
    border-radius: 8px;
    color: #fff;
    font-family: Arial, sans-serif;
    box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2);
  }

  .token-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 8px;
  }

  .token-title {
    display: flex;
    align-items: center;
    gap: 6px;

    .icon-bit {
      width: 32px;
      height: 32px;
    }

    .token-name {
      font-size: 14px;
      font-weight: 600;
    }

    .token-symbol {
      font-size: 12px;
      color: #9E9CB6;
      margin-left: 2px;
    }

    .token-rank {
      color: #9E9CB6;
      font-size: 12px;
      margin-left: 4px;
      background-color: #2D2D47;
      border-radius: 10px;
      padding: 1px 8px;
    }
  }

  .token-favorite-box{
    display: flex;
    align-items: center;
    gap: 12px;
    .token-fire {
      display: flex;
      align-items: center;
      gap: 2px;

      .icon-fire {
        width: 11.5px;
        height: 15px;
      }

      span {
        font-size: 14px;
        font-weight: 600;
      }
    }
    .btn-fav {
      width: 28px;
      height: 28px;
      cursor: pointer;
      transition: opacity 0.2s ease;

      &:active {
        opacity: 0.8;
      }
    }
  }
  

  .token-price-section {
    margin-bottom: 12px;
    padding-bottom: 6px;
  }

  .price-change-box {
    display: flex;
    justify-content: flex-start;
    align-items: center;
  }

  .token-price {
    font-size: 26px;
    font-weight: 800;
    margin-right: 2.5px;
  }

  .token-change {
    display: flex;
    align-items: center;
    gap: 2px;
    margin-bottom: 3px;

    .icon-up {
      width: 4.5px;
      height: auto;
    }

    .change-percent {
      color: #00C087;
      font-size: 7px;
    }
  }

  .price-label {
    font-size: 6px;
    color: rgba(255, 255, 255, 0.5);
  }

  .token-stat-title {
    font-size: 14px;
    font-weight: 600;
    margin-bottom: 14px;
  }

  .token-stats {
    display: flex;
    flex-direction: column;
    gap: 14px;
    margin-bottom: 31px;
  }

  .stat-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }

  .stat-label {
    display: flex;
    align-items: center;
    gap: 3px;
    font-weight: 500;
    font-size: 12px;
    color: #9092A8;

    .icon-info {
      width: 6px;
      height: 6px;
      opacity: 0.7;
    }
  }

  .stat-value {
    font-size: 12px;
    font-weight: 500;
  }
}

.sentiment-index {
  margin-top: 10px;

  .sentiment-card {
    height: 110px;
    box-sizing: border-box;
    background: #1C1833;
    border-radius: 12px;
    padding: 12px;
    color: #fff;
    font-family: Arial, sans-serif;
    box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2);
    display: flex;
    justify-content: space-between;
    align-items: center;
  }

  .card-left {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
  }

  .sentiment-header {
    display: flex;
    align-items: center;
    margin-bottom: 25px;

    .icon-info {
      margin-left: 2px;
    }
  }

  .sentiment-title {
    font-size: 14px;
    font-weight: 600;
  }

  .info-icon {
    cursor: pointer;
    opacity: 0.7;

    &:hover {
      opacity: 1;
    }
  }

  .gauge-container {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    position: relative;
  }

  .gauge {
    position: relative;
    width: 130px;
    height: 70px;
    margin-bottom: 5px;
    display: flex;
    justify-content: center;
    margin-top: 5px;
  }

  .gauge-image-container {
    position: relative;
    width: 114px;
    height: 59px;
    display: flex;
    justify-content: center;
    margin: 0 auto;
    overflow: visible;
  }

  .gauge-bg-image {
    width: 114px;
    height: 59px;
    position: relative;
    z-index: 1;
  }

  .indicator {
    position: absolute;
    width: 10px;
    height: 10px;
    background-color: white;
    border-radius: 50%;
    border: 1px solid #1E1E2E;
    transform: translate(-50%, 50%);
    box-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
    z-index: 2;
  }

  .gauge-value {
    text-align: center;
    position: absolute;
    bottom: 20px;
    width: 100%;
  }

  .value {
    font-size: 23px;
    font-weight: 700;
    line-height: 1;
    margin-bottom: 4px;
  }

  .status {
    font-size: 14px;
    color: #fff;
    height: 28px;
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 0 12px;
    background-color: #16C784;
    border-radius: 4px;
    min-width: 122.5px;
    box-sizing: border-box;
    font-family: Tomato Grotesk;
    font-weight: 500;
    vertical-align: middle;
    text-transform: capitalize;

  }
}
</style>