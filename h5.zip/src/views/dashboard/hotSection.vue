<template>
  <div class="hot-section">
    <div class="hot-section-content">
      <div class="title">{{title}}</div>
      <div class="sub-title">{{ subTitle }}</div>
      <!-- CO50 Token List -->
      <CO50TokenList />
    </div>
    
    <Footer />
  </div>
</template>

<script setup>
import Footer from '@/components/Footer.vue'
import CO50TokenList from './components/CO50TokenList.vue'
import { useRoute } from 'vue-router'
import { computed } from 'vue'

const route = useRoute()

const title = computed(()=>{
  if(route.query.type == 1){
    return 'Callout Highlights'
  }else if(route.query.type == 2){
    return 'Unusual Market Movers'
  }else if(route.query.type == 3){
    return 'Sentiment Surge'
  }
})

const subTitle = computed(()=>{
  if(route.query.type == 1){
    return 'We analyze token popularity trends across various communities using multiple dimensions, including discussion volume, frequency of mentions in private domain groups, and commentary from high-weighted users, to rank the Top 10 Tokens.'
  }else if(route.query.type == 2){
    return 'We identify the top 10 tokens—among the 30 mainstream tokens we monitor—that show the highest volatility and corresponding spikes in discussions across groups and key opinion leaders (KOLs).'
  }else if(route.query.type == 3){
    return 'Top 10 Tokens by Rapid Sentiment Acceleration in Private Communities (24H) ,These tokens exhibit the fastest-growing sentiment or engagement in the past 24 hours. Mentions may originate from any user or group, and those with high frequency are included in the ranking.'
  }
})
</script>

<style lang="scss" scoped>
.hot-section {
  background-color: #0A061D;
  padding-top: 91px;

  .hot-section-content {

    .title {
      font-family: Tomato Grotesk;
      font-weight: 400;
      font-size: 20px;
      line-height: 100%;
      letter-spacing: 0%;
      margin-bottom: 12px;
      padding: 0 12px;
    }

    .sub-title {
      font-family: Tomato Grotesk;
      font-weight: 500;
      font-size: 11px;
      line-height: 16px;
      letter-spacing: 0%;
      text-transform: capitalize;
      color:#9E9CB6;
      padding: 0 12px;
    }
  }
}
</style>