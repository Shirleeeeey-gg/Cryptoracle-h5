<template>
  <div class="home-container">

    <!-- 其他内容 -->
    <section class="banner">
      <!-- <img src="@/assets/images/home/home-logo.png" alt="" class="home-logo"> -->
      <div class="notice-box">Precision Analytics, Expert-Driven <span>Alpha</span></div>
      <div class="main-title">
        AI-Powered Quantitative Precision Engine
        <img src="@/assets/banner-arrow.png" alt="" class="banner-arrow">
      </div>
      <div class="sub-title">The first infrastructure decoding markets via machine learning,<br> generating adaptive
        strategies & empowering decisions with institutional-grade analytics.</div>
      <div class="btn-start" @click="handleStartClick">
        <img src="@/assets/btn-start.png" alt="">
      </div>
    </section>
    <section class="groups">
      <div class="groups-title">
        <div class="groups-title-wrapper">
          Power Investment, Marketing and Growth Teams
        </div>
      </div>
      <div class="groups-content">
        <div class="scroll-row-wrapper">
          <div class="scroll-row">
            <div class="groups-item" v-for="i in [1,2,3,4,5,15]" :key="'row1-' + i">
              <img :src="getCompanyImg(i)" alt="">
            </div>
            <div class="groups-item" v-for="i in [1,2,3,4,5,15]" :key="'row1-dup-' + i">
              <img :src="getCompanyImg(i)" alt="">
            </div>
          </div>
        </div>
        <div class="scroll-row-wrapper">
          <div class="scroll-row">
            <div class="groups-item" v-for="i in [6,7,8,9,10]" :key="'row2-' + i">
              <img :src="getCompanyImg(i)" alt="">
            </div>
            <div class="groups-item" v-for="i in [6,7,8,9,10]" :key="'row2-dup-' + i">
              <img :src="getCompanyImg(i)" alt="">
            </div>
          </div>
        </div>
        <div class="scroll-row-wrapper">
          <div class="scroll-row">
            <div class="groups-item" v-for="i in [11,12,13,14]" :key="'row3-' + i">
              <img :src="getCompanyImg(i)" alt="">
            </div>
            <div class="groups-item" v-for="i in [11,12,13,14]" :key="'row3-dup-' + i">
              <img :src="getCompanyImg(i)" alt="">
            </div>
          </div>
        </div>
      </div>
    </section>
    <section class="section2">
      <div class="section2-title">
        Redefine Crypto Investment Paradigms
        <img src="@/assets/section2-title-bg.png" alt="" class="section2-title-bg">
      </div>
      <!-- <div class="section2-subtitle">We pioneer the gold standard in AI-powered quantitative analysis, decoding
        on-chain/market alpha through machine learning modeling to build 24/7 adaptive multi-factor strategies. Our
        infrastructure empowers institutions and individuals with precision tools to navigate crypto complexities,
        establishing the trust anchor for next-gen digital asset allocation in the decentralized finance revolution.
      </div> -->
    </section>
    <section class="application" id="applications">
      <!-- <img src="@/assets/app-title-bg.png" alt="" class="app-title-bg"> -->
      <div class="main-title">Applications</div>
      <div class="sub-title">AI-Driven Applications developed by Cryptooracle</div>
      <!-- <div class="app-list">
        <div class="app-item">
          <div class="item-left">
            <img src="@/assets/app1.png" alt="">
          </div>
          <div class="item-right">
            <div class="right-title">Adaptive AI Engine</div>
            <div class="right-content">Dynamic multi-factor models auto-adapt to market volatility, delivering tailored
              analytics from BTC to long-tail assets.</div>
          </div>
        </div>
        <div class="app-item">
          <div class="item-left">
            <img src="@/assets/app2.png" alt="">
          </div>
          <div class="item-right">
            <div class="right-title">News Sentience Radar</div>
            <div class="right-content">Analyzes global crypto media/community sentiment in real-time, precisely
              capturing sentiment factors and filtering high-value signals.</div>
          </div>
        </div>
        <div class="app-item">
          <div class="item-left">
            <img src="@/assets/app3.png" alt="">
          </div>
          <div class="item-right">
            <div class="right-title">Strategy Foundry</div>
            <div class="right-content">Pre-built crypto-native strategies with multi-dimensional backtesting,
              integrating quantitative factors and sentiment indicators for model fusion.</div>
          </div>
        </div>
        <div class="app-item">
          <div class="item-left">
            <img src="@/assets/app4.png" alt="">
          </div>
          <div class="item-right">
            <div class="right-title">ChainSage Bot</div>
            <div class="right-content">Multi-chain conversational AI for portfolio diagnostics and risk scans,
              integrated with DEX/CEX for seamless execution.
            </div>
          </div>
        </div>
      </div> -->
      <img src="@/assets/images/home/apps.png" alt="" class="apps-img">
    </section>
    <section class="newsletter">
      <!-- <div class="main-title">Newsletter</div>
      <div class="sub-title">Subscribe to our amazing newsletter to receive all the latest news & updates.</div>
      <div class="input-box">
        <input type="text" v-model="mailbox" placeholder="Your email address">
        <div class="btn-sub" @click="handleSubscribe">Subscribe</div>
      </div> -->

      <div class="index-footer">
        <div class="footer-wrapper">
          <img src="@/assets/logo-bottom.png" alt="" class="logo-bottom">

          <!-- 社交媒体图标 -->
          <div class="social-icons">
            <img src="@/assets/icon-x.png" alt="Twitter" class="social-icon" @click="jumpLink('https://x.com/web3cryptoracle')">
            <img src="@/assets/icon-youtube.png" alt="YouTube" class="social-icon" @click="jumpLink('https://www.youtube.com/@Cryptoracle_AI')">
          </div>

          <!-- 导航链接 -->
          <!-- <div class="footer-nav">
            <div class="nav-section">
              <h3 class="section-title">About Us</h3>
              <div class="nav-links">
                <div class="nav-link">Introduction</div>
                <div class="nav-link">Data Strategies</div>
              </div>
            </div>

            <div class="nav-section">
              <h3 class="section-title">Support</h3>
              <div class="nav-links">
                <div class="nav-link">Contact Us</div>
                <div class="nav-link">FAQ</div>
              </div>
            </div>
          </div> -->

          <!-- 版权信息 -->
          <div class="copyright">Copyright © 2025. All rights reserved</div>
        </div>
      </div>
    </section>

    <!-- Cookie 提示条 -->
    <CookieBar />
  </div>
</template>

<script setup>
import { useRouter, useRoute } from 'vue-router';
import { saveEmailApi } from '@/api/twitter';
import { ref, onMounted } from 'vue';
import { ElMessage } from 'element-plus';
import CookieBar from '@/components/Login/CookieBar.vue';
import { googleCallbackApi } from '@/api/login';
import { useUserStore } from '@/store/user';

const router = useRouter();
const route = useRoute();
const userStore = useUserStore();
const mailbox = ref('');

// 动态获取公司图片路径
const getCompanyImg = (i) => {
  const extension = i >= 12 ? 'svg' : 'png';
  return new URL(`/src/assets/companies/${i}.${extension}`, import.meta.url).href;
};

const handleStartClick = () => {
  router.push('/dashboard');
};

const handleSubscribe = async () => {
  try {
    await saveEmailApi({ mailbox: mailbox.value });
    ElMessage.success('Subscribe Successful');
    mailbox.value = ''; // 清空输入框
  } catch (error) {
    ElMessage.error('Subscribe Failed');
  }
};

const handleWhitePaperClick = () => {
  // Implementation of handleWhitePaperClick
};

const jumpLink = (url) => {
  window.open(url, '_blank');
};

// 组件挂载时处理 Google 登录回调
onMounted(() => {
  // 处理 Google 登录回调
  // 检测 URL 中是否包含 Google 回调参数（state, code, scope, authuser, prompt）
  const { state, code, scope, authuser, prompt } = route.query;
  if (state && code && scope) {
    // 调用 Google 回调接口，传入所有查询参数
    googleCallbackApi({
      state,
      code,
      scope,
      authuser: authuser || undefined,
      prompt: prompt || undefined
    }).then(res => {
      if (res && res.data && res.data.token) {
        // 直接将 res.data 存储到 userStore，因为所有用户信息字段都在 res.data 中
        userStore.setUserInfo(res.data);
        
        ElMessage.success({
          message: 'Logged in successfully',
          zIndex: 20000
        });
        
        // 清除 URL 中的查询参数，避免刷新页面时重复调用
        router.replace({ path: route.path });
      }
    }).catch(error => {
      // 错误信息已通过 request.js 中的 ElMessage 显示
      console.error('Google callback error:', error);
    });
  }
});
</script>

<style scoped lang="scss">
// @use '@/styles/mixins' as mix;

.pc-index-nav {
  @media (max-width: 384px) {
    display: none;
  }
}

.home-container {
  min-height: 100vh;
  background-color: #030219;

  .banner {
    overflow: hidden;
    height: 465px;
    background-size: cover;
    background-position: center;
    display: flex;
    flex-direction: column;
    align-items: center;
    background: url('@/assets/mobile-banner-bg.png') no-repeat bottom left;
    background-size: 100% auto;
    box-sizing: border-box;
    padding-top: 125px;

    .home-logo {
      width: 137px;
      display: block;
      margin-bottom: 81px;
      margin-top: 19px;
    }

    .notice-box {
      width: 259px;
      height: 27px;
      border: 0.5px solid transparent;
      background-clip: padding-box;
      font-family: Tomato Grotesk;
      font-weight: 400;
      font-size: 7px;
      color: rgba(255, 255, 255, 0.8);
      background: linear-gradient(180deg, rgba(150, 136, 192, 0.1) 0%, rgba(255, 255, 255, 0.1) 100%);
      margin: 0 auto;
      display: flex;
      justify-content: center;
      align-items: center;
      font-size: 12px;
      border-radius: 8px;

      span {
        color: rgba(136, 109, 255, 1);
        margin-left: 5px;
      }


    }

    .main-title {
      margin: 0 auto;
      margin-top: 3px;
      width: 530.5px;
      height: 110px;
      position: relative;
      background: linear-gradient(180deg, #AB8BFF 6.74%, #F2DFFC 47.18%);
      -webkit-background-clip: text;
      background-clip: text;
      color: transparent;
      font-family: Tomato Grotesk;
      font-weight: 400;
      font-size: 48px;
      line-height: 55px;
      letter-spacing: 0%;
      text-align: center;

      // @media (max-width: 384px) {
        width: 100%;
        height: auto;
        font-size: 30px;
        line-height: 1.2;
        margin-top: 17px;
        text-align: center;
        padding: 0;
      // }

      .banner-arrow {
        position: absolute;
        width: 98.36716px;
        height: 79.97873px;
        bottom: -14.5px;
        left: -8.5px;

        // @media (max-width: 384px) {
          width: 68.5px;
          height: 56px;
          display: block;
          position: absolute;
          bottom: -16px;
          left: 11px;
        // }
      }
    }

    .sub-title {
      font-family: Tomato Grotesk;
      font-weight: 500;
      font-size: 8px;
      line-height: 15px;
      letter-spacing: 0%;
      text-align: center;
      text-transform: capitalize;
      color: rgba(255, 255, 255, 0.8);
      margin-top: 24px;

      // @media (max-width: 384px) {
        width: 100%;
        margin-top: 28.5px;
        font-size: 11px;
        line-height: 19px;
        padding: 0 29px;
        text-align: center;
        color: rgba(255, 255, 255, 0.8);

        br {
          display: none;
        }
      // }
    }

    .btn-start {
      margin-top: 65px;
      cursor: pointer; // 添加鼠标手型
      img {
        display: block;
        width: 152px;
        height: 48px;
        margin: 0 auto;

        // @media (max-width: 384px) {
          width: 152px;
          height: auto;
        // }
      }
    }

    // Add white paper button for mobile
    .white-paper-btn {
      display: none;

      // @media (max-width: 384px) {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 152px;
        height: 44px;
        background: linear-gradient(95deg, #6E32FF 10.23%, #7948FF 92.81%);
        border-radius: 22px;
        margin-top: 30px;
        cursor: pointer;
        color: white;
        font-weight: 600;
        font-size: 14px;

        .plus-icon {
          display: inline-block;
          margin-right: 8px;
          font-size: 18px;
        }
      // }
    }
  }

  .groups {
    margin-top: 50px;

    .groups-title {
      height: 80px;
      background-image: url('@/assets/images/home/title-bg-logo.png');
      background-size: 114px 79.5px;
      background-repeat: no-repeat;
      background-position: center center;
      font-family: Tomato Grotesk;
      font-weight: 400;
      font-size: 20px;
      line-height: 100%;
      letter-spacing: 0%;
      padding: 0 48px;
      margin-bottom: 15px;
      box-sizing: border-box;
      display: flex;
      justify-content: center;
      align-items: center;

      .groups-title-wrapper {
        background: linear-gradient(180deg, #AB8BFF 6.74%, #F2DFFC 47.18%);
        -webkit-background-clip: text;
        background-clip: text;
        color: transparent;
        text-align: center;
      }
    }

    .groups-content {
      display: flex;
      flex-direction: column;

      .scroll-row-wrapper {
        width: 100%;
        overflow: hidden;
        position: relative;
      }
      .scroll-row {
        display: flex;
        width: max-content;
        animation: scroll-x 16s linear infinite;
        align-items: center;
        will-change: transform;
        backface-visibility: hidden;
        -webkit-backface-visibility: hidden;
        transform-style: preserve-3d;
        -webkit-transform-style: preserve-3d;
      }
      .scroll-row-wrapper:nth-child(2) .scroll-row {
        animation-duration: 20s;
      }
      .scroll-row-wrapper:nth-child(3) .scroll-row {
        animation-duration: 18s;
      }
      .groups-item {
        height: 60px;
        min-width: 90px;
        display: flex;
        align-items: center;
        justify-content: center;
        img {
          display: block;
          height: 100%;
        }
      }
    }
  }

  .section2 {

    .section2-title {
      position: relative;
      height: 210px;
      font-family: Tomato Grotesk;
      font-weight: 400;
      font-size: 20px;
      line-height: 100%;
      letter-spacing: 0%;
      text-align: center;
      line-height: 24px;
      /* 添加渐变文字效果 */
      background: linear-gradient(180deg, #AB8BFF 6.74%, #F2DFFC 47.18%);
      -webkit-background-clip: text;
      background-clip: text;
      color: transparent;
      padding: 0 48px;
      box-sizing: border-box;
      padding-top: 110px;

      .section2-title-bg {
        position: absolute;
        display: block;
        width: 375px;
        height: 210px;
        top: 0;
        left: 0;
      }
    }

    .section2-subtitle {
      margin-top: 2.5px;
      width: 418.5px;
      margin: 0 auto;
      color: rgba(255, 255, 255, 0.60);
      text-align: center;
      font-family: "Tomato Grotesk";
      font-size: 8px;
      font-style: normal;
      font-weight: 500;
      line-height: 15px;
      /* 187.5% */
      text-transform: capitalize;

      // @media (max-width: 384px) {
        width: 100%;
        font-size: 11px;
        line-height: 18px;
        padding: 0 5px;
      // }
    }
  }

  .application {
    margin-top: 27px;

    padding: 0px 20px;

    .apps-img {
      display: block;
      width: 100%;
    }

    .app-title-bg {
      display: block;
      width: 259.0025px;
      height: 150.001px;
      margin: 0 auto;

      // @media (max-width: 384px) {
        width: 100%;
        height: auto;
      // }
    }

    .main-title {
      text-align: center;
      font-family: "Tomato Grotesk";
      font-size: 20px;
      font-style: normal;
      font-weight: 400;
      line-height: normal;
      background: linear-gradient(180deg, #AB8BFF 6.74%, #F2DFFC 47.18%);
      background-clip: text;
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      margin-bottom: 12.5px;

      // @media (max-width: 384px) {
        margin-top: 20px;
        font-size: 20px;
        margin-bottom: 15px;
      // }
    }

    .sub-title {
      color: rgba(255, 255, 255, 0.60);
      text-align: center;
      font-family: "Tomato Grotesk";
      font-size: 8px;
      font-style: normal;
      font-weight: 500;
      line-height: 15px;
      /* 187.5% */
      text-transform: capitalize;

      // @media (max-width: 384px) {
        font-size: 11px;
        line-height: 1.5;
        margin-bottom: 20px;
      //  }
    }

    .app-list {
      width: 704px;
      margin: 0 auto;
      margin-top: 40px;
      display: flex;
      flex-wrap: wrap;
      justify-content: space-between;

      // @media (max-width: 384px) {
        width: 100%;
        flex-direction: column;
        box-sizing: border-box;
        padding: 0 15px;
      // }

      .app-item {
        box-sizing: border-box;
        overflow: hidden;
        width: 346px;
        height: 120px;
        box-sizing: border-box;
        flex-shrink: 0;
        border-radius: 12px;
        border: 0.5px solid #595185;
        background: linear-gradient(194deg, rgba(111, 72, 204, 0.10) -0.35%, rgba(0, 0, 0, 0.10) 89.15%);
        display: flex;
        justify-content: space-between;
        margin-bottom: 12px;

        // @media (max-width: 384px) {
          width: 100%;
          height: 131.5px;
          margin-bottom: 12.5px;
          overflow: hidden;
          border-radius: 10px;
        // }

        &:nth-child(3),
        &:nth-child(4) {
          margin-bottom: 0;

          // @media (max-width: 384px) {
            &:nth-child(3) {
              margin-bottom: 16px;
            }
          // }
          }
        }

        .item-left {
          width: 170px;
          height: 120px;

          // @media (max-width: 384px) {
            width: 150px;
            height: 131.5px;
            display: flex;
            justify-content: center;
            align-items: center;
          // }

          &>img {
            display: block;
            width: 100%;
            height: 100%;

            // @media (max-width: 384px) {
              object-fit: contain;
            // }
          }
        }

        .item-right {
          box-sizing: border-box;
          padding: 17.5px 10px;
          width: 175.5px;
          height: 119px;
          border-radius: 10px;
          border: 0.5px solid #453774;
          background: linear-gradient(73deg, rgba(94, 62, 172, 0.30) 3.05%, rgba(39, 20, 83, 0.00) 82.33%);

          // @media (max-width: 384px) {
            width: 195.5px;
            height: 131.5px;
            padding: 17.5px 12px;
            border-top-right-radius: 0;
            border-top-left-radius: 0;
          // }

          .right-title {
            color: #FFF;
            font-family: "Tomato Grotesk";
            font-size: 12px;
            font-style: normal;
            font-weight: 500;
            line-height: normal;
            margin-bottom: 10px;

            // @media (max-width: 384px) {
              font-size: 14px;
              margin-bottom: 7.5px;
            // }
          }

          .right-content {
            color: rgba(255, 255, 255, 0.60);
            font-family: "Tomato Grotesk";
            font-size: 7px;
            font-style: normal;
            font-weight: 400;
            line-height: 10px;
            /* 142.857% */
            letter-spacing: 0.14px;
            text-transform: capitalize;

            // @media (max-width: 384px) {
              font-size: 10px;
              line-height: 12px;
              letter-spacing: 0.2px;
            // }
          }
        }
      }
    }
  }

  .newsletter {
    background: linear-gradient(180deg, rgba(3, 2, 25, 0.00) 20%, #6F48CC 99.87%);
    padding-top: 60px;


    .main-title {
      text-align: center;
      font-family: "Tomato Grotesk";
      font-size: 15px;
      font-style: normal;
      font-weight: 400;
      line-height: normal;
      background: linear-gradient(180deg, #AB8BFF 6.74%, #F2DFFC 47.18%);
      background-clip: text;
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      margin-bottom: 4px;

      // @media (max-width: 384px) {
        font-size: 20px;
        margin-bottom: 15px;
      // }
    }

    .sub-title {
      color: rgba(255, 255, 255, 0.60);
      text-align: center;
      font-family: "Tomato Grotesk";
      font-size: 8px;
      font-style: normal;
      font-weight: 500;
      line-height: 15px;
      /* 187.5% */
      text-transform: capitalize;
      margin-bottom: 14px;

      // @media (max-width: 384px) {
        font-size: 11px;
        line-height: 18px;
        padding: 0 60px;
        margin-bottom: 30px;
      // }
    }

    .input-box {
      margin: 0 auto;
      box-sizing: border-box;
      padding: 0 10px;
      width: 460px;
      height: 50px;
      flex-shrink: 0;
      border-radius: 30px;
      border: 0.5px solid rgba(192, 180, 255, 0.60);
      background: rgba(16, 7, 45, 0.50);
      display: flex;
      justify-content: space-between;
      align-items: center;

      // @media (max-width: 384px) {
        width: 345px;
        height: 60px;
        border-radius: 30px;
        padding: 0 10px 0 20px;
      // }

      input {
        width: 300px;
        padding-left: 5px;
        line-height: 50px;
        border: none;
        background: transparent;
        outline: none;
        color: #FFF;
        font-family: "PP Neue Montreal";
        font-size: 12px;
        font-style: normal;
        font-weight: 500;

        // @media (max-width: 384px) {
          width: 215px;
          font-size: 14px;
          line-height: 60px;
          padding-left: 0;
        // }

        &::placeholder {
          color: rgba(205, 193, 255, 0.50);
          font-family: "PP Neue Montreal";
          font-size: 12px;
          font-style: normal;
          font-weight: 500;
          /* 125% */
          text-transform: capitalize;

          // @media (max-width: 384px) {
            font-size: 14px;
          // }
        }
      }

      .btn-sub {
        cursor: pointer;
        width: 80px;
        height: 30px;
        flex-shrink: 0;
        border-radius: 20px;
        background: linear-gradient(95deg, #6E32FF 10.23%, #7948FF 92.81%);
        color: #FFF;
        font-family: "Tomato Grotesk";
        font-size: 10px;
        font-style: normal;
        font-weight: 600;
        line-height: 30px;
        text-align: center;

        // @media (max-width: 384px) {
          width: 100px;
          height: 40px;
          font-size: 15px;
          line-height: 40px;
          border-radius: 20px;
        // }

        &:hover {
          background: #fff;
          color: #5E26F6;
        }
      }
    }

          .index-footer {
        background-color: #030219;
        padding-top: 50px;
        padding-bottom: 30px;
        margin-top: 60px;
        background: url('@/assets/index-footer-bg.png') no-repeat #030219;
        background-position: bottom right;
        background-size: 349.5px 327.5px;
      .footer-wrapper {
        .logo-bottom {
          display: block;
          width: 200px;
          margin:0 auto;
          margin-bottom: 20px;
        }

        .social-icons {
          display: flex;
          justify-content: center;
          gap: 14px;
          margin-bottom: 40px;

          .social-icon {
            width: 36px;
            height: 36px;
            border-radius: 50%;
          }
        }

        .footer-nav {

          .nav-section {
            &:first-child{
              margin-bottom: 16px;
            }
            .section-title {
              margin:0;
              font-family: Tomato Grotesk;
              font-weight: 400;
              font-style: Regular;
              font-size: 15px;
              line-height: 100%;
              letter-spacing: 0%;
              text-transform: capitalize;
              color:#8985A2;
              margin-bottom: 15px;
            }

            .nav-links {
              .nav-link {
                height:32px;
                color:#fff;
                font-family: Tomato Grotesk;
                font-weight: 500;
                font-style: Medium;
                font-size: 18px;
                line-height: 100%;
                letter-spacing: 0%;
                text-transform: capitalize;

              }
            }
          }
        }

        .copyright {
          font-family: Tomato Grotesk;
          font-weight: 400;
          font-style: Regular;
          font-size: 12px;
          line-height: 9px;
          letter-spacing: 0%;
          color: #9D9BB8;
          margin-top: 38px;
          text-align: center;

        }
      }
    }
  }


@keyframes scroll-x {
  0% {
    transform: translate3d(0, 0, 0);
  }
  100% {
    transform: translate3d(-50%, 0, 0);
  }
}
</style>