<template>
  <div class="home-container">
    <img src="@/assets/images/logo.png" alt="" class="top-logo">
    <div class="tooltip-box">Precision Analytics, Expert-Driven <span>Alpha</span></div>
  </div>
</template>

<script setup>

</script>

<style lang="scss" scoped>
.home-container {
  width: 100%;
  height: 100%;
  background-color: #030219;

  .top-logo {
    width: 137px;
    height: 25px;
    margin: 0 auto;
    margin-top: 19px;
    display: block;
    margin-bottom: 81px;
  }

  .tooltip-box {
    background: linear-gradient(180deg, rgba(150, 136, 192, 0.1) 0%, rgba(255, 255, 255, 0.1) 100%);
    height: 27px;
    width: 259px;
    border-radius: 8px;
    font-family: Tomato Grotesk;
    font-weight: 400;
    font-size: 12px;
    line-height: 15px;
    letter-spacing: 0%;
    vertical-align: middle;
    text-transform: capitalize;
    display: flex;
    align-items: center;
    justify-content: center;
    border: 0.5px solid;

    border-image-source: linear-gradient(180deg, #2E2172 0%, #615793 100%);
    gap: 5px;
    margin: 0 auto;
    span {
      color: #886DFF;
    }
  }
}
</style>