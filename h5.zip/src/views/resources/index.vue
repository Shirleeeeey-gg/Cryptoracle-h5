<template> 
  <div class="insights-container">
    <Navbar />
    <div class="insights-content">
      <GitbookIframe src="https://cryptoracle.gitbook.io/cryptoracle-docs/open-api" />
    </div>
  </div>
</template>
<script setup>
import Navbar from '@/components/Navbar.vue'
import GitbookIframe from '@/components/GitbookIframe.vue'
</script>
<style scoped lang="scss">
.insights-container {
  width: 100%;
  height: 100vh;
  box-sizing: border-box;
  overflow: hidden;
  .insights-content {
    margin-top: 60px;
    width: 100%;
    height:calc(100vh - 60px);
    position: relative;
  }
}
</style>