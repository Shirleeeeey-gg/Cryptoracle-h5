<template>
  <div class="watchlist-container">
    <Navbar />
    <div class="watchlist-content">
      <div class="page-title">Watchlist</div>
      
      <!-- 有数据时显示表格 -->
      <div v-if="tokenData.length > 0" class="table-wrapper" ref="tableWrapper" >
        <el-table :data="tokenData" class="custom-table" @row-click="handleRowClick" @scroll="handleScroll">
          <!-- 最后一列收藏星标（无表头文字，只展示星星图标） -->
          <el-table-column label="" fixed="left" align="center" width="40" class-name="star-column">
            <template #default="scope">
              <div class="favorite-star-cell" @click.stop="handleCancelFavorite(scope.row)">
                <!-- 固定展示星星图标，大小 16x16 -->
                <img
                  class="favorite-star-icon"
                  src="@/assets/login/icon-star.svg"
                  alt="favorite"
                />
              </div>
            </template>
          </el-table-column>
          <el-table-column type="index" label="#" fixed="left" min-width="40" class-name="index-column" />

          <el-table-column label="Name" fixed="left" min-width="130" class-name="name-column">
            <template #default="scope">
              <div class="token-info">
                <div class="token-image">
                  <img :src="scope.row.imageUrl" :alt="scope.row.name" />
                </div>
                <div class="token-name-wrapper">
                  <div class="token-name">{{ scope.row.name }}</div>
                  <div class="token-symbol">{{ scope.row.coin }}</div>
                </div>
              </div>
            </template>
          </el-table-column>

          <el-table-column label="Buzz(24h)" align="center" min-width="100" class-name="buzz-column">
            <template #default="scope">
              <div class="mention-wrapper">
                <img class="kol-icon" v-if="scope.$index < 5" src="@/assets/icons/tokens/up-arrow.svg" alt="KOL" />
                <span>{{ $filters.heat(scope.row.heat) }}</span>
              </div>
            </template>
          </el-table-column>

          <el-table-column prop="community" label="Communities(24h)" min-width="130" align="center" class-name="community-column">
            <template #default="scope">
              {{ $filters.integer(scope.row.community) }}
            </template>
          </el-table-column>

          <el-table-column label="Trends(24h)" align="center" width="160" class-name="trends-column">
            <template #default="scope">
              <div class="sentiment-trend">
                <SentimentTrendChart
                  :data="scope.row.emotionalData ? JSON.parse(scope.row.emotionalData) : []"
                  :color="scope.row.emotional > 0 ? '#16C784' : '#EA3943'"
                />
              </div>
            </template>
          </el-table-column>

        </el-table>
        
        <!-- Load More Data 提示 -->
        <div v-if="!noMoreData && tokenData.length > 0 && type === 'coall'" class="slide-for-more">
          <span class="spinner" aria-hidden="true"></span>
          <div class="slide-text">Load More Data</div>
        </div>
      </div>
      
      <!-- 无数据时显示空状态 -->
      <div v-else class="section-card empty-card">
        <img
          class="empty-image"
          :src="iconNoFlowing"
          alt="No Following Token"
        />
        <p class="empty-text">No Following Token</p>
      </div>
    </div>
    
    <BottomNav @login="handleLogin" />
    <Login v-model:visible="loginVisible" @register="handleRegister" />
    <Register v-model:visible="registerVisible" />
  </div>
</template>

<script setup>
import { ref, onMounted, nextTick } from 'vue';
import SentimentTrendChart from '@/components/charts/SentimentTrendChart.vue';
import { useRouter } from 'vue-router'
import { useUserStore } from '@/store/user'
import { getCancelCollectApi, getUserCollectListApi } from '@/api/login'
import { ElMessage } from 'element-plus'
import Navbar from '@/components/Navbar.vue'
import BottomNav from '@/components/BottomNav.vue'
import Login from '@/components/Login/Login.vue'
import Register from '@/components/Login/Register.vue'
// 导入无数据状态图片
import iconNoFlowing from '@/assets/login/icon-no-flowing.png'

const loginVisible = ref(false)
const registerVisible = ref(false)

// 处理登录按钮点击
const handleLogin = () => {
  loginVisible.value = true
}

// 处理注册按钮点击
const handleRegister = () => {
  loginVisible.value = false
  registerVisible.value = true
}

const userStore = useUserStore()

const pageNum = ref(1)
const pageSize = ref(20)
const total = ref(0)
const current = ref(1)
const pages = ref(2)
const loading = ref(false)
const noMoreData = ref(false)
const tableWrapper = ref(null)

const router = useRouter()

const type = ref('coall')

const handleRowClick = (row) => {
  //找出点击的这行的index
  const index = tokenData.value.findIndex(item => item.id === row.id)
  router.push(`/project?id=${row.id}&coin=${row.coin}&rank=${index+1}`)
}

// 处理取消收藏操作
const handleCancelFavorite = async (row) => {
  try {
    // 调用取消收藏接口，传入userId和coin
    await getCancelCollectApi({
      userId: userStore.userId,
      coin: row.coin
    })
    // 接口调用成功后，重置页码为1并重新加载列表
    pageNum.value = 1
    // 重置noMoreData状态，确保可以重新加载数据
    noMoreData.value = false
    await getCO50TokenList()
    ElMessage.success('Removed from watchlist successfully')
  } catch (error) {
    // 接口调用失败时，提示错误
    console.error('取消收藏失败:', error)
    ElMessage.error('Could not remove. Please try again')
  }
}

const getCO50TokenList = async (isLoadMore = false) => {
  if (loading.value || noMoreData.value) return
  
  loading.value = true
  
  try {
    let res
    // 只有coall类型才传递分页参数
    if (type.value === 'coall') {
      res = await getUserCollectListApi({ pageNum: pageNum.value, pageSize: pageSize.value, userId: userStore.userId })
    } else {
      res = await getUserCollectListApi({ userId: userStore.userId })
    }
    if (res.code === 200) {
      let dataList = []
      
      // 根据API类型处理不同的数据结构
      if (type.value === 'coall') {
        // coall类型：res.data是包含分页信息的对象，数据在records中
        dataList = res.data.records || []
        total.value = res.data.total
        current.value = res.data.current
        pages.value = res.data.pages
        
        // 检查是否已经加载到最后一页
        if (current.value >= pages.value) {
          noMoreData.value = true
        }
      } else {
        // 其他类型：res.data直接是数组
        dataList = Array.isArray(res.data) ? res.data : []
        // 非coall类型，设置noMoreData为true，不显示加载更多
        noMoreData.value = true
      }
      
      if (isLoadMore) {
        // 追加数据
        tokenData.value = [...tokenData.value, ...dataList]
      } else {
        // 初始加载
        tokenData.value = dataList
      }
    }
  } catch (error) {
    console.error('加载数据失败:', error)
  } finally {
    loading.value = false
  }
}

// 滚动事件处理 - 由父组件触发
const loadNextPage = async () => {
  if (loading.value || noMoreData.value || type.value !== 'coall') return
  
  pageNum.value++
  await getCO50TokenList(true)
}

// 滚动事件处理
const handleScroll = async () => {
  return 
  if (loading.value || noMoreData.value) return
  
  const wrapper = tableWrapper.value
  if (!wrapper) return
  
  const { scrollTop, scrollHeight, clientHeight } = wrapper
  
  // 当滚动到距离底部50px时开始加载
  if (scrollTop + clientHeight >= scrollHeight - 50) {
    pageNum.value++
    await getCO50TokenList(true)
  }
}

onMounted(async () => {
  await getCO50TokenList()
})

// 模拟数据
const tokenData = ref([]);

// 导出方法供父组件调用
defineExpose({
  loadNextPage,
  loading,
  noMoreData
})
</script>

<style scoped>
.watchlist-container {
  min-height: 100vh;
  background-color: #030219;
  padding-bottom: 84px; /* BottomNav高度：60px min-height + 24px padding */
}

.watchlist-content {
  padding-top: 80px; /* 为顶部导航栏留出空间 */
  padding-left: 24px;
  padding-right: 24px;
  padding-bottom: 20px;
}

.page-title {
  font-family: Tomato Grotesk, Arial, sans-serif;
  font-weight: 600;
  font-size: 24px;
  color: #fff;
  margin-bottom: 24px;
}

:deep(.el-table tr){
  /* background-color: transparent; */
}
:deep(.el-table--fit .el-table__inner-wrapper:before){
  display:none!important;
}
/* 表体行边框样式 */
:deep(.el-table__body .el-table__row:not(:last-child)) {
  border-bottom: 1px solid rgba(50, 53, 70, 0.5);
}
:deep(.el-table td.el-table__cell, .el-table th.el-table__cell.is-leaf){
  border-bottom: 1px solid rgba(50, 53, 70, 0.5);
}
:deep(.el-table .cell){
  padding:0!important;
}
:deep(.el-pagination button){
  background:transparent!important;
  color:rgba(255,255,255,0.6)!important;
}
:deep(.el-pager li){
  background:transparent!important;
  color:rgba(255,255,255,0.6)!important;
  width:32px;
  height:32px;
  border-radius: 7px;
  margin:0 4px;
}
:deep(.el-pager li.is-active){
  background:#7644FB!important;
  color:#fff!important;
}
:deep(.el-table) {
  border: none !important;
  background: transparent !important;
}

:deep(.el-table__row) {
  border-radius: 8px !important;
  cursor: pointer;
}

:deep(.el-table__header-wrapper) {
  border-radius: 8px;
}

:deep(.el-table tr:last-child td.el-table__cell){
  border-bottom: none !important;
}

/* 表头样式 - 左侧列（#、Name、Buzz、Communities）深灰色背景 */
:deep(.el-table__header-wrapper th.index-column),
:deep(.el-table__header-wrapper th.name-column),
:deep(.el-table__header-wrapper th.buzz-column),
:deep(.el-table__header-wrapper th.community-column) {
  background-color: #1F1C33 !important;
}

/* 表头样式 - 右侧列（Trends、星星）稍浅灰色背景 */
:deep(.el-table__header-wrapper th.trends-column),
:deep(.el-table__header-wrapper th.star-column) {
  background-color: #27243D !important;
}

.table-wrapper{
  padding-bottom: 20px;
}



.loading-wrapper {
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 20px;
  background-color: #0B0527;
}

.loading-text {
  color: #9E9CB6;
  font-size: 14px;
  font-family: Tomato Grotesk, Arial, sans-serif;
}

.no-more-data {
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 20px;
  color: #9E9CB6;
  font-size: 14px;
  font-family: Tomato Grotesk, Arial, sans-serif;
  border-top: 1px solid rgba(50, 53, 70, 0.5);
}

/* 自定义Element Plus Table样式 */
:deep(.el-table) {
  background-color: transparent;
  border: none;
  border-radius: 0;
  overflow: visible;
}

:deep(.el-table__inner-wrapper) {
  border-radius: 0;
}

/* 表头样式 */
:deep(.el-table__header-wrapper th.el-table__cell) {
  color: #fff;
  font-family: Tomato Grotesk, Arial, sans-serif;
  font-weight: 500;
  font-size: 12px;
  padding: 0 8px;
  height:40px;
  border-bottom: none;
}

/* 表头行样式 */
:deep(.el-table__header-row) {
  height: 50px;
}

/* 表体单元格样式 */
:deep(.el-table__body .el-table__cell) {
  font-family: Tomato Grotesk, Arial, sans-serif;
  font-weight: 600;
  font-size: 14px;
  color: #fff;
  padding: 8px;
  background-color: #0A0818;
}

/* 表体行样式 */
:deep(.el-table__body .el-table__row) {
  height: 70px;
  background-color: #0A0818;
}

/* 表体行边框样式 */
:deep(.el-table__body .el-table__row:not(:last-child)) {
  border-bottom: 1px solid rgba(50, 53, 70, 0.5);
}
:deep(.el-table td.el-table__cell, .el-table th.el-table__cell.is-leaf){
  border-bottom: 1px solid rgba(50, 53, 70, 0.5);
}

/* 表体行悬停样式 */
:deep(.el-table__body .el-table__row:hover) {
  background-color: rgba(47, 43, 81, 0.3) !important;
}

:deep(.el-table__body tr:hover > td.el-table__cell) {
  background-color: rgba(47, 43, 81, 0.3) !important;
}

:deep(.el-table::before) {
  display: none;
}

.token-info {
  display: flex;
  align-items: center;
}

.token-image {
  flex-shrink: 0;
  width: 24px;
  height: 24px;
  border-radius: 50%;
  overflow: hidden;
  margin-right: 8px;
}

.token-image img {
  width: 100%;
  height: 100%;
  display: block;
  object-fit: cover;
}

.token-name-wrapper {
  display: flex;
  align-items: center;
}

.token-name {
  font-weight: 600;
  font-size: 14px;
  color: #fff;
  margin-right: 4px;
  line-height: 18px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  max-width: 120px;
}

.token-symbol {
  font-weight: 500;
  font-size: 12px;
  line-height: 14px;
  color: #9E9CB6;
}

.green-text {
  color: #16C784;
}

.red-text {
  color: #EA3943;
}

.mention-wrapper {
  display: flex;
  align-items: center;
  justify-content: center;
}

.kol-icon {
  width: 15px;
  height: 19px;
  margin-right: 2px;
}

.sentiment-trend {
  height: 36px;
  padding: 0 4px;
}

.favorite-star-cell {
  display: flex;
  align-items: center;
  justify-content: center;
}

/* 收藏星星图标大小固定为 16x16 */
.favorite-star-icon {
  width: 16px;
  height: 16px;
  cursor: pointer;
}

.slide-for-more {
  display: flex;
  justify-content: center;
  align-items: center;
  font-family: Tomato Grotesk, Arial, sans-serif;
  border-top: 1px solid rgba(50, 53, 70, 0.5);
  padding-top:20px;
}

.slide-text {
  margin-left: 16px;
  letter-spacing: 0.5px;
}

.slide-icon {
  width: 24px;
  height: 24px;
}

/* spinner */
.spinner {
  box-sizing: border-box;
  width: 26px;
  height: 26px;
  border: 4px solid rgba(255,255,255,0.25);
  border-top-color: #fff;
  border-radius: 50%;
  animation: spin 1s linear infinite;
}

@keyframes spin {
  to { transform: rotate(360deg); }
}

/* 无数据状态样式 */
.section-card {
  padding-bottom: 24px;
  padding-top: 12px;
  border-bottom: 1px solid #3A3655;
  margin-bottom: 20px;
}

.section-card:last-child {
  border-bottom: none;
}

.empty-card {
  text-align: center;
}

.empty-image {
  width: 120px;
  height: 120px;
  display: block;
  margin: 80px auto 16px; 
}

.empty-text {
  color: #7B73AE;
  font-size: 14px;
}
</style>
