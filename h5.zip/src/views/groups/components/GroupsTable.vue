<template>
  <div class="token-list-container">
    <!-- <div class="title">CO50 Token List</div> -->
    <el-table ref="tableRef" :data="tokenData" class="custom-table">
      <el-table-column type="index" align="center" label="#" min-width="40" />

      <el-table-column label="Name" min-width="90">
        <template #default="scope">
          <div class="token-info">
            <div class="token-name-wrapper">
              <div class="token-name">{{ $filters.tokenName(scope.row.name) }}</div>
            </div>
          </div>
        </template>
      </el-table-column>

      <el-table-column label="Members" align="center" min-width="100">
        <template #header>
          <div class="custom-header" @click="handleCustomSort('members')">
            <span>Members</span>
            <img :src="sortArrowIcon" class="sort-arrow" :class="{
              'sort-ascending': sortStates.members === 'ascending',
              'sort-descending': sortStates.members === 'descending',
              'sort-inactive': !sortStates.members
            }" />
          </div>
        </template>
        <template #default="scope">
          <div class="mention-wrapper">
            <span>{{ selectedFilter == 'Lark' ? '***' : $filters.members(scope.row.members) }}</span>
          </div>
        </template>
      </el-table-column>

      <el-table-column label="Rank" min-width="100" align="center">
        <template #header>
          <div class="custom-header" @click="handleCustomSort('rank')">
            <span>Rank</span>
            <img :src="sortArrowIcon" class="sort-arrow" :class="{
              'sort-ascending': sortStates.rank === 'ascending',
              'sort-descending': sortStates.rank === 'descending',
              'sort-inactive': !sortStates.rank
            }" />
          </div>
        </template>
        <template #default="scope">
          <div class="star-rating">
            <span v-for="n in 5" :key="n" class="star">
              <img :src="n <= scope.row.rank ? starWhite : starGray" class="star-icon" />
            </span>
          </div>
        </template>
      </el-table-column>

      <el-table-column prop="platform" label="Platform" min-width="100">
        <template #default="scope">
          <div class="platform-wrapper">
            <img v-if="scope.row.platform === 'Telegram'" src="@/assets/groups/icon-tg.png" class="platform-icon" />
            <img v-else-if="scope.row.platform === 'Discord'" src="@/assets/groups/icon-dc.png" class="platform-icon" />
            <img v-else-if="scope.row.platform === 'Twitter'" src="@/assets/groups/icon-x.png" class="platform-icon" />
            <img v-else-if="scope.row.platform === 'Lark'" src="@/assets/groups/icon-others.png" class="platform-icon" />
            <span>{{ scope.row.platform === 'Lark' ? 'Others' : scope.row.platform }}</span>
          </div>
        </template>
      </el-table-column>

      <el-table-column prop="tokenTag" label="Associated Currency" align="left" min-width="200">
        <template #default="scope">
          <div class="currency-tags">
            <span v-for="currency in scope.row.tokenTag" :key="currency" class="currency-tag"
              :class="getCurrencyClass(currency)">
              {{ currency }}
            </span>
          </div>
        </template>
      </el-table-column>

      <el-table-column prop="updateTime" label="Update Time" align="right" min-width="150">
        <template #header>
          <div class="custom-update-time-header">
            <span>Update Time</span>
          </div>
        </template>
        <template #default="scope">
          <span class="update-time">{{ scope.row.updateTime }}</span>
        </template>
      </el-table-column>


    </el-table>
  </div>
</template>

<script setup>
import { ref, watch } from 'vue';

import sortArrowIcon from '@/assets/groups/sort-arrow-top.svg'
import starGray from '@/assets/groups/star-gray.svg'
import starWhite from '@/assets/groups/star-white.svg'

const tableRef = ref(null) // 表格引用

// 多字段排序状态管理
const sortStates = ref({
  members: 'descending', // 默认降序
  rank: 'descending'     // 默认降序
})

// 新增排序顺序记录，用于跟踪点击的先后顺序
const sortOrder = ref(['members', 'rank']) // 记录字段点击的顺序，后点击的在前面

// 新增后端排序参数
const apiSortBy = ref('')  // 存储包含排序方向的字段字符串，如"members DESC,rank DESC"

const props = defineProps({
  selectedFilter: {
    type: String,
    default: 'all'
  },
  rank: {
    type: Number,
    default: 0
  },
  tokenData: {
    type: Array,
    default: () => []
  }
})

const emit = defineEmits(['sortChange', 'updateTotal'])

// 构建排序参数字符串
const buildSortParams = () => {
  const activeSorts = []
  
  // 按照sortOrder的顺序检查字段的排序状态，后点击的排在前面
  sortOrder.value.forEach(field => {
    if (sortStates.value[field]) {
      const order = sortStates.value[field] === 'ascending' ? 'ASC' : 'DESC'
      activeSorts.push(`${field} ${order}`)
    }
  })
  
  if (activeSorts.length === 0) {
    apiSortBy.value = ''
    return
  }
  
  apiSortBy.value = activeSorts.join(',')
}

const handleCustomSort = (columnProp) => {
  // 切换当前字段的排序状态
  const currentState = sortStates.value[columnProp]
  
  if (currentState === '') {
    // 无排序 -> 降序（修改为默认降序）
    sortStates.value[columnProp] = 'descending'
  } else if (currentState === 'descending') {
    // 降序 -> 升序
    sortStates.value[columnProp] = 'ascending'
  } else {
    // 升序 -> 无排序
    sortStates.value[columnProp] = ''
  }
  
  // 更新排序顺序：将当前点击的字段移到最前面
  if (sortStates.value[columnProp]) {
    // 如果字段有排序状态，将其移到数组最前面
    const newSortOrder = [columnProp, ...sortOrder.value.filter(field => field !== columnProp)]
    sortOrder.value = newSortOrder
  } else {
    // 如果字段没有排序状态，从数组中移除
    sortOrder.value = sortOrder.value.filter(field => field !== columnProp)
  }
  
  // 构建排序参数字符串
  buildSortParams()
  
  // 通知父组件排序已改变
  emit('sortChange', apiSortBy.value)
  
  console.log('排序状态:', sortStates.value)
  console.log('排序顺序:', sortOrder.value)
  console.log('后端排序参数 sortBy:', apiSortBy.value)
}

// 获取货币标签样式
const getCurrencyClass = (currency) => {
  const colors = [
    'currency-orange',
    'currency-purple',
    'currency-green',
    'currency-brown',
    'currency-default',
    'currency-pink'
  ]
  
  // 使用币种名称作为种子生成伪随机数，确保同一币种每次都得到相同颜色
  let hash = 0
  for (let i = 0; i < currency.length; i++) {
    const char = currency.charCodeAt(i)
    hash = ((hash << 5) - hash) + char
    hash = hash & hash // 转换为32位整数
  }
  
  const index = Math.abs(hash) % colors.length
  return colors[index]
}

// 监听 selectedFilter 和 rank 变化，重置排序状态
watch(() => [props.selectedFilter, props.rank], () => {
  // 重置排序状态为默认降序
  sortStates.value = {
    members: 'descending',
    rank: 'descending'
  }
  
  // 重置排序顺序为默认顺序
  sortOrder.value = ['members', 'rank']
  
  // 重新构建排序参数
  buildSortParams()
  
  // 通知父组件排序已改变
  emit('sortChange', apiSortBy.value)
})

// 初始化排序参数
buildSortParams()
emit('sortChange', apiSortBy.value)
</script>

<style scoped>
.custom-update-time-header{
  padding-right: 10px;
}
.update-time{
  padding-right: 10px;
}
:deep(.el-table--fit .el-table__inner-wrapper:before) {
  display: none !important;
}

/* 表体行边框样式 */
:deep(.el-table__body .el-table__row:not(:last-child)) {
  border-bottom: 0.5px solid rgba(50, 53, 70, 0.5);
}

:deep(.el-table td.el-table__cell, .el-table th.el-table__cell.is-leaf) {
  border-bottom: 0.5px solid rgba(50, 53, 70, 0.5);
}

:deep(.el-table .cell) {
  padding: 0 !important;
}

:deep(.el-pagination button) {
  background: transparent !important;
  color: rgba(255, 255, 255, 0.6) !important;
}

:deep(.el-pager li) {
  background: transparent !important;
  color: rgba(255, 255, 255, 0.6) !important;
  width: 16px;
  height: 16px;
  border-radius: 3.5px;
  margin: 0 2px;
}

:deep(.el-pager li.is-active) {
  background: #7644FB !important;
  color: #fff !important;
}

:deep(.el-table) {
  border: none !important;
  background: transparent !important;
}

:deep(.el-table__row) {
  background: transparent !important;
  border-radius: 49px !important;
  cursor: pointer;
}

:deep(.el-table__header-wrapper) {
  border-radius: 4px;
}

.token-list-container {
  box-sizing: border-box;
  padding: 0 16px;
}

.title {
  font-family: Tomato Grotesk, Arial, sans-serif;
  font-weight: 600;
  font-size: 9px;
  padding-top: 15px;
  color: #fff;
  margin-bottom: 12.5px;
}

/* 自定义Element Plus Table样式 */
:deep(.el-table) {
  background-color: #0B0527;
  border: 0.5px solid #323546;
  border-radius: 6px;
  overflow: hidden;
}

:deep(.el-table__inner-wrapper) {
  border-radius: 6px;
}

/* 表头样式 */
:deep(.el-table__header-wrapper th.el-table__cell) {
  background-color: #27243D !important;
  color: #fff;
  font-family: Tomato Grotesk, Arial, sans-serif;
  font-weight: 500;
  font-size: 10px;
  padding: 8px 4px;
  border-bottom: none;
}

/* 表头行样式 */
:deep(.el-table__header-row) {
  height: 25px;
}

/* 表体单元格样式 */
:deep(.el-table__body .el-table__cell) {
  font-family: Tomato Grotesk, Arial, sans-serif;
  font-weight: 600;
  font-size: 11px;
  color: #fff;
  padding: 4px;
  background-color: transparent;
  border-bottom: none;
}

/* 表体行样式 */
:deep(.el-table__body .el-table__row) {
  height: 40px;
  background-color: #0B0527;
}

/* 表体行边框样式 */
:deep(.el-table__body .el-table__row:not(:last-child)) {
  border-bottom: 0.5px solid rgba(50, 53, 70, 0.5);
}

/* 表体行悬停样式 */
:deep(.el-table__body .el-table__row:hover) {
  background-color: #2F2B51 !important;
}

:deep(.el-table__body tr:hover > td.el-table__cell) {
  background-color: #2F2B51 !important;
}

:deep(.el-table__body tr:hover > td.el-table__cell:first-child) {
  border-top-left-radius: 4px;
  border-bottom-left-radius: 4px;
}

:deep(.el-table__body tr:hover > td.el-table__cell:last-child) {
  border-top-right-radius: 4px;
  border-bottom-right-radius: 4px;
}

/* 悬浮时货币标签透明度变为1 */
:deep(.el-table__body tr:hover .currency-tag.currency-orange) {
  background-color: rgba(71, 41, 151, 1);
}

:deep(.el-table__body tr:hover .currency-tag.currency-purple) {
  background-color: rgba(137, 85, 20, 1);
}

:deep(.el-table__body tr:hover .currency-tag.currency-green) {
  background-color: rgba(13, 119, 79, 1);
}

:deep(.el-table__body tr:hover .currency-tag.currency-brown) {
  background-color: rgba(72, 128, 153, 1);
}

:deep(.el-table__body tr:hover .currency-tag.currency-default) {
  background-color: rgba(37, 83, 153, 1);
}

:deep(.el-table__body tr:hover .currency-tag.currency-pink) {
  background-color: rgba(153, 75, 131, 1);
}

:deep(.el-table::before) {
  display: none;
}

.token-info {
  display: flex;
  align-items: center;
}


.token-name-wrapper {
  display: flex;
  align-items: center;
}

.token-name {
  font-weight: 600;
  font-size: 11px;
  color: #fff;
  margin-right: 2px;
}

.token-symbol {
  font-weight: 500;
  font-size: 11px;
  line-height: 7px;
  color: #9E9CB6;
}

.green-text {
  color: #16C784;
}

.red-text {
  color: #EA3943;
}

.mention-wrapper {
  display: flex;
  align-items: center;
  justify-content: center;
}

.kol-icon {
  width: 7.5px;
  height: 9.5px;
  margin-right: 1px;
}

.sentiment-trend {
  height: 18px;
  padding: 0 2px;
}

.pagination-wrapper {
  padding: 14px 0;
  display: flex;
  justify-content: center;
}

/* 自定义排序按钮样式 */
.custom-header {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 4px;
  cursor: pointer;
  user-select: none;
}

.sort-arrow {
  width: 6px;
  transition: all 0.3s ease;
}

.sort-arrow.sort-ascending {
  transform: rotate(0deg);
  opacity: 1;
}

.sort-arrow.sort-descending {
  transform: rotate(180deg);
  opacity: 1;
}

.sort-arrow.sort-inactive {
  opacity: 0.3;
}

.custom-header:hover .sort-arrow.sort-inactive {
  opacity: 0.6;
}

/* 星级评分样式 */
.star-rating {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 1px;
}

.star .star-icon {
  width: 11px;
  height: 11px;
}

/* 平台样式 */
.platform-wrapper {
  display: flex;
  align-items: center;
  justify-content: flex-start;
  gap: 4px;
}

.platform-icon {
  width: 12px;
  height: 12px;
  border-radius: 50%;
  overflow: hidden;
}

/* 货币标签样式 */
.currency-tags {
  display: flex;
  align-items: center;
  justify-content: flex-start;
  gap: 4px;
  flex-wrap: wrap;
}

.currency-tag {
  padding: 3px 8px;
  border-radius: 6px;
  font-size: 10px;
  color: #fff;
  font-family: Tomato Grotesk;
  font-weight: 600;
  letter-spacing: 0%;
  vertical-align: middle;

}

.currency-orange {
  background-color: rgba(71, 41, 151, 0.6);
}

.currency-purple {
  background-color: rgba(137, 85, 20, 0.6);
}

.currency-green {
  background-color: rgba(13, 119, 79, 0.6);
}

.currency-brown {
  background-color: rgba(72, 128, 153, 0.6);
}

.currency-default {
  background-color: rgba(37, 83, 153, 0.6);
}
.currency-pink{
  background-color: rgba(153, 75, 131, 0.6);
}


</style>