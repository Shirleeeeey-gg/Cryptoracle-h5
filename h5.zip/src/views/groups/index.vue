<template>
  <div class="groups-container">
    <div class="page-title">
      Multi-platform Data Intelligence
    </div>
    <div class="channel-box">
      <div class="channel-item">
        <div class="channel-content">
          <div class="logo-box">
            <img src="@/assets/groups/icon-tg.png" alt="">
            <span>Telegram</span>
          </div>
          <div class="value">{{ $filters.integer(groupsData?.tgCount) }}</div>
        </div>
      </div>
      <div class="channel-item">
        <div class="channel-content">
          <div class="logo-box">
            <img src="@/assets/groups/icon-dc.png" alt="">
            <span>Discord</span>
          </div>
          <div class="value">{{ $filters.integer(groupsData?.dcCount) }}</div>
        </div>
      </div>
      <div class="channel-item">
        <div class="channel-content">
          <div class="logo-box">
            <img src="@/assets/groups/icon-x.png" alt="">
            <span>X（Twitter）</span>
          </div>
          <div class="value">{{ $filters.integer(groupsData?.xCount) }}</div>
        </div>
      </div>
      <div class="channel-item">
        <div class="channel-content">
          <div class="logo-box">
            <img src="@/assets/groups/icon-others.png" alt="">
            <span>Others</span>
          </div>
          <div class="value">{{ $filters.integer(groupsData?.larkCount) }}</div>
        </div>
      </div>
    </div>

    <!-- 图表区域 -->
    <div class="chart-box">
      <div class="filter-box">
        <div class="filter-item" :class="{ active: selectedFilter === 'all' }" @click="selectFilter('all')">
          <span>All Community</span>
        </div>
        <div class="filter-item" :class="{ active: selectedFilter === 'Telegram' }" @click="selectFilter('Telegram')">
          <img class="icon" src="@/assets/groups/icon-tg.png" alt="">
          <span>Telegram</span>
        </div>
        <div class="filter-item" :class="{ active: selectedFilter === 'Discord' }" @click="selectFilter('Discord')">
          <img class="icon" src="@/assets/groups/icon-dc.png" alt="">
          <span>Discord</span>
        </div>
        <div class="filter-item" :class="{ active: selectedFilter === 'Twitter' }" @click="selectFilter('Twitter')">
          <img class="icon" src="@/assets/groups/icon-x.png" alt="">
          <span>X(Twitter)</span>
        </div>
        <div class="filter-item" :class="{ active: selectedFilter === 'Lark' }" @click="selectFilter('Lark')">
          <img class="icon" src="@/assets/groups/icon-others.png" alt="">
          <span>Others</span>
        </div>
      </div>
      <div class="star-filter-box">
        <div class="star-box">
          <div class="all-btn" :class="{ active: selectedStar === 0 }" @click="selectStar(0)">
            <img :src="selectedStar === 0 ? starWhite : starGray" class="star-icon" />
            <span>All</span>
          </div>
          <div class="star-items">
            <div v-for="n in 5" :key="n" class="star-group" 
              :class="{ active: selectedStar === n }"
              @click="selectStar(n)"
              @mouseenter="hoverStar = n"
              @mouseleave="hoverStar = 0">
              <span v-for="starIndex in n" :key="starIndex" class="star-item">
                <img :src="(hoverStar === n || selectedStar === n) ? starWhite : starGray" class="star-icon" />
              </span>
            </div>
          </div>
        </div>
        <!-- <div class="total-box">
          <span>Total:</span>
          <span>{{ $filters.integer(totalCount) }}</span>
        </div> -->
      </div>
      <GroupsTable 
        :selectedFilter="selectedFilter" 
        :rank="selectedStar" 
        :tokenData="tokenData"
        @sortChange="handleSortChange"
        @updateTotal="totalCount = $event" 
      />
      
      <!-- 加载更多指示器 -->
      <div v-if="loading && tokenData.length > 0" class="loading-indicator">
        <div class="loading-text">loading...</div>
      </div>
      
      <!-- 数据加载完成提示 -->
      <!-- <div v-else-if="tokenData.length > 0 && tokenData.length >= totalCount" class="no-more-data">
        <div class="no-more-text">All data loaded</div>
      </div> -->
    </div>
    <Footer />
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted, watch } from 'vue'
import starGray from '@/assets/groups/star-gray.svg'
import starWhite from '@/assets/groups/star-white.svg'
import GroupsTable from './components/GroupsTable.vue'
import { getGroupDataApi, getGroupTableDataApi } from '@/api/groups'
import Footer from '@/components/Footer.vue'
import dayjs from 'dayjs'

// 社群数据
const groupsData = ref({
  tgCount: 0,
  dcCount: 0,
  xCount: 0,
  larkCount: 0
})

// 表格数据相关状态
const tokenData = ref([])
const pageNum = ref(1)
const pageSize = ref(20)
const totalCount = ref(0)
const loading = ref(false)
const currentSortBy = ref('')

const selectedStar = ref(0)
const hoverStar = ref(0)
const selectedFilter = ref('all')

function selectStar(n) {
  selectedStar.value = n
}

function selectFilter(filter) {
  selectedFilter.value = filter
}

// 处理排序变化
const handleSortChange = (sortBy) => {
  currentSortBy.value = sortBy
  // 排序改变时重置分页
  pageNum.value = 1
  tokenData.value = []
  // 重新加载数据
  loadTableData()
}

// 加载表格数据
const loadTableData = async (isLoadMore = false) => {
  if (loading.value) return
  
  loading.value = true
  
  try {
    const params = { 
      pageNum: pageNum.value, 
      pageSize: pageSize.value, 
      platform: selectedFilter.value,
      rank: selectedStar.value
    }
    
    if(selectedStar.value == 0){
      delete params.rank
    }

    if(selectedFilter.value === 'all'){
      params.platform = ''
    }
    
    // 添加排序参数，只有当有值时才添加
    if (currentSortBy.value) {
      params.sortBy = currentSortBy.value
    }
    
    const res = await getGroupTableDataApi(params)
    if (res.code === 200) {
      const newData = res.data.list.map(item => {
        return {
          ...item,
          tokenTag: item.tokenTag ? item.tokenTag.split(',') : [],
          updateTime: dayjs().subtract(1, 'day').format('YYYY-MM-DD')
        }
      });
      
      if (isLoadMore) {
        // 加载更多时追加数据
        tokenData.value = [...tokenData.value, ...newData]
      } else {
        // 重新加载时替换数据
        tokenData.value = newData
      }
      
      totalCount.value = res.data.total
    }
  } catch (error) {
    console.error('加载数据失败:', error)
    // 如果请求失败，回退页码
    if (isLoadMore) {
      pageNum.value -= 1
    }
  } finally {
    loading.value = false
  }
}

// 加载更多数据
const loadMoreData = async () => {
  // 检查是否还有更多数据
  if (tokenData.value.length >= totalCount.value) {
    return
  }
  
  pageNum.value += 1
  await loadTableData(true)
}

// 页面滚动监听
const handlePageScroll = () => {
  const { scrollTop, scrollHeight, clientHeight } = document.documentElement
  
  // 检测是否滚动到底部（留出50px的缓冲区）
  if (scrollTop + clientHeight >= scrollHeight - 100 && !loading.value) {
    loadMoreData()
  }
}

// 监听 selectedFilter 变化
watch(() => selectedFilter.value, (newVal, oldVal) => {
  if (newVal !== oldVal) {
    pageNum.value = 1
    tokenData.value = []
    loadTableData()
  }
})

// 监听 selectedStar 变化
watch(() => selectedStar.value, (newVal, oldVal) => {
  if (newVal !== oldVal) {
    pageNum.value = 1
    tokenData.value = []
    loadTableData()
  }
})

onMounted(() => {
  // 加载群组统计数据
  getGroupDataApi().then(res => {
    groupsData.value = res.data
  })
  
  // 加载表格数据
  loadTableData()
  
  // 添加页面滚动监听
  window.addEventListener('scroll', handlePageScroll)
})

onUnmounted(() => {
  // 移除页面滚动监听
  window.removeEventListener('scroll', handlePageScroll)
})
</script>

<style lang="scss" scoped>
.groups-container {
  width: 100%;
  min-height: 100vh;
  box-sizing: border-box;
  background: url('@/assets/groups/groups-bg.png') no-repeat left top;
  background-size: 375px 245px;
  padding-top: 91px;

  .page-title {
    font-family: Tomato Grotesk;
    font-weight: 400;
    font-style: Regular;
    font-size: 23px;
    line-height: 100%;
    letter-spacing: 0%;
    color: #fff;
    padding: 0 16px;
    margin-bottom: 26px;
  }

  .channel-box {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    padding: 0 16px;
    gap: 8px;

    .channel-item {
      width: 167.5px;
      height: 80px;
      background: url('@/assets/groups/bg-tg.png') no-repeat center center #1C1833;
      background-size: 100% 100%;
      border-radius: 10px;
      box-sizing: border-box;
      padding: 12px;

      &:nth-child(2) {
        background: url('@/assets/groups/bg-dc.png') no-repeat center center #1C1833;
        background-size: 100% 100%;
      }

      &:nth-child(3) {
        background: url('@/assets/groups/bg-x.png') no-repeat center center #1C1833;
        background-size: 100% 100%;
      }

      &:nth-child(4) {
        background: url('@/assets/groups/bg-others.png') no-repeat center center #1C1833;
        background-size: 100% 100%;
      }

      .channel-content {
        .logo-box {
          display: flex;
          align-items: center;
          gap: 5.5px;
          margin-bottom: 12px;

          img {
            width: 18px;
            height: 18px;
          }

          span {
            font-family: Tomato Grotesk;
            font-weight: 500;
            font-style: Medium;
            font-size: 12px;
            line-height: 12px;
            letter-spacing: 0%;
            color: #fff;
          }
        }

        .value {
          font-family: Tomato Grotesk;
          font-weight: 500;
          font-style: Medium;
          font-size: 22px;
          line-height: 22px;
          letter-spacing: 0%;
          vertical-align: middle;
          color: #fff;
        }
      }
    }
  }

  .chart-box {
    box-sizing: border-box;
    margin-top: 30px;
    .filter-box {
      display: flex;
      align-items: center;
      border-bottom: 0.5px solid #2F2F44;
      overflow-x: auto;
      padding-bottom: 1px;
      margin-left: 16px;
      margin-right: 16px;
      
      /* 隐藏滚动条 */
      scrollbar-width: none; /* Firefox */
      -ms-overflow-style: none; /* IE and Edge */
      
      &::-webkit-scrollbar {
        display: none; /* Chrome, Safari, Opera */
      }
      
      .filter-item {
        display: flex;
        align-items: center;
        gap: 4px;
        padding: 0 12px;
        cursor: pointer;
        box-sizing: border-box;
        height: 30px;
        border-bottom: 1px solid transparent;
        white-space: nowrap;
        flex-shrink: 0;

        &:hover,&.active{
          border-bottom: 1px solid #fff;
          span{
            color: #fff;
          }
          img{
            opacity: 1;
          }
        }

        img {
          width: 12px;
          height: 12px;
          border-radius: 50%;
          opacity: 0.6;
        }

        span {
          font-family: Tomato Grotesk;
          font-weight: 500;
          font-size: 14px;
          line-height: 15px;
          letter-spacing: 0%;
          vertical-align: middle;
          color: rgba(255, 255, 255, 0.6);
        }
      }
    }

    .star-filter-box {
      display: flex;
      align-items: center;
      justify-content: space-between;
      height: 32px;
      margin-top: 12px;
      margin-bottom: 20px;
      padding: 0 16px;
      
      .star-box {
        display: flex;
        align-items: center;
        background: #302D4A;
        border-radius: 6px;
        padding: 4px;
        gap: 9px;
        width: 100%;
        .all-btn {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 4px;
          padding: 4px 8px;
          border-radius: 4px;
          background: transparent;
          cursor: pointer;
          color: rgba(255, 255, 255, 0.6);
          font-size: 12px;
          font-family: Tomato Grotesk;
          font-weight: 500;

          &.active {
            background: #17152A;
            color: #fff;
          }

          .star-icon {
            width: 10px;
            height: 10px;
          }

          span {
            color: inherit;
          }
        }

        .star-items {
          display: flex;
          align-items: center;
          justify-content: space-between;
          width: 100%;
          .star-group {
            display: flex;
            align-items: center;
            padding: 4px 8px;
            border-radius: 4px;
            cursor: pointer;
            background: transparent;
            transition: background-color 0.2s;

            &:hover,
            &.active {
              background: #17152A;
            }

            .star-item {
              margin-right: 1px;

              &:last-child {
                margin-right: 0;
              }

              .star-icon {
                width: 10px;
                height: 10px;
                transition: filter 0.2s;
              }
            }
          }
        }
      }

      .total-box {
        display: flex;
        align-items: center;
        gap: 4px;
        font-family: Tomato Grotesk;
        font-weight: 500;
        font-size: 12px;
        line-height: 15px;
        letter-spacing: 0%;
        text-align: right;
        vertical-align: middle;
        color: #9E9CB6;
      }
    }
  }
}

/* 加载指示器样式 */
.loading-indicator {
  padding: 10px;
  text-align: center;
}

.loading-text {
  color: rgba(255, 255, 255, 0.6);
  font-size: 7px;
  font-family: Tomato Grotesk, Arial, sans-serif;
}

/* 无更多数据提示样式 */
.no-more-data {
  padding: 10px;
  text-align: center;
}

.no-more-text {
  color: rgba(255, 255, 255, 0.4);
  font-size: 7px;
  font-family: Tomato Grotesk, Arial, sans-serif;
}
</style>