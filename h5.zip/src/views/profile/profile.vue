<template>
  <div class="profile-container">
    <Navbar />

    <!-- Profile 内容区域 -->
    <div class="profile-content">
      <h1 class="page-title">Profile</h1>

      <!-- About me 区块 -->
      <div class="section-card">
        <h2 class="section-title">About me</h2>
        
        <!-- 用户名字段 -->
        <div class="field">
          <label class="field-label">Username</label>
          <div class="username-input-wrapper">
            <input
              v-model="username"
              class="text-input"
              placeholder="Enter your username"
              maxlength="20"
            />
            <span class="char-count">{{ username.length }}/20</span>
          </div>
          <p class="field-hint">* Username can only be changed once per 7 days</p>
          <div class="field-actions-inline">
            <button class="primary-btn" @click="saveUsername">Save</button>
          </div>
        </div>

        <!-- 联系信息字段 -->
        <div class="field">
          <label class="field-label">Contact Information</label>
          <div
            class="contact-container"
            :class="{
              'has-focus': contactFocused || isContactOpen,
            }"
          >
            <input
              v-model="contactValue"
              class="contact-input"
              :placeholder="contactPlaceholder"
              @focus="contactFocused = true"
              @blur="contactFocused = false"
            />
            <div
              class="contact-select"
              @click="toggleContactDropdown"
            >
              <img
                v-if="currentContact?.icon"
                :src="currentContact.icon"
                alt=""
                class="contact-icon"
              />
              <span class="contact-label">{{ currentContact?.label }}</span>
              <span class="arrow" />
            </div>
          </div>
        </div>

        <div class="field-actions">
          <button class="primary-btn" @click="saveAboutMe">Save</button>
        </div>
      </div>

      <!-- Social Accounts 区块 -->
      <div class="section-card">
        <div class="section-header">
          <h2 class="section-title">Social Accounts</h2>
        </div>

        <!-- 社交账号行 -->
        <div
          v-for="item in socialAccounts"
          :key="item.key"
          class="social-row"
        >
          <div class="social-left">
            <img :src="item.icon" :alt="item.label" class="social-icon" />
            <span class="social-label">{{ item.label }}</span>
          </div>
          <div class="social-input-wrapper">
            <input
              v-model="item.value"
              class="social-input"
              :placeholder="item.placeholder"
            />
            <button
              type="button"
              class="copy-btn"
              @click="copyToClipboard(item.value)"
            >
              <img :src="iconCopy" alt="" class="copy-icon" />
            </button>
          </div>
        </div>

        <div class="field-actions">
          <button class="primary-btn" @click="saveSocialAccounts">Save</button>
        </div>
      </div>

      <!-- Password 区块 -->
      <div class="section-card password-card" v-if="userStore.loginType == 1">
        <div class="section-header">
          <h2 class="section-title">Password</h2>
        </div>
        <div class="password-content">
          <p class="password-desc">
            If you want to change your password, please click the button below.
          </p>
          <button class="secondary-btn" @click="openChangePasswordModal">
            Change Password
          </button>
        </div>
      </div>
    </div>

    <!-- Change Password 弹框 -->
    <Transition name="change-pass-modal-fade">
      <div
        v-if="showChangePasswordModal"
        class="change-pass-modal-overlay"
        @click.self="closeChangePasswordModal"
      >
        <div class="change-pass-modal" @click.stop>
          <!-- 拖拽把手 -->
          <div class="change-pass-handle"></div>
          
          <div class="change-pass-header">
            <h2 class="change-pass-title">Change Password</h2>
          </div>

          <!-- 弹框说明 -->
          <p class="change-pass-desc">
            Please enter your old password, then enter the new password you wish to
            create.
          </p>

          <!-- 修改密码表单 -->
          <div class="change-pass-form">
            <!-- 当前密码 -->
            <div class="form-group">
              <label class="form-label">Current password</label>
              <div class="password-input-wrapper">
                <input
                  v-model="passwordForm.currentPassword"
                  :type="showCurrentPassword ? 'text' : 'password'"
                  class="form-input password-input"
                  placeholder="Enter your current password"
                  required
                />
                <button
                  type="button"
                  class="password-toggle-btn"
                  @click="showCurrentPassword = !showCurrentPassword"
                >
                  <img
                    :src="showCurrentPassword ? iconEye : iconEyeClose"
                    alt="Toggle password visibility"
                  />
                </button>
              </div>
            </div>

            <!-- 新密码 -->
            <div class="form-group">
              <label class="form-label">New password</label>
              <div class="password-input-wrapper">
                <input
                  v-model="passwordForm.newPassword"
                  :type="showNewPassword ? 'text' : 'password'"
                  :class="[
                    'form-input',
                    'password-input',
                    { 'form-input-error': newPasswordError },
                  ]"
                  placeholder="Enter your new password..."
                  required
                  @blur="validateNewPassword"
                  @input="checkPasswordRules"
                />
                <button
                  type="button"
                  class="password-toggle-btn"
                  @click="showNewPassword = !showNewPassword"
                >
                  <img
                    :src="showNewPassword ? iconEye : iconEyeClose"
                    alt="Toggle password visibility"
                  />
                </button>
              </div>
              <!-- 密码验证规则提示 -->
              <div v-if="showLengthRule || showFormatRule" class="password-rules">
                <div v-if="showLengthRule" class="password-rule-item">- Use 8-20 characters.</div>
                <div v-if="showFormatRule" class="password-rule-item">- Include both letters and numbers.</div>
              </div>
              <!-- 错误提示信息 -->
              <div v-if="newPasswordError" class="error-message">
                {{ newPasswordErrorText }}
              </div>
            </div>

            <!-- 确认新密码 -->
            <div class="form-group">
              <label class="form-label">Confirm new password</label>
              <div class="password-input-wrapper">
                <input
                  v-model="passwordForm.confirmPassword"
                  :type="showConfirmPassword ? 'text' : 'password'"
                  :class="[
                    'form-input',
                    'password-input',
                    { 'form-input-error': confirmPasswordError },
                  ]"
                  placeholder="Repeat your new password..."
                  required
                  @blur="validateConfirmPassword"
                  @input="handleConfirmPasswordInput"
                />
                <button
                  type="button"
                  class="password-toggle-btn"
                  @click="showConfirmPassword = !showConfirmPassword"
                >
                  <img
                    :src="showConfirmPassword ? iconEye : iconEyeClose"
                    alt="Toggle password visibility"
                  />
                </button>
              </div>
              <div v-if="confirmPasswordError" class="error-message">
                {{ confirmPasswordErrorText }}
              </div>
            </div>

            <!-- 提示文字 -->
            <p class="help-text">
              * You will be logged out from all devices on password change.
            </p>

            <!-- 保存按钮 -->
            <button
              type="button"
              class="save-pass-btn"
              @click="handleSaveNewPassword"
            >
              Save new password
            </button>
          </div>
        </div>
      </div>
    </Transition>

    <!-- Contact Information 底部弹出选择框 -->
    <Transition name="bottom-sheet-fade">
      <div
        v-if="isContactOpen"
        class="bottom-sheet-overlay"
        @click.self="closeContactDropdown"
      >
        <div class="bottom-sheet" @click.stop>
          <!-- 拖拽把手 -->
          <div class="bottom-sheet-handle"></div>
          
          <!-- 选项列表 -->
          <div class="bottom-sheet-content">
            <div
              v-for="option in contactOptions"
              :key="option.label"
              class="bottom-sheet-item"
              :class="{ active: contactMethod === option.label }"
              @click="selectContact(option.label)"
            >
              <img :src="option.icon" alt="" class="bottom-sheet-icon" />
              <span class="bottom-sheet-label">{{ option.label }}</span>
              <svg
                v-if="contactMethod === option.label"
                class="check-icon"
                width="20"
                height="20"
                viewBox="0 0 20 20"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M16.6667 5L7.50004 14.1667L3.33337 10"
                  stroke="currentColor"
                  stroke-width="2"
                  stroke-linecap="round"
                  stroke-linejoin="round"
                />
              </svg>
            </div>
          </div>
        </div>
      </div>
    </Transition>

    <!-- 滚动到顶部按钮 -->
    <button v-if="showScrollTop" class="scroll-top-btn" @click="scrollToTop">
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M12 19V5M12 5L5 12M12 5L19 12" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>
    </button>

  </div>
</template>

<script setup>
import { computed, ref, onMounted, onUnmounted } from 'vue';
import { useRouter } from 'vue-router';
import Navbar from '@/components/Navbar.vue';
import { getProfileApi, saveProfileApi, changePasswordApi, logoutApi } from '@/api/login';
import { ElMessage } from 'element-plus';
import { sha256 } from '@/utils/encrypto';
import { useUserStore } from '@/store/user';

// 联系方式图标
import iconPhone from '@/assets/login/icon-phone.svg';
import iconTg from '@/assets/login/icon-tg.svg';

// 社交账号图标
import iconX from '@/assets/login/icon-x.svg';
import iconTgSocial from '@/assets/login/icon-tg.svg';
import iconYoutube from '@/assets/login/icon-youtube.svg';
import iconDc from '@/assets/login/icon-dc.svg';
import iconCopy from '@/assets/login/icon-copy.svg';

// 密码输入框右侧显示/隐藏图标
import iconEye from '@/assets/login/icon-eye.svg';
import iconEyeClose from '@/assets/login/icon-eye-close.svg';

const userStore = useUserStore();
const router = useRouter();

// About me - 用户名
const username = ref('');

// Contact 信息
const contactOptions = [
  { label: 'Telephone', icon: iconPhone },
  { label: 'Telegram', icon: iconTg },
];

const contactMethod = ref('Telegram');
const contactValue = ref('');
const isContactOpen = ref(false);
const contactFocused = ref(false);

// 保存接口返回的原始数据，用于切换联系方式时回显
const profileDataCache = ref(null);

// 根据选择的联系方式动态展示 placeholder
const contactPlaceholder = computed(() => {
  if (contactMethod.value === 'Telephone') {
    return 'Enter phone number...';
  }
  return 'Enter Telegram username...';
});

// 当前下拉选中的联系方式对象
const currentContact = computed(() =>
  contactOptions.find((item) => item.label === contactMethod.value),
);

// 切换联系方式下拉
function toggleContactDropdown() {
  isContactOpen.value = !isContactOpen.value;
}

// 关闭联系方式下拉
function closeContactDropdown() {
  isContactOpen.value = false;
}

// 选择联系方式
function selectContact(label) {
  contactMethod.value = label;
  isContactOpen.value = false;
  
  // 切换联系方式时，根据选中的方式从接口数据中获取对应的值进行回显
  if (profileDataCache.value) {
    if (label === 'Telephone') {
      contactValue.value = profileDataCache.value.telephone || '';
    } else if (label === 'Telegram') {
      contactValue.value = profileDataCache.value.telegramOne || '';
    }
  }
}

// Social Accounts 列表
const socialAccounts = ref([
  {
    key: 'x',
    label: 'X (Twitter)',
    icon: iconX,
    placeholder: 'https://x.com/',
    value: '',
  },
  {
    key: 'telegram',
    label: 'Telegram',
    icon: iconTgSocial,
    placeholder: 'https://telegram.com/',
    value: '',
  },
  {
    key: 'youtube',
    label: 'YouTube',
    icon: iconYoutube,
    placeholder: 'https://youtube.com/',
    value: '',
  },
  {
    key: 'discord',
    label: 'Discord',
    icon: iconDc,
    placeholder: 'https://Discord.com/',
    value: '',
  },
]);

// 复制到剪贴板
async function copyToClipboard(text) {
  if (!text) return;
  try {
    await navigator.clipboard.writeText(text);
    ElMessage.success('Copied to clipboard');
  } catch (e) {
    console.error('Copy failed', e);
    ElMessage.error('Copy failed');
  }
}

// ---------------- Password 修改密码弹框相关逻辑 ----------------

// 是否显示"Change Password"弹框
const showChangePasswordModal = ref(false);

// 修改密码表单数据
const passwordForm = ref({
  currentPassword: '',
  newPassword: '',
  confirmPassword: '',
});

// 密码显示 / 隐藏控制
const showCurrentPassword = ref(false);
const showNewPassword = ref(false);
const showConfirmPassword = ref(false);

// 校验错误状态
const newPasswordError = ref(false);
const confirmPasswordError = ref(false);

// 错误提示文案
const newPasswordErrorText = ref('');
const confirmPasswordErrorText = ref('');

// 密码规则提示显示状态
const showLengthRule = ref(false);
const showFormatRule = ref(false);

// 打开修改密码弹框
const openChangePasswordModal = () => {
  showChangePasswordModal.value = true;
};

// 关闭修改密码弹框，并重置表单
const closeChangePasswordModal = () => {
  showChangePasswordModal.value = false;
  passwordForm.value = {
    currentPassword: '',
    newPassword: '',
    confirmPassword: '',
  };
  newPasswordError.value = false;
  newPasswordErrorText.value = '';
  confirmPasswordError.value = false;
  confirmPasswordErrorText.value = '';
  showLengthRule.value = false;
  showFormatRule.value = false;
};

// 实时检查密码规则（在用户输入时触发）
const checkPasswordRules = () => {
  const password = passwordForm.value.newPassword;
  
  if (!password || password.trim() === '') {
    showLengthRule.value = false;
    showFormatRule.value = false;
    if (newPasswordError.value) {
      newPasswordError.value = false;
      newPasswordErrorText.value = '';
    }
    return;
  }
  
  const lengthValid = password.length >= 8 && password.length <= 20;
  showLengthRule.value = !lengthValid;
  
  const hasNumber = /\d/.test(password);
  const hasLetter = /[a-zA-Z]/.test(password);
  showFormatRule.value = !(hasNumber && hasLetter);
  
  if (newPasswordError.value) {
    newPasswordError.value = false;
    newPasswordErrorText.value = '';
  }
  
  if (passwordForm.value.confirmPassword.trim() !== '') {
    validateConfirmPassword();
  }
};

// 确认密码输入时的处理：清除错误
const handleConfirmPasswordInput = () => {
  if (confirmPasswordError.value) {
    confirmPasswordError.value = false;
    confirmPasswordErrorText.value = '';
  }
};

// 校验新密码复杂度
const validateNewPassword = () => {
  const password = passwordForm.value.newPassword.trim();

  checkPasswordRules();

  if (password === '') {
    newPasswordError.value = false;
    newPasswordErrorText.value = '';
    return;
  }

  const hasNumber = /\d/.test(password);
  const hasLetter = /[a-zA-Z]/.test(password);
  const lengthValid = password.length >= 8 && password.length <= 20;

  if (!(hasNumber && hasLetter && lengthValid)) {
    newPasswordError.value = true;
    newPasswordErrorText.value = 'Invalid password format.';
  } else {
    newPasswordError.value = false;
    newPasswordErrorText.value = '';
  }

  if (passwordForm.value.confirmPassword.trim() !== '') {
    validateConfirmPassword();
  }
};

// 校验确认密码与新密码是否一致
const validateConfirmPassword = () => {
  const confirmPassword = passwordForm.value.confirmPassword.trim();
  const newPassword = passwordForm.value.newPassword.trim();

  if (confirmPassword === '') {
    confirmPasswordError.value = false;
    confirmPasswordErrorText.value = '';
    return;
  }

  if (confirmPassword !== newPassword) {
    confirmPasswordError.value = true;
    confirmPasswordErrorText.value = 'Passwords do not match';
  } else {
    confirmPasswordError.value = false;
    confirmPasswordErrorText.value = '';
  }
};

// 点击保存新密码：对密码进行 SHA-256 加密后调用修改密码接口
const handleSaveNewPassword = async () => {
  validateNewPassword();
  validateConfirmPassword();

  if (newPasswordError.value || confirmPasswordError.value) {
    return;
  }

  if (!passwordForm.value.currentPassword.trim() || 
      !passwordForm.value.newPassword.trim() || 
      !passwordForm.value.confirmPassword.trim()) {
    ElMessage.error('Please fill in all password fields');
    return;
  }

  try {
    const encryptedCurrentPassword = await sha256(passwordForm.value.currentPassword);
    const encryptedNewPassword = await sha256(passwordForm.value.newPassword);
    const encryptedConfirmPassword = await sha256(passwordForm.value.confirmPassword);

    await changePasswordApi({
      userId: userStore.userId,
      currentPassword: encryptedCurrentPassword,
      newPassword: encryptedNewPassword,
      confirmPassword: encryptedConfirmPassword
    });

    closeChangePasswordModal();
    
    try {
      await logoutApi();
      userStore.clearUserInfo();
      ElMessage.success('Password changed successfully');
      router.push({ name: 'home' });
    } catch (logoutError) {
      console.error('Logout error after password change:', logoutError);
      userStore.clearUserInfo();
      ElMessage.success('Password changed successfully');
      router.push({ name: 'home' });
    }
  } catch (error) {
    console.error('Change password error:', error);
  }
};

// 获取个人中心用户信息
const getProfile = () => {
  getProfileApi({userId:userStore.userId}).then(res=>{
    if (res && res.data) {
      const profileData = res.data;
      
      profileDataCache.value = profileData;
      username.value = profileData.username || '';
      
      if (profileData.telegramOne) {
        contactMethod.value = 'Telegram';
        contactValue.value = profileData.telegramOne || '';
      } else if (profileData.telephone) {
        contactMethod.value = 'Telephone';
        contactValue.value = profileData.telephone || '';
      }
      
      socialAccounts.value.forEach(item => {
        switch (item.key) {
          case 'x':
            item.value = profileData.twitter || '';
            break;
          case 'telegram':
            item.value = profileData.telegramTwo || '';
            break;
          case 'youtube':
            item.value = profileData.youtube || '';
            break;
          case 'discord':
            item.value = profileData.discord || '';
            break;
        }
      });
    }
  })
}

// 保存用户名
const saveUsername = () => {
  const params = {
    userId: userStore.userId,
    username: username.value
  };
  
  saveProfileApi(params).then(res => {
    console.log('保存用户名成功', res);
    // 保存成功提示
    ElMessage.success('Saved successfully');
    userStore.setUserName(username.value);
  }).catch(err => {
    console.error('保存用户名失败', err);
    // 保存失败提示
    ElMessage.error('Save failed. Please try again');
  });
}

// 保存联系方式
const saveAboutMe = () => {
  const contactParams = {
    userId: userStore.userId
  };
  
  if (contactMethod.value === 'Telegram') {
    contactParams.telegramOne = contactValue.value;
  } else if (contactMethod.value === 'Telephone') {
    contactParams.telephone = contactValue.value;
  }
  
  saveProfileApi(contactParams).then(res => {
    console.log('保存联系方式成功', res);
    // 保存成功提示
    ElMessage.success('Saved successfully');
  }).catch(err => {
    console.error('保存联系方式失败', err);
    // 保存失败提示
    ElMessage.error('Save failed. Please try again');
  });
}

// 保存社交账号
const saveSocialAccounts = () => {
  const twitterAccount = socialAccounts.value.find(item => item.key === 'x');
  const telegramAccount = socialAccounts.value.find(item => item.key === 'telegram');
  const youtubeAccount = socialAccounts.value.find(item => item.key === 'youtube');
  const discordAccount = socialAccounts.value.find(item => item.key === 'discord');
  
  const params = {
    userId: userStore.userId,
    twitter: twitterAccount ? twitterAccount.value : '',
    telegramTwo: telegramAccount ? telegramAccount.value : '',
    youtube: youtubeAccount ? youtubeAccount.value : '',
    discord: discordAccount ? discordAccount.value : ''
  };
  
  saveProfileApi(params).then(res => {
    console.log('保存社交账号成功', res);
    ElMessage.success('Saved successfully');
  }).catch(err => {
    console.error('保存社交账号失败', err);
    ElMessage.error('Save failed. Please try again');
  });
}

// 滚动到顶部按钮显示控制
const showScrollTop = ref(false);

const handleScroll = () => {
  showScrollTop.value = window.scrollY > 300;
};

const scrollToTop = () => {
  window.scrollTo({
    top: 0,
    behavior: 'smooth'
  });
};

onMounted(() => {
  getProfile();
  window.addEventListener('scroll', handleScroll);
});

onUnmounted(() => {
  window.removeEventListener('scroll', handleScroll);
});

</script>

<style lang="scss" scoped>
.profile-container {
  min-height: 100vh;
  background-color: #030219;
  padding-top: 60px;
  padding-bottom: 80px;
}

.profile-content {
  padding: 20px 16px;
  color: #fff;
}

.page-title {
  padding: 0;
  margin: 0;
  font-size: 32px;
  line-height: 46px;
  font-weight: 500;
  margin-bottom: 20px;
  border-bottom: 1px solid #3A3655;
  padding-bottom: 12px;
}

.section-card {
  margin-bottom: 32px;
  padding-bottom: 24px;
  border-bottom: 1px solid #3A3655;
  
  &:last-child {
    border-bottom: none;
  }
}

.section-header {
  margin-bottom: 24px;
}

.section-title {
  margin: 0;
  padding: 0;
  font-size: 20px;
  font-weight: 500;
  color: #EEEDF7;
  line-height: 28px;
}

.field {
  margin-bottom: 24px;
}

.field-label {
  display: block;
  font-size: 14px;
  color: #EEEDF7;
  margin-bottom: 8px;
  font-weight: 500;
}

.username-input-wrapper {
  position: relative;
  display: flex;
  align-items: center;
}

.text-input {
  width: 100%;
  height: 56px;
  border-radius: 12px;
  padding: 0 24px;
  padding-right: 60px;
  box-sizing: border-box;
  background: #1F1C33;
  border: 1px solid #474269;
  color: #f6f4ff;
  font-size: 16px;
  outline: none;
  transition: border-color 0.2s ease, box-shadow 0.2s ease;
}

.text-input::placeholder {
  color: #9E9CB6;
}

.text-input:focus {
  border-color: #8d67ff;
  box-shadow: 0 0 8px rgba(141, 103, 255, 0.5);
}

.char-count {
  position: absolute;
  right: 16px;
  font-size: 14px;
  color: #9E9CB6;
  pointer-events: none;
}

.field-hint {
  margin: 8px 0 0 0;
  font-size: 12px;
  color: #9E9CB6;
  line-height: 18px;
}

/* ---- 联系方式输入 + 下拉组合 ---- */
.contact-container {
  position: relative;
  display: flex;
  align-items: center;
  border-radius: 12px;
  border: 1px solid #474269;
  background: #1F1C33;
  transition: border-color 0.2s ease, box-shadow 0.2s ease;
  overflow: hidden;
}

.contact-container.has-focus {
  border-color: #8d67ff;
  box-shadow: 0 0 8px rgba(141, 103, 255, 0.5);
}

.contact-input {
  flex: 1;
  height: 56px;
  padding: 0 16px;
  border: none;
  background: transparent;
  color: #eeedf7;
  font-size: 16px;
  outline: none;
}

.contact-input::placeholder {
  color: #9E9CB6;
}

.contact-select {
  height: 56px;
  padding: 0 14px 0 12px;
  display: flex;
  align-items: center;
  gap: 8px;
  cursor: pointer;
  border-left: 1px solid rgba(71, 66, 105, 0.5);
  transition: background 0.2s ease;
}

.contact-select:hover {
  background: rgba(255, 255, 255, 0.04);
}

.contact-icon {
  width: 24px;
  height: 24px;
}

.contact-label {
  color: #ffffff;
  font-weight: 600;
  font-size: 14px;
}

.arrow {
  width: 14px;
  height: 14px;
  background-color: #ffffff;
  mask: url('@/assets/login/icon-down.svg') center/contain no-repeat;
  -webkit-mask: url('@/assets/login/icon-down.svg') center/contain no-repeat;
  transition: transform 0.2s ease;
}

/* ---- Contact Information 底部弹出选择框样式 ---- */
.bottom-sheet-fade-enter-active,
.bottom-sheet-fade-leave-active {
  transition: opacity 0.3s ease;
}

.bottom-sheet-fade-enter-active .bottom-sheet,
.bottom-sheet-fade-leave-active .bottom-sheet {
  transition: transform 0.3s ease;
}

.bottom-sheet-fade-enter-from,
.bottom-sheet-fade-leave-to {
  opacity: 0;
}

.bottom-sheet-fade-enter-from .bottom-sheet,
.bottom-sheet-fade-leave-to .bottom-sheet {
  transform: translateY(100%);
}

.bottom-sheet-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: flex-end;
  justify-content: center;
  z-index: 100;
}

.bottom-sheet {
  width: 100%;
  max-width: 100%;
  background: #1F1C33;
  border-radius: 20px 20px 0 0;
  padding: 0 0 32px 0;
  box-sizing: border-box;
  max-height: 50vh;
  display: flex;
  flex-direction: column;
  box-shadow: 0 -4px 20px rgba(0, 0, 0, 0.3);
}

.bottom-sheet-handle {
  width: 40px;
  height: 4px;
  background: #474269;
  border-radius: 2px;
  margin: 12px auto 24px;
  flex-shrink: 0;
}

.bottom-sheet-content {
  flex: 1;
  overflow-y: auto;
  padding: 0 16px;
}

.bottom-sheet-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 16px;
  border-radius: 12px;
  cursor: pointer;
  transition: background 0.2s ease;
  position: relative;
  margin-bottom: 8px;

  &:last-child {
    margin-bottom: 0;
  }

  &:active {
    background: rgba(255, 255, 255, 0.05);
  }
}

.bottom-sheet-item.active {
  background: #2b2545;
}

.bottom-sheet-icon {
  width: 24px;
  height: 24px;
  flex-shrink: 0;
}

.bottom-sheet-label {
  flex: 1;
  font-size: 16px;
  font-weight: 500;
  color: #EEEDF7;
}

.check-icon {
  width: 20px;
  height: 20px;
  color: #ffffff;
  flex-shrink: 0;
}

.field-actions {
  margin-top: 24px;
}

.field-actions-inline {
  margin-top: 16px;
}

.primary-btn {
  width: 100%;
  height: 52px;
  box-sizing: border-box;
  border-radius: 12px;
  border: none;
  background: #7644FB;
  color: #EEEDF7;
  font-weight: 600;
  font-size: 16px;
  cursor: pointer;
  text-align: center;
  transition: background 0.2s ease;
}

.primary-btn:active {
  background: #8d67ff;
}

/* ---- Social Accounts ---- */
.social-row {
  margin-bottom: 24px;
  
  &:last-child {
    margin-bottom: 0;
  }
}

.social-left {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 8px;
}

.social-icon {
  width: 20px;
  height: 20px;
}

.social-label {
  font-size: 16px;
  color: #EEEDF7;
  font-weight: 500;
}

.social-input-wrapper {
  flex: 1;
  display: flex;
  align-items: center;
  border-radius: 12px;
  border: 1px solid #474269;
  background: #1F1C33;
  transition: border-color 0.2s ease, box-shadow 0.2s ease;
  overflow: hidden;
}

.social-input-wrapper:focus-within {
  border-color: #8d67ff;
  box-shadow: 0 0 8px rgba(141, 103, 255, 0.5);
}

.social-input {
  flex: 1;
  height: 56px;
  padding: 0 24px;
  border: none;
  background: transparent;
  color: #f6f4ff;
  font-size: 16px;
  outline: none;
}

.social-input::placeholder {
  color: #9E9CB6;
}

.copy-btn {
  width: 56px;
  height: 56px;
  border: none;
  background: transparent;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  padding: 0;
  transition: background 0.2s ease;
  flex-shrink: 0;
}

.copy-btn:active {
  background: rgba(255, 255, 255, 0.1);
}

.copy-icon {
  width: 20px;
  height: 20px;
  opacity: 0.8;
}

/* Password 区块 */
.password-content {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.password-desc {
  font-size: 14px;
  color: #9E9CB6;
  line-height: 22px;
  margin: 0;
}

.secondary-btn {
  width: 100%;
  height: 52px;
  text-align: center;
  border-radius: 12px;
  background: #251A50;
  border: none;
  color: #EEEDF7;
  font-size: 16px;
  font-weight: 600;
  cursor: pointer;
  transition: background 0.2s ease;
}

.secondary-btn:active {
  background: rgba(124, 100, 255, 0.16);
}

/* ---------------- Change Password 弹框样式 ---------------- */

.change-pass-modal-fade-enter-active,
.change-pass-modal-fade-leave-active {
  transition: opacity 0.3s ease;
}

.change-pass-modal-fade-enter-active .change-pass-modal,
.change-pass-modal-fade-leave-active .change-pass-modal {
  transition: transform 0.3s ease;
}

.change-pass-modal-fade-enter-from,
.change-pass-modal-fade-leave-to {
  opacity: 0;
}

.change-pass-modal-fade-enter-from .change-pass-modal,
.change-pass-modal-fade-leave-to .change-pass-modal {
  transform: translateY(100%);
}

.change-pass-modal-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: flex-end;
  justify-content: center;
  z-index: 100;
}

.change-pass-modal {
  width: 100%;
  max-width: 100%;
  background: #1F1C33;
  border-radius: 20px 20px 0 0;
  padding: 0 24px 32px 24px;
  box-sizing: border-box;
  max-height: 80vh;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  box-shadow: 0 -4px 20px rgba(0, 0, 0, 0.3);
}

.change-pass-handle {
  width: 40px;
  height: 4px;
  background: #474269;
  border-radius: 2px;
  margin: 12px auto 24px;
  flex-shrink: 0;
}

.change-pass-header {
  display: flex;
  align-items: center;
  margin-bottom: 20px;
}

.change-pass-title {
  margin: 0;
  font-size: 24px;
  font-weight: 500;
  color: #EEEDF7;
}

.change-pass-desc {
  margin: 0 0 20px 0;
  font-size: 14px;
  line-height: 22px;
  color: #EEEDF7;
  font-weight: 500;
}

.change-pass-form {
  .form-group {
    width: 100%;
    margin-bottom: 20px;
  }

  .form-label {
    display: block;
    font-size: 14px;
    font-weight: 500;
    color: #ffffff;
    margin-bottom: 4px;
  }

  .password-input-wrapper {
    position: relative;
  }

  .form-input {
    width: 100%;
    height: 56px;
    padding: 0 24px;
    background: #1f1c33;
    border: 1px solid #474269;
    border-radius: 12px;
    font-size: 14px;
    color: #ffffff;
    outline: none;
    box-sizing: border-box;
    transition: border-color 0.2s ease, box-shadow 0.2s ease;

    &::placeholder {
      color: rgba(185, 176, 255, 0.64);
      font-size: 16px;
    }

    &:focus {
      border-color: #8d67ff;
      box-shadow: 0 0 8px rgba(96, 78, 158, 0.5);
    }
  }

  .password-input {
    padding-right: 48px;
  }

  .password-toggle-btn {
    position: absolute;
    right: 24px;
    top: 50%;
    transform: translateY(-50%);
    width: 20px;
    height: 20px;
    background: transparent;
    border: none;
    cursor: pointer;
    padding: 0;
    display: flex;
    align-items: center;
    justify-content: center;

    img {
      width: 20px;
      height: 20px;
      display: block;
      transition: filter 0.2s ease;
    }
  }

  .form-input-error {
    border-color: #ea3943 !important;

    &:focus {
      border-color: #ea3943 !important;
      box-shadow: none;
    }
  }

  .error-message {
    margin-top: 4px;
    font-size: 14px;
    line-height: 22px;
    color: #ea3943;
    text-align: left;
  }

  .password-rules {
    margin-top: 4px;
    display: flex;
    flex-direction: column;
    gap: 4px;
  }

  .password-rule-item {
    font-size: 14px;
    line-height: 22px;
    color: #ea3943;
  }

  .help-text {
    margin-bottom: 20px;
    font-size: 14px;
    font-weight: 500;
    line-height: 22px;
    color: #B2ADE2;
  }

  .save-pass-btn {
    width: 100%;
    height: 52px;
    background: #7644fb;
    border: none;
    border-radius: 12px;
    font-size: 16px;
    font-weight: 500;
    color: #eeedf7;
    cursor: pointer;
    transition: background 0.2s ease;

    &:active {
      background: #8d67ff;
    }
  }
}

/* 滚动到顶部按钮 */
.scroll-top-btn {
  position: fixed;
  bottom: 100px;
  right: 16px;
  width: 48px;
  height: 48px;
  border-radius: 50%;
  background: rgba(48, 45, 72, 0.8);
  border: none;
  color: #ffffff;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 999;
  transition: background 0.2s ease, transform 0.2s ease;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);

  svg {
    width: 24px;
    height: 24px;
    transform: rotate(180deg);
  }

  &:active {
    background: rgba(48, 45, 72, 1);
    transform: scale(0.95);
  }
}
</style>
