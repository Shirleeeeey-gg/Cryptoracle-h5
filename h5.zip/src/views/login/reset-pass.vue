<template>
  <div class="reset-pass-container">
    <!-- 第一个标题栏：Log In -->
    <div class="login-header">
      <h2 class="login-title">Log In</h2>
      <button class="close-btn" @click="handleClose">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect
            x="4.02515"
            y="18.5225"
            width="20.538"
            height="2.0538"
            rx="1.0269"
            transform="rotate(-45 4.02515 18.5225)"
            fill="currentColor"
          />
          <rect
            x="5.23328"
            y="4.02515"
            width="20.538"
            height="2.0538"
            rx="1.0269"
            transform="rotate(45 5.23328 4.02515)"
            fill="currentColor"
          />
        </svg>
      </button>
    </div>

    <!-- 第二个标题栏：Change your password -->
    <div class="reset-pass-header">
      <button class="back-btn" @click="handleBack">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M15 18L9 12L15 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
      </button>
      <h2 class="reset-pass-title">Change your password</h2>
    </div>

    <!-- 表单内容 -->
    <div class="reset-pass-content">
      <!-- 说明文字 -->
      <p class="form-description">
        For added security, your new password should have min. 8 characters that contain letters, numbers and symbols.
      </p>
      
      <!-- 新密码输入框 -->
      <div class="form-group">
        <label class="form-label">Enter new password</label>
        <div class="password-input-wrapper">
          <input
            v-model="formData.newPassword"
            :type="showNewPassword ? 'text' : 'password'"
            :class="['form-input', 'password-input', { 'form-input-error': newPasswordError }]"
            placeholder="Enter your new password..."
            required
            @blur="validateNewPassword"
            @input="checkPasswordRules"
          />
          <button
            type="button"
            class="password-toggle-btn"
            @click="toggleNewPasswordVisibility"
          >
            <img
              :src="showNewPassword ? iconEye : iconEyeClose"
              alt="Toggle password visibility"
            />
          </button>
        </div>
        <!-- 密码验证规则提示 -->
        <div v-if="showLengthRule || showFormatRule" class="password-rules">
          <div v-if="showLengthRule" class="password-rule-item">- Use 8-20 characters.</div>
          <div v-if="showFormatRule" class="password-rule-item">- Include both letters and numbers.</div>
        </div>
        <!-- 错误提示信息 -->
        <div v-if="newPasswordError" class="error-message">{{ newPasswordErrorText }}</div>
      </div>
      
      <!-- 确认新密码输入框 -->
      <div class="form-group">
        <label class="form-label">Confirm new password</label>
        <div class="password-input-wrapper">
          <input
            v-model="formData.confirmPassword"
            :type="showConfirmPassword ? 'text' : 'password'"
            :class="['form-input', 'password-input', { 'form-input-error': confirmPasswordError }]"
            placeholder="Repeat your new password..."
            required
            @blur="validateConfirmPassword"
            @input="handleConfirmPasswordInput"
          />
          <button
            type="button"
            class="password-toggle-btn"
            @click="toggleConfirmPasswordVisibility"
          >
            <img
              :src="showConfirmPassword ? iconEye : iconEyeClose"
              alt="Toggle password visibility"
            />
          </button>
        </div>
        <!-- 错误提示信息 -->
        <div v-if="confirmPasswordError" class="error-message">{{ confirmPasswordErrorText }}</div>
      </div>
      
      <!-- 保存按钮 -->
      <button 
        type="button" 
        class="submit-btn" 
        :disabled="isLoading || !isFormValid"
        @click="handleSubmit"
      >
        <span v-if="isLoading" class="loading-spinner"></span>
        <span>{{ isLoading ? 'Saving...' : 'Save new password' }}</span>
      </button>
    </div>

    <!-- 重置密码成功弹窗组件 -->
    <ResetSuccess
      :visible="showSuccessModal"
      @close="handleCloseSuccessModal"
      @sign-in="handleSignIn"
    />
  </div>
</template>

<script setup>
import { ref, computed } from 'vue';
import { useRouter, useRoute } from 'vue-router';
import ResetSuccess from '@/components/Login/ResetSuccess.vue';
import iconEye from '@/assets/login/icon-eye.svg';
import iconEyeClose from '@/assets/login/icon-eye-close.svg';
import { resetPasswordApi } from '@/api/login';
import { sha256 } from '@/utils/encrypto';

const router = useRouter();
const route = useRoute();
const cocode = route.query.cocode || '';

// 表单数据
const formData = ref({
  newPassword: '',
  confirmPassword: '',
});

// 控制密码显示/隐藏
const showNewPassword = ref(false);
const showConfirmPassword = ref(false);

// 密码验证错误状态
const newPasswordError = ref(false);
const confirmPasswordError = ref(false);

// 错误提示文本
const newPasswordErrorText = ref('');
const confirmPasswordErrorText = ref('');

// 密码规则提示显示状态
const showLengthRule = ref(false); // 是否显示长度规则提示（8-20字符）
const showFormatRule = ref(false); // 是否显示格式规则提示（包含数字和字母）

// 提交加载状态
const isLoading = ref(false);

// 重置密码成功弹窗显示状态
const showSuccessModal = ref(false);

// 表单验证状态（计算属性）
const isFormValid = computed(() => {
  return (
    formData.value.newPassword.trim() !== '' &&
    formData.value.confirmPassword.trim() !== '' &&
    !newPasswordError.value &&
    !confirmPasswordError.value
  );
});

// 切换新密码显示状态
const toggleNewPasswordVisibility = () => {
  showNewPassword.value = !showNewPassword.value;
};

// 切换确认密码显示状态
const toggleConfirmPasswordVisibility = () => {
  showConfirmPassword.value = !showConfirmPassword.value;
};

// 实时检查密码规则（在用户输入时触发）
const checkPasswordRules = () => {
  const password = formData.value.newPassword;
  
  // 如果密码为空，隐藏所有规则提示
  if (!password || password.trim() === '') {
    showLengthRule.value = false;
    showFormatRule.value = false;
    // 清除错误状态
    if (newPasswordError.value) {
      newPasswordError.value = false;
      newPasswordErrorText.value = '';
    }
    return;
  }
  
  // 检查长度规则：8-20 字符
  const lengthValid = password.length >= 8 && password.length <= 20;
  showLengthRule.value = !lengthValid;
  
  // 检查格式规则：至少包含一个数字和一个字母
  const hasNumber = /\d/.test(password); // 检查是否包含数字
  const hasLetter = /[a-zA-Z]/.test(password); // 检查是否包含字母（不区分大小写）
  showFormatRule.value = !(hasNumber && hasLetter);
  
  // 输入时清除错误状态
  if (newPasswordError.value) {
    newPasswordError.value = false;
    newPasswordErrorText.value = '';
  }
  
  // 如果确认密码已输入，重新验证确认密码
  if (formData.value.confirmPassword.trim() !== '') {
    validateConfirmPassword();
  }
};

// 确认密码输入变化处理
const handleConfirmPasswordInput = () => {
  // 输入时清除错误状态
  if (confirmPasswordError.value) {
    confirmPasswordError.value = false;
    confirmPasswordErrorText.value = '';
  }
};

// 新密码格式验证函数
const validateNewPassword = () => {
  const password = formData.value.newPassword.trim();
  
  // 先检查规则
  checkPasswordRules();
  
  // 如果密码为空，不显示错误（因为 required 属性会处理）
  if (password === '') {
    newPasswordError.value = false;
    newPasswordErrorText.value = '';
    return;
  }
  
  // 校验规则：至少包含一个数字和一个字母（不区分大小写）
  const hasNumber = /\d/.test(password); // 检查是否包含数字
  const hasLetter = /[a-zA-Z]/.test(password); // 检查是否包含字母（不区分大小写）
  
  // 检查长度
  const lengthValid = password.length >= 8 && password.length <= 20;
  
  // 如果缺少数字或字母，或者长度不符合要求，则显示错误
  if (!(hasNumber && hasLetter && lengthValid)) {
    newPasswordError.value = true;
    newPasswordErrorText.value = 'Invalid password format.';
  } else {
    newPasswordError.value = false;
    newPasswordErrorText.value = '';
  }
  
  // 如果确认密码已输入，重新验证确认密码
  if (formData.value.confirmPassword.trim() !== '') {
    validateConfirmPassword();
  }
};

// 确认密码验证函数
const validateConfirmPassword = () => {
  const confirmPassword = formData.value.confirmPassword.trim();
  const newPassword = formData.value.newPassword.trim();
  
  // 如果确认密码为空，不显示错误（因为 required 属性会处理）
  if (confirmPassword === '') {
    confirmPasswordError.value = false;
    confirmPasswordErrorText.value = '';
    return;
  }
  
  // 验证两个密码是否一致
  if (confirmPassword !== newPassword) {
    confirmPasswordError.value = true;
    confirmPasswordErrorText.value = 'Passwords do not match';
  } else {
    confirmPasswordError.value = false;
    confirmPasswordErrorText.value = '';
  }
};

// 处理表单提交
const handleSubmit = async () => {
  // 如果正在加载中，不重复提交
  if (isLoading.value) {
    return;
  }
  
  // 验证新密码格式
  validateNewPassword();
  // 验证确认密码
  validateConfirmPassword();
  
  // 如果验证失败，不提交
  if (newPasswordError.value || confirmPasswordError.value) {
    return;
  }
  
  // 设置加载状态
  isLoading.value = true;
  
  try {
    // 使用 SHA-256 加密新密码和确认密码
    const encryptedNewPassword = await sha256(formData.value.newPassword);
    const encryptedConfirmPassword = await sha256(formData.value.confirmPassword);
    
    // 调用重置密码接口，传递 code、加密后的 newPassword 和 confirmPassword
    await resetPasswordApi({
      code: cocode,
      newPassword: encryptedNewPassword,
      confirmPassword: encryptedConfirmPassword
    });
    
    // 成功后显示重置密码成功弹窗
    showSuccessModal.value = true;
    
  } catch (error) {
    // 重置密码失败，打印错误信息
    console.error('Password reset error:', error);
    // 错误信息已通过 request.js 中的 ElMessage 显示
  } finally {
    // 无论成功或失败，都重置加载状态
    isLoading.value = false;
  }
};

// 关闭重置密码成功弹窗
const handleCloseSuccessModal = () => {
  showSuccessModal.value = false;
};

// 跳转到 home 页并打开登录弹窗
const handleSignIn = () => {
  showSuccessModal.value = false;
  // 跳转到 home 页，并带上 openLogin 参数以触发登录弹窗
  router.push({ 
    name: 'home',
    query: { openLogin: 'true' }
  });
};

// 处理关闭
const handleClose = () => {
  router.push({ name: 'home' });
};

// 处理返回
const handleBack = () => {
  router.back();
};
</script>

<style scoped lang="scss">
.reset-pass-container {
  width: 100%;
  min-height: 100vh;
  background: #1A1625;
  padding: 20px 20px 32px;
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
}

// 第一个标题栏：Log In
.login-header {
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;
  margin-bottom: 0;
  min-height: 44px;
}

.login-title {
  font-family: 'Tomato Grotesk', sans-serif;
  font-size: 16px;
  font-weight: 500;
  line-height: 24px;
  color: #ffffff;
  margin: 0;
  text-align: center;
}

.login-header .close-btn {
  position: absolute;
  right: 0;
  top: 50%;
  transform: translateY(-50%);
  width: 24px;
  height: 24px;
  background: transparent;
  border: none;
  cursor: pointer;
  padding: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #ffffff;
  transition: opacity 0.2s ease;

  svg {
    width: 24px;
    height: 24px;
    display: block;
  }

  &:active {
    opacity: 0.8;
  }
}

// 第二个标题栏：Change your password
.reset-pass-header {
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;
  margin-bottom: 32px;
  min-height: 44px;
}

.back-btn {
  position: absolute;
  left: 0;
  top: 50%;
  transform: translateY(-50%);
  width: 24px;
  height: 24px;
  background: transparent;
  border: none;
  cursor: pointer;
  padding: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #ffffff;
  transition: opacity 0.2s ease;

  svg {
    width: 24px;
    height: 24px;
    display: block;
  }

  &:active {
    opacity: 0.8;
  }
}

.reset-pass-title {
  font-family: 'Tomato Grotesk', sans-serif;
  font-size: 16px;
  font-weight: 500;
  line-height: 24px;
  color: #ffffff;
  margin: 0;
  text-align: center;
}

.reset-pass-content {
  flex: 1;
  display: flex;
  flex-direction: column;
}

.form-description {
  font-family: 'Tomato Grotesk', sans-serif;
  font-size: 14px;
  font-weight: 500;
  line-height: 22px;
  color: rgba(201, 195, 255, 0.89);
  text-align: left;
  margin: 0 0 24px 0;
}

.form-group {
  margin-bottom: 24px;
}

.form-label {
  display: block;
  font-family: 'Tomato Grotesk', sans-serif;
  font-size: 14px;
  line-height: 22px;
  font-weight: 500;
  color: #ffffff;
  margin-bottom: 4px;
}

.password-input-wrapper {
  position: relative;
}

.form-input {
  width: 100%;
  height: 56px;
  padding: 0 20px;
  background: #1A1625;
  border: 1px solid rgba(178, 167, 255, 0.6);
  border-radius: 12px;
  font-family: 'Tomato Grotesk', sans-serif;
  font-size: 16px;
  color: #ffffff;
  outline: none;
  transition: border-color 0.2s ease, background-color 0.2s ease;
  box-sizing: border-box;
  -webkit-appearance: none;
  appearance: none;

  &::placeholder {
    color: rgba(185, 176, 255, 0.64);
    font-size: 14px;
  }

  &:focus {
    border-color: #8D67FF;
    box-shadow: 0px 0px 8px 0px rgba(141, 103, 255, 0.3);
  }
}

.password-input {
  padding-right: 56px;
}

.password-toggle-btn {
  position: absolute;
  right: 20px;
  top: 50%;
  transform: translateY(-50%);
  width: 20px;
  height: 20px;
  background: transparent;
  border: none;
  cursor: pointer;
  padding: 0;
  display: flex;
  align-items: center;
  justify-content: center;

  img {
    width: 20px;
    height: 20px;
    display: block;
  }
}

.form-input-error {
  border-color: #EA3943 !important;
  
  &:focus {
    border-color: #EA3943 !important;
    box-shadow: none;
  }
}

.error-message {
  margin-top: 8px;
  font-family: 'Tomato Grotesk', sans-serif;
  font-size: 14px;
  line-height: 22px;
  color: #EA3943;
}

.password-rules {
  margin-top: 4px;
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.password-rule-item {
  font-family: 'Tomato Grotesk', sans-serif;
  font-size: 14px;
  line-height: 22px;
  color: #EA3943;
}

.submit-btn {
  width: 100%;
  height: 56px;
  background: #7644FB;
  border: none;
  border-radius: 12px;
  font-family: 'Tomato Grotesk', sans-serif;
  font-size: 16px;
  font-weight: 500;
  color: #EEEDF7;
  cursor: pointer;
  transition: background-color 0.2s ease, transform 0.1s ease;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  flex-shrink: 0;
  margin-top: auto;

  &:active:not(:disabled) {
    background: #8D67FF;
    transform: scale(0.98);
  }

  &:disabled {
    background: #7644FB;
    color: #EEEDF7;
    cursor: not-allowed;
    opacity: 0.6;
  }
}

.loading-spinner {
  width: 16px;
  height: 16px;
  border: 2px solid rgba(238, 237, 247, 0.3);
  border-top-color: #EEEDF7;
  border-radius: 50%;
  animation: spin 0.8s linear infinite;
}

@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}
</style>
