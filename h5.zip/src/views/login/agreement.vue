<template>
  <div class="agreement-container">
    <Navbar />

    <!-- 内容区域 -->
    <div class="content-wrapper" v-if="agreementData">
      <div class="content">
        <!-- 标题和更新时间 -->
        <h1 class="title">{{ agreementData.title }}</h1>
        <p class="last-updated">Last updated: {{ agreementData.lastUpdated }}</p>

        <!-- Privacy Policy 的介绍 -->
        <div v-if="agreementData.introduction" class="introduction">
          {{ agreementData.introduction }}
        </div>

        <!-- Privacy Policy 的目录 -->
        <div v-if="agreementData.tableOfContents" class="table-of-contents">
          <h2 class="toc-title">This Policy Will Help You Understand:</h2>
          <ul class="toc-list">
            <li v-for="item in agreementData.tableOfContents" :key="item.id" class="toc-item">
              <a :href="`#${item.id}`" @click.prevent="scrollToSection(item.id)" class="toc-link">
                {{ item.title }}
              </a>
            </li>
          </ul>
        </div>

        <!-- 主要内容区域 -->
        <div class="sections">
          <!-- Cookie Notice 和 Terms of Use 的 sections -->
          <template v-for="(section, index) in agreementData.sections" :key="section.id || index">
            <!-- 有 title 的 section -->
            <section v-if="section.title" :id="section.id" class="section">
              <h2 class="section-title">{{ section.title }}</h2>

              <!-- 纯文本内容 -->
              <div
                v-if="section.content && !section.subsections"
                class="section-content"
                v-html="formatContent(section.content)"
              ></div>

              <!-- 有 subsections 的内容 -->
              <template v-if="section.subsections">
                <div
                  v-for="(subsection, subIndex) in section.subsections"
                  :key="subIndex"
                  :class="subsection.title ? 'subsection' : 'subsection-no-title'"
                >
                  <h3 v-if="subsection.title" class="subsection-title">{{ subsection.title }}</h3>
                  <div
                    v-if="subsection.content"
                    :class="subsection.title ? 'subsection-content' : 'section-content'"
                    v-html="formatContent(subsection.content)"
                  ></div>

                  <!-- 嵌套的 subsections（Privacy Policy 中的 Account Registration 等） -->
                  <template v-if="subsection.subsections">
                    <div v-for="(nestedSub, nestedIndex) in subsection.subsections" :key="nestedIndex" class="nested-subsection">
                      <h4 v-if="nestedSub.title" class="nested-subsection-title">{{ nestedSub.title }}</h4>
                      <div v-if="nestedSub.content" class="nested-subsection-content" v-html="formatContent(nestedSub.content)"></div>
                    </div>
                  </template>
                </div>
              </template>

              <!-- Cookie Notice 的表格 -->
              <div v-if="section.table" class="cookie-table">
                <table>
                  <thead>
                    <tr>
                      <th>Category</th>
                      <th>Description</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr v-for="(row, rowIndex) in section.table" :key="rowIndex">
                      <td class="category-cell">{{ row.category }}</td>
                      <td class="description-cell">{{ row.description }}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </section>

            <!-- 没有 title 的 section（Terms of Use 的 introduction） -->
            <section v-else :id="section.id" class="section">
              <div class="section-content" v-html="formatContent(section.content)"></div>
            </section>
          </template>

          <!-- Privacy Policy 的免责声明 -->
          <div v-if="agreementData.disclaimer" class="disclaimer">
            <h2 class="disclaimer-title">{{ agreementData.disclaimer.title }}</h2>
            <div v-for="(item, index) in agreementData.disclaimer.subsections" :key="index" class="disclaimer-item">
              <h3 class="disclaimer-item-title">{{ item.title }}</h3>
              <div class="disclaimer-item-content" v-html="formatContent(item.content)"></div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <Footer />
  </div>
</template>

<script setup>
import { computed, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import Navbar from '@/components/Navbar.vue'
import Footer from '@/components/Footer.vue'

// 导入 JSON 数据文件
import cookieNoticeData from './data/cookie-notice.json'
import privacyPolicyData from './data/privacy-policy.json'
import termsOfUseData from './data/terms-of-use.json'

const route = useRoute()

// 根据路由名称加载对应的数据
const agreementData = computed(() => {
  const routeName = route.name
  switch (routeName) {
    case 'cookie-notice':
      return cookieNoticeData
    case 'privacy-policy':
      return privacyPolicyData
    case 'terms-of-use':
      return termsOfUseData
    default:
      return null
  }
})

// 格式化内容，处理邮箱链接和换行
const formatContent = (content) => {
  if (!content) return ''

  // 将邮箱地址转换为可点击的链接
  const emailRegex = /support@cryptoracle\.network/g
  let formatted = content.replace(
    emailRegex,
    '<a href="mailto:support@cryptoracle.network" class="email-link">support@cryptoracle.network</a>',
  )

  // 处理换行符（\n），但保留列表格式
  // 先处理列表项，再处理换行
  const lines = formatted.split('\n')
  const processedLines = []
  let inList = false

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i]
    const trimmedLine = line.trim()

    // 检查是否是列表项（以 * 或数字开头）
    const bulletMatch = trimmedLine.match(/^\* (.+)$/)
    const numberMatch = trimmedLine.match(/^(\d+)\. (.+)$/)

    if (bulletMatch || numberMatch) {
      if (!inList) {
        processedLines.push('<ul>')
        inList = true
      }
      // 提取列表项内容
      const listContent = bulletMatch ? bulletMatch[1] : numberMatch[2]
      processedLines.push(`<li>${listContent}</li>`)
    } else {
      if (inList) {
        processedLines.push('</ul>')
        inList = false
      }
      if (trimmedLine) {
        processedLines.push(trimmedLine)
      } else if (i < lines.length - 1) {
        // 只在不是最后一行时添加换行
        processedLines.push('<br>')
      }
    }
  }

  // 如果最后还在列表中，关闭列表
  if (inList) {
    processedLines.push('</ul>')
  }

  formatted = processedLines.join('')

  // 处理加粗文本（**text**）
  formatted = formatted.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')

  return formatted
}

// 锚点滚动功能
const scrollToSection = (sectionId) => {
  const element = document.getElementById(sectionId)
  if (element) {
    // 计算偏移量，考虑导航栏高度（mobile navbar 为 60px）
    const offset = 80
    const elementPosition = element.getBoundingClientRect().top
    const offsetPosition = elementPosition + window.pageYOffset - offset

    window.scrollTo({
      top: offsetPosition,
      behavior: 'smooth',
    })
  }
}

// 组件挂载后，如果有 hash，滚动到对应位置
onMounted(() => {
  if (route.hash) {
    // 移除 # 符号
    const sectionId = route.hash.substring(1)
    setTimeout(() => {
      scrollToSection(sectionId)
    }, 100)
  }
})
</script>

<style lang="scss" scoped>
h1,
h2,
h3,
h4 {
  margin: 0;
  padding: 0;
}
.agreement-container {
  width: 100%;
  min-height: 100vh;
  padding-top: 60px; // mobile Navbar 高度
  box-sizing: border-box;
  background-color: #0a061d;
  display: flex;
  flex-direction: column;
}

.content-wrapper {
  flex: 1;
  width: 100%;
  padding: 0 16px;
  box-sizing: border-box;
}

.content {
  color: #eeedf7;
  font-family: 'Tomato Grotesk', sans-serif;
  line-height: 1.8;
  padding-top: 32px;

  .title {
    padding: 0;
    margin: 0;
    font-size: 28px;
    font-weight: 600;
    color: #ffffff;
    margin-bottom: 12px;
    line-height: 36px;
    text-align: center;
  }

  .last-updated {
    font-size: 12px;
    color: #b2ade2;
    margin-bottom: 28px;
    font-weight: 500;
    text-align: center;
    line-height: 18px;
  }

  // 目录样式
  .table-of-contents {
    margin-bottom: 28px;
    padding: 0;
    background: transparent;
    border: none;

    .toc-title {
      font-size: 16px;
      font-weight: 600;
      color: #ffffff;
      margin-bottom: 16px;
    }

    .toc-list {
      margin: 0;

      .toc-item {
        position: relative;
        margin-bottom: 12px;
        padding-left: 14px;
        list-style: none;
        color: #8d67ff; // 文本与小圆点默认颜色保持一致

        // 自定义小圆点，颜色跟随 currentColor
        &::before {
          content: '';
          position: absolute;
          left: 0;
          top: 9px;
          width: 4px;
          height: 4px;
          border-radius: 50%;
          background-color: currentColor;
        }

        // hover 时同时改变文字和小圆点颜色
        &:hover {
          color: #dfdcff;
        }

        .toc-link {
          color: inherit; // 继承 li 颜色，保证和小圆点颜色一致
          text-decoration: none;
          font-size: 14px;
          font-weight: 400;
          transition: color 0.3s ease;
          cursor: pointer;
          display: inline-block;
        }
      }
    }
  }

  // 介绍段落
  .introduction {
    margin-bottom: 20px;
    font-size: 14px;
    color: #ffffff;
    line-height: 22px;
    font-weight: 500;
  }

  // 章节样式
  .sections {
    .section {
      scroll-margin-top: 80px; // 锚点滚动时的偏移
      margin-bottom: 14px;

      .section-title {
        font-size: 18px;
        font-weight: 600;
        color: #ffffff;
        line-height: 1.3;
        margin-top: 20px;
        margin-bottom: 12px;
      }

      .section-content {
        font-size: 14px;
        color: #ffffff;
        line-height: 1.8;
        font-weight: 400;

        // 邮箱链接样式
        :deep(.email-link) {
          color: #ab8bff;
          text-decoration: none;
          transition: color 0.3s ease;

          &:hover {
            color: #f2dffc;
            text-decoration: underline;
          }
        }

        // 列表样式
        :deep(ul) {
          margin: 14px 0;
          padding-left: 18px;

          li {
            margin-bottom: 10px;
            line-height: 1.8;
            color: #ffffff;
          }
        }

        // 加粗文本
        :deep(strong) {
          font-weight: 600;
          color: #ffffff;
        }
      }

      // 子章节样式
      .subsection {
        margin-bottom: 24px;

        .subsection-title {
          font-size: 16px;
          font-weight: 600;
          color: #ffffff;
          margin-bottom: 12px;
          margin-top: 18px;
          line-height: 1.4;
        }

        .subsection-content {
          font-size: 14px;
          color: #ffffff;
          line-height: 1.8;
          margin-bottom: 14px;
          font-weight: 400;

          :deep(.email-link) {
            color: #ab8bff;
            text-decoration: none;
            transition: color 0.3s ease;

            &:hover {
              color: #f2dffc;
              text-decoration: underline;
            }
          }

          :deep(ul) {
            margin: 14px 0;
            padding-left: 18px;

            li {
              margin-bottom: 10px;
              line-height: 1.8;
              color: #ffffff;
            }
          }

          :deep(strong) {
            font-weight: 600;
            color: #ffffff;
          }
        }

        // 嵌套子章节
        .nested-subsection {
          margin-bottom: 16px;
          margin-left: 12px;

          .nested-subsection-title {
            font-size: 14px;
            font-weight: 600;
            color: #ffffff;
            margin-bottom: 10px;
            margin-top: 16px;
            line-height: 1.4;
          }

          .nested-subsection-content {
            font-size: 14px;
            color: #ffffff;
            line-height: 1.8;
            font-weight: 400;

            :deep(.email-link) {
              color: #ab8bff;
              text-decoration: none;
              transition: color 0.3s ease;

              &:hover {
                color: #f2dffc;
                text-decoration: underline;
              }
            }
          }
        }
      }

      // 无标题的子章节（作为普通段落显示）
      .subsection-no-title {
        margin-bottom: 16px;
      }

      // Cookie 表格样式
      .cookie-table {
        margin-top: 20px;
        overflow-x: auto;

        table {
          width: 100%;
          border-collapse: collapse;
          border-spacing: 0;
          background: transparent;
          border: 1px solid rgba(255, 255, 255, 0.12); // 外边框

          thead {
            background: transparent;

            th {
              padding: 12px 0;
              text-align: left;
              font-size: 13px;
              font-weight: 600;
              color: #ffffff;
              border-right: 1px solid rgba(255, 255, 255, 0.12);
              border-bottom: 1px solid rgba(255, 255, 255, 0.12);

              &:first-child {
                width: 32%;
                padding: 12px 12px;
              }

              &:last-child {
                width: 68%;
                padding: 12px 12px;
                border-right: none; // 最后一列不需要右边框，避免双线
              }
            }
          }

          tbody {
            tr {
              border-bottom: 1px solid rgba(255, 255, 255, 0.12);
            }

            td {
              padding: 12px 0;
              font-size: 13px;
              color: #ffffff;
              line-height: 1.8;
              font-weight: 400;
              border-right: 1px solid rgba(255, 255, 255, 0.12);
            }

            .category-cell {
              font-weight: 600;
              color: #ffffff;
              padding: 12px 12px;
            }

            .description-cell {
              color: #ffffff;
              padding: 12px 12px 12px 12px;
              border-right: none;
            }
          }
        }
      }
    }

    // 免责声明样式
    .disclaimer {
      margin-top: 32px;
      padding: 0;
      background: transparent;
      border: none;

      .disclaimer-title {
        font-size: 18px;
        font-weight: 600;
        color: #ffffff;
        margin-bottom: 18px;
        line-height: 1.3;
      }

      .disclaimer-item {
        margin-bottom: 18px;

        &:last-child {
          margin-bottom: 0;
        }

        .disclaimer-item-title {
          font-size: 16px;
          font-weight: 600;
          color: #ffffff;
          margin-bottom: 12px;
          line-height: 1.4;
        }

        .disclaimer-item-content {
          font-size: 14px;
          color: #ffffff;
          line-height: 1.8;
          font-weight: 400;

          :deep(.email-link) {
            color: #ab8bff;
            text-decoration: none;
            transition: color 0.3s ease;

            &:hover {
              color: #f2dffc;
              text-decoration: underline;
            }
          }
        }
      }
    }
  }
}
</style>
