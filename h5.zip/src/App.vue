<script setup>
import Navbar from './components/Navbar.vue'
import { useRoute } from 'vue-router';
import { computed, ref, watch, onMounted } from 'vue';
import TellUsMore from '@/components/Login/TellUsMore.vue';
import { useUserStore } from '@/store/user';
import {checkUserTellUsMoreApi} from '@/api/login';
import {ElMessage} from 'element-plus';

const route = useRoute();
const showNavBar = computed(() => {
  const routeName = route.name;
  return routeName != 'reset-pass';
})

const from = computed(() => route.query.from || '');
// 控制 TellUsMore 弹框显示
const showTellUsMore = ref(false);

/**
 * 检查路由 query 参数，如果满足条件则显示 TellUsMore 弹框
 * 条件：from=mail 且 type=verify-email
 */
const isVerified = ref(1);  //用户是否已填写 tell us more    是否已验证 0-未验证 1-已验证 2-已过期
const userStore = useUserStore();
const checkQueryParams = async () => {
  const cocode = route.query.cocode;
  if(cocode || userStore.userId){
    const params = {}
    if(cocode){
      params.code = cocode;
    }
    if(userStore.userId){
      params.userId = userStore.userId;
    }
    const result = await checkUserTellUsMoreApi(params)
    isVerified.value = result.data;
  }else{
    isVerified.value = 1;
  }
  const query = route.query;
  if (query.from === 'mail' && query.type === 'verify-email') { //普通邮箱注册用户
    if(isVerified.value == 0){
      showTellUsMore.value = true;
    }else if(isVerified.value == 2){
      ElMessage.error('The verification code has expired');
    }
  }else{
    if(isVerified.value == 0){
      showTellUsMore.value = true;
    }
  }
};

// 监听路由 query 参数变化
watch(
  () => route.query,
  () => {
    checkQueryParams();
  },
  { immediate: true } // 立即执行一次，检查初始状态
);

onMounted(() => {
  // 组件挂载时也检查一次 query 参数
  checkQueryParams();
});

// 提交事件可接入后端或埋点
const handleTellUsMoreSubmit = (payload) => {
  console.log('TellUsMore submit payload:', payload);
  showTellUsMore.value = false;
};
</script>

<template>
  <div>
    <Navbar v-if="showNavBar" />
    <router-view></router-view>
    
    <!-- 首页挂载"Tell Us More"弹框 -->
    <TellUsMore v-model:visible="showTellUsMore" :from="from" @submit="handleTellUsMoreSubmit" />
  </div>
</template>

<style scoped>

</style>
