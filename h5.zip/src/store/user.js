import { defineStore } from 'pinia'

/**
 * 用户信息 Store
 * 用于管理用户登录状态、用户信息等
 * 使用 pinia-plugin-persistedstate 插件实现数据持久化到 localStorage
 */
export const useUserStore = defineStore('user', {
  state: () => ({
    // 用户ID
    userId: null,
    // 用户名
    username: null,
    // 用户邮箱
    email: null,
    // 用户头像
    avatar: null,
    // 验证码
    code: null,
    // 确认密码（通常不保存，但为了完整性保留）
    confirmPassword: null,
    // 创建时间
    createTime: null,
    // Google OpenID
    googleOpenId: null,
    // Google 用户名
    googleUsername: null,
    // 是否订阅
    isSubscribe: null,
    // 是否已验证
    isVerified: null,
    // 最后登录时间
    lastLoginTime: null,
    // 登录类型（1: 邮箱密码登录, 2: Google登录等）
    loginType: null,
    // 新密码（通常不保存）
    newPassword: null,
    // 密码哈希（通常不保存，但为了完整性保留）
    password: null,
    // 用户状态
    status: null,
    // 认证 token
    token: null,
    // 更新时间
    updateTime: null,
  }),

  getters: {
    /**
     * 判断用户是否已登录
     * @returns {boolean} 如果存在 token 则返回 true，否则返回 false
     */
    isLoggedIn: (state) => !!state.token,

    /**
     * 获取用户基本信息（不包含敏感信息）
     * @returns {Object} 用户基本信息对象
     */
    userInfo: (state) => ({
      userId: state.userId,
      username: state.username,
      email: state.email,
      avatar: state.avatar,
      isVerified: state.isVerified,
      status: state.status,
      createTime: state.createTime,
      lastLoginTime: state.lastLoginTime,
      loginType: state.loginType,
    }),
  },

  actions: {
    /**
     * 设置用户信息（登录成功后调用）
     * @param {Object} userData - 用户数据对象，包含从登录接口返回的所有用户信息
     */
    setUserInfo(userData) {
      // 更新所有用户信息字段
      this.userId = userData.userId ?? null
      this.username = userData.username ?? null
      this.email = userData.email ?? null
      this.avatar = userData.avatar ?? null
      this.code = userData.code ?? null
      this.confirmPassword = userData.confirmPassword ?? null
      this.createTime = userData.createTime ?? null
      this.googleOpenId = userData.googleOpenId ?? null
      this.googleUsername = userData.googleUsername ?? null
      this.isSubscribe = userData.isSubscribe ?? null
      this.isVerified = userData.isVerified ?? null
      this.lastLoginTime = userData.lastLoginTime ?? null
      this.loginType = userData.loginType ?? null
      this.newPassword = userData.newPassword ?? null
      this.password = userData.password ?? null
      this.status = userData.status ?? null
      this.token = userData.token ?? null
      this.updateTime = userData.updateTime ?? null
    },

    setUserName(username){
      this.username = username
    },

    /**
     * 清除用户信息（退出登录时调用）
     */
    clearUserInfo() {
      this.userId = null
      this.username = null
      this.email = null
      this.avatar = null
      this.code = null
      this.confirmPassword = null
      this.createTime = null
      this.googleOpenId = null
      this.googleUsername = null
      this.isSubscribe = null
      this.isVerified = null
      this.lastLoginTime = null
      this.loginType = null
      this.newPassword = null
      this.password = null
      this.status = null
      this.token = null
      this.updateTime = null
    },

    /**
     * 更新用户信息（部分更新）
     * @param {Object} partialUserData - 需要更新的用户数据字段
     */
    updateUserInfo(partialUserData) {
      Object.keys(partialUserData).forEach((key) => {
        if (key in this.$state) {
          this[key] = partialUserData[key]
        }
      })
    },
  },

  // 配置持久化插件，使用 localStorage 存储
  persist: {
    enabled: true,
    strategies: [
      {
        key: 'user',
        storage: localStorage,
      },
    ],
  },
})
